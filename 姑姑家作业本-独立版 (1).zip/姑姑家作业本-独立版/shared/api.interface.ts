export const SUBJECTS = [
  'chinese', 'math', 'english', 'physics', 'chemistry',
  'biology', 'geography', 'history', 'politics',
] as const;
export type Subject = (typeof SUBJECTS)[number];
export const isSubject = (v: string): v is Subject =>
  (SUBJECTS as readonly string[]).includes(v);
export const SUBJECT_LABELS: Record<Subject, string> = {
  chinese: '语文', math: '数学', english: '英语',
  physics: '物理', chemistry: '化学', biology: '生物',
  geography: '地理', history: '历史', politics: '政治',
};
export const SUBJECT_EMOJIS: Record<Subject, string> = {
  chinese: '📚', math: '🔢', english: '🔤',
  physics: '⚡', chemistry: '🧪', biology: '🌱',
  geography: '🌍', history: '📜', politics: '🏛️',
};

export const QUESTION_TYPES = ['choice', 'multi_choice', 'true_false', 'fill', 'essay'] as const;
export type QuestionType = (typeof QUESTION_TYPES)[number];
export const isQuestionType = (v: string): v is QuestionType =>
  (QUESTION_TYPES as readonly string[]).includes(v);
export const QUESTION_TYPE_LABELS: Record<QuestionType, string> = {
  choice: '单选题', multi_choice: '多选题', true_false: '判断题',
  fill: '填空题', essay: '简答题',
};

export const DIFFICULTIES = ['easy', 'medium', 'hard'] as const;
export type Difficulty = (typeof DIFFICULTIES)[number];
export const isDifficulty = (v: string): v is Difficulty =>
  (DIFFICULTIES as readonly string[]).includes(v);
export const DIFFICULTY_LABELS: Record<Difficulty, string> = {
  easy: '简单', medium: '中等', hard: '困难',
};

export const SUBMISSION_STATUSES = ['submitted', 'graded'] as const;
export type SubmissionStatus = (typeof SUBMISSION_STATUSES)[number];
export const isSubmissionStatus = (v: string): v is SubmissionStatus =>
  (SUBMISSION_STATUSES as readonly string[]).includes(v);
export const SUBMISSION_STATUS_LABELS: Record<SubmissionStatus, string> = {
  submitted: '待批改', graded: '已批改',
};

export const KNOWLEDGE_TYPES = ['text', 'image', 'video'] as const;
export type KnowledgeType = (typeof KNOWLEDGE_TYPES)[number];
export const isKnowledgeType = (v: string): v is KnowledgeType =>
  (KNOWLEDGE_TYPES as readonly string[]).includes(v);
export const KNOWLEDGE_TYPE_LABELS: Record<KnowledgeType, string> = {
  text: '文字', image: '图片', video: '视频',
};

export const CHECKIN_TYPES = ['audio', 'text'] as const;
export type CheckinType = (typeof CHECKIN_TYPES)[number];
export const isCheckinType = (v: string): v is CheckinType =>
  (CHECKIN_TYPES as readonly string[]).includes(v);
export const CHECKIN_TYPE_LABELS: Record<CheckinType, string> = {
  audio: '录音打卡', text: '文字打卡',
};

export interface QuestionOption {
  label: string;
  value: string;
}

export interface Question {
  id: string;
  subject: Subject;
  type: QuestionType;
  title: string;
  options: QuestionOption[];
  correctAnswer: string;
  explanation: string;
  difficulty: Difficulty;
  tags: string[];
  createdAt: string;
}

export interface Assignment {
  id: string;
  title: string;
  subject: Subject;
  questionIds: string[];
  description: string;
  accessCode: string;
  deadline: string | null;
  isPublished: boolean;
  allowRetry: boolean;
  maxSubmissions: number;
  isClosed: boolean;
  createdAt: string;
  questions?: Question[];
  submissionCount?: number;
}

export interface Answer {
  id: string;
  submissionId: string;
  questionId: string;
  studentAnswer: string;
  isCorrect: boolean | null;
  autoPoints: string;
}

export interface Submission {
  id: string;
  assignmentId: string;
  assignmentTitle?: string;
  studentName: string;
  autoScore: string;
  teacherScore: string | null;
  teacherComment: string;
  status: SubmissionStatus;
  submissionIndex: number;
  submittedAt: string;
  answers?: Answer[];
  questions?: Question[];
}

export interface KnowledgePoint {
  id: string;
  title: string;
  subject: Subject;
  contentType: KnowledgeType;
  contentText: string;
  attachmentUrl: string;
  coverUrl: string;
  description: string;
  createdAt: string;
}

export interface CheckinTask {
  id: string;
  title: string;
  subject: Subject;
  taskType: CheckinType;
  requirement: string;
  accessCode: string;
  deadline: string | null;
  isPublished: boolean;
  allowRetry: boolean;
  maxSubmissions: number;
  isClosed: boolean;
  createdAt: string;
  recordCount?: number;
}

export interface CheckinRecord {
  id: string;
  taskId: string;
  studentName: string;
  audioUrl: string;
  note: string;
  teacherComment: string;
  status: string;
  submissionIndex: number;
  submittedAt: string;
}

export interface StudentStats {
  studentName: string;
  submissionCount: number;
  avgScore: number;
  latestScore: number;
  wrongQuestionIds: { questionId: string; count: number }[];
}

export interface ListResponse<T> {
  items: T[];
  total: number;
}

export interface IdResponse {
  id: string;
}

export interface TeacherLoginRequest {
  password: string;
}

export interface TeacherLoginResponse {
  ok: boolean;
  token?: string;
}

export interface TeacherChangePasswordRequest {
  oldPassword: string;
  newPassword: string;
}

export interface TeacherAuthStatus {
  isLoggedIn: boolean;
}

// ===== 家长端 =====
export interface ParentAccount {
  id: string;
  username: string;
  studentName: string;
  createdAt: string;
}

export interface ParentLoginRequest {
  username: string;
  password: string;
}

export interface ParentLoginResponse {
  ok: boolean;
  token?: string;
  studentName?: string;
}

export interface ParentOverviewSubmission {
  assignmentTitle: string;
  subject: string;
  score: string;
  teacherComment: string | null;
  status: SubmissionStatus;
  submittedAt: string;
}

export interface ParentOverviewCheckin {
  taskTitle: string;
  note: string | null;
  teacherComment: string | null;
  status: string;
  submittedAt: string;
}

export interface ParentOverview {
  studentName: string;
  submissions: ParentOverviewSubmission[];
  checkins: ParentOverviewCheckin[];
}
