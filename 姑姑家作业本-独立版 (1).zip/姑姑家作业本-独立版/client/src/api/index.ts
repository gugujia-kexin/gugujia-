import axios from 'axios';

// 独立部署版：不再走平台封装的请求器，直接用标准 axios。
const axiosForBackend = axios.create({
  baseURL: '',
  withCredentials: true,
});
import type {
  Question, Subject, QuestionType, Difficulty,
  Assignment, Submission, SubmissionStatus,
  KnowledgePoint, KnowledgeType,
  CheckinTask, CheckinRecord,
  StudentStats, ListResponse, IdResponse,
  ParentAccount, ParentOverview, ParentLoginResponse,
} from '@shared/api.interface';

const base = '/api';
const TEACHER_TOKEN_KEY = 'teacher_auth_token';

export function getTeacherToken(): string | null {
  try {
    return localStorage.getItem(TEACHER_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setTeacherToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(TEACHER_TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TEACHER_TOKEN_KEY);
    }
  } catch {
    // ignore
  }
}

function getCsrfTokenFromCookie(): string {
  const name = 'suda-csrf-token';
  const cookies = document.cookie.split('; ');
  for (const c of cookies) {
    const [k, v] = c.split('=');
    if (k === name) return decodeURIComponent(v);
  }
  return (window as any).csrfToken ?? '';
}

axiosForBackend.interceptors.request.use((config) => {
  const url = config.url ?? '';
  const isParentApi = url.startsWith(base + '/parent-auth') || url.startsWith(base + '/parent/overview');
  const token = isParentApi ? getParentToken() : getTeacherToken();
  if (token && url.startsWith(base + '/')) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  const csrf = getCsrfTokenFromCookie();
  if (csrf) {
    config.headers['X-Suda-Csrf-Token'] = csrf;
  }
  return config;
});

// === Questions ===
export const listQuestions = (params: {
  subject?: Subject;
  type?: QuestionType;
  difficulty?: Difficulty;
  page?: number;
  pageSize?: number;
}) =>
  axiosForBackend.get<ListResponse<Question>>(`${base}/questions`, { params }).then(r => r.data);

export const getQuestion = (id: string) =>
  axiosForBackend.get<Question>(`${base}/questions/${id}`).then(r => r.data);

export const createQuestion = (body: Partial<Question>) =>
  axiosForBackend.post<IdResponse>(`${base}/questions`, body).then(r => r.data);

export const updateQuestion = (id: string, body: Partial<Question>) =>
  axiosForBackend.patch<IdResponse>(`${base}/questions/${id}`, body).then(r => r.data);

export const deleteQuestion = (id: string) =>
  axiosForBackend.delete(`${base}/questions/${id}`).then(r => r.data);

// === Assignments ===
export const listAssignments = (params: { subject?: Subject; page?: number; pageSize?: number }) =>
  axiosForBackend.get<ListResponse<Assignment>>(`${base}/assignments`, { params }).then(r => r.data);

export const getAssignment = (id: string) =>
  axiosForBackend.get<Assignment>(`${base}/assignments/${id}`).then(r => r.data);

export const getAssignmentByCode = (code: string) =>
  axiosForBackend.get<Assignment>(`${base}/assignments/by-code/${code}`).then(r => r.data);

export const createAssignment = (body: Partial<Assignment>) =>
  axiosForBackend.post<IdResponse>(`${base}/assignments`, body).then(r => r.data);

export const updateAssignment = (id: string, body: Partial<Assignment>) =>
  axiosForBackend.patch<IdResponse>(`${base}/assignments/${id}`, body).then(r => r.data);

export const deleteAssignment = (id: string) =>
  axiosForBackend.delete(`${base}/assignments/${id}`).then(r => r.data);

export const regenerateAssignmentCode = (id: string) =>
  axiosForBackend.post<{ accessCode: string }>(`${base}/assignments/${id}/regenerate-code`).then(r => r.data);

export const closeAssignment = (id: string) =>
  axiosForBackend.post<IdResponse>(`${base}/assignments/${id}/close`).then(r => r.data);

export const reopenAssignment = (id: string) =>
  axiosForBackend.post<IdResponse>(`${base}/assignments/${id}/reopen`).then(r => r.data);

export const updateAssignmentDeadline = (id: string, deadline: string | null) =>
  axiosForBackend.patch<IdResponse>(`${base}/assignments/${id}/deadline`, { deadline }).then(r => r.data);

// === Submissions ===
export const listSubmissions = (params: {
  assignmentId?: string;
  studentName?: string;
  status?: SubmissionStatus;
  page?: number;
  pageSize?: number;
}) =>
  axiosForBackend.get<ListResponse<Submission>>(`${base}/submissions`, { params }).then(r => r.data);

export const getSubmission = (id: string) =>
  axiosForBackend.get<Submission>(`${base}/submissions/${id}`).then(r => r.data);

export const gradeSubmission = (id: string, body: { teacherScore: number; teacherComment: string }) =>
  axiosForBackend.patch<IdResponse>(`${base}/submissions/${id}/grade`, body).then(r => r.data);

export const submitAssignment = (body: {
  accessCode: string;
  studentName: string;
  answers: { questionId: string; studentAnswer: string }[];
}) =>
  axiosForBackend.post<IdResponse>(`${base}/submissions/submit`, body).then(r => r.data);

// === Knowledge Points ===
export const listKnowledge = (params: { subject?: Subject; contentType?: KnowledgeType; page?: number; pageSize?: number }) =>
  axiosForBackend.get<ListResponse<KnowledgePoint>>(`${base}/knowledge`, { params }).then(r => r.data);

export const getKnowledge = (id: string) =>
  axiosForBackend.get<KnowledgePoint>(`${base}/knowledge/${id}`).then(r => r.data);

export const createKnowledge = (body: Partial<KnowledgePoint>) =>
  axiosForBackend.post<IdResponse>(`${base}/knowledge`, body).then(r => r.data);

export const updateKnowledge = (id: string, body: Partial<KnowledgePoint>) =>
  axiosForBackend.patch<IdResponse>(`${base}/knowledge/${id}`, body).then(r => r.data);

export const deleteKnowledge = (id: string) =>
  axiosForBackend.delete(`${base}/knowledge/${id}`).then(r => r.data);

// === Checkin ===
export const listCheckinTasks = (params: { subject?: Subject; page?: number; pageSize?: number }) =>
  axiosForBackend.get<ListResponse<CheckinTask>>(`${base}/checkin/tasks`, { params }).then(r => r.data);

export const getCheckinTask = (id: string) =>
  axiosForBackend.get<CheckinTask>(`${base}/checkin/tasks/${id}`).then(r => r.data);

export const getCheckinTaskByCode = (code: string) =>
  axiosForBackend.get<CheckinTask>(`${base}/checkin/tasks/by-code/${code}`).then(r => r.data);

export const createCheckinTask = (body: Partial<CheckinTask>) =>
  axiosForBackend.post<IdResponse>(`${base}/checkin/tasks`, body).then(r => r.data);

export const updateCheckinTask = (id: string, body: Partial<CheckinTask>) =>
  axiosForBackend.patch<IdResponse>(`${base}/checkin/tasks/${id}`, body).then(r => r.data);

export const deleteCheckinTask = (id: string) =>
  axiosForBackend.delete(`${base}/checkin/tasks/${id}`).then(r => r.data);

export const regenerateCheckinTaskCode = (id: string) =>
  axiosForBackend.post<{ accessCode: string }>(`${base}/checkin/tasks/${id}/regenerate-code`).then(r => r.data);

export const closeCheckinTask = (id: string) =>
  axiosForBackend.post<IdResponse>(`${base}/checkin/tasks/${id}/close`).then(r => r.data);

export const reopenCheckinTask = (id: string) =>
  axiosForBackend.post<IdResponse>(`${base}/checkin/tasks/${id}/reopen`).then(r => r.data);

export const updateCheckinTaskDeadline = (id: string, deadline: string | null) =>
  axiosForBackend.patch<IdResponse>(`${base}/checkin/tasks/${id}/deadline`, { deadline }).then(r => r.data);

export const listCheckinRecords = (taskId: string) =>
  axiosForBackend.get<CheckinRecord[]>(`${base}/checkin/tasks/${taskId}/records`).then(r => r.data);

export const submitCheckin = (body: {
  taskId: string;
  studentName: string;
  audioUrl?: string;
  note?: string;
}) =>
  axiosForBackend.post<IdResponse>(`${base}/checkin/records`, body).then(r => r.data);

export const commentCheckin = (id: string, body: { teacherComment: string }) =>
  axiosForBackend.patch<IdResponse>(`${base}/checkin/records/${id}/comment`, body).then(r => r.data);

// === Students ===
export const getStudentStats = (params?: { studentName?: string }) =>
  axiosForBackend.get<StudentStats[]>(`${base}/students/stats`, { params }).then(r => r.data);

export const listStudents = () =>
  axiosForBackend
    .get<{ items: string[] } | string[]>(`${base}/students/list`)
    .then(r => (Array.isArray(r.data) ? r.data : r.data.items ?? []));

// === Teacher Auth ===
export const teacherLogin = (password: string) =>
  axiosForBackend.post<{ ok: boolean; token?: string }>(`${base}/teacher-auth/login`, { password })
    .then(r => {
      if (r.data.token) {
        setTeacherToken(r.data.token);
      }
      return r.data;
    });

export const teacherLogout = () =>
  axiosForBackend.post<{ ok: boolean }>(`${base}/teacher-auth/logout`)
    .then(r => {
      setTeacherToken(null);
      return r.data;
    });

export const teacherChangePassword = (oldPassword: string, newPassword: string) =>
  axiosForBackend.post<{ ok: boolean }>(`${base}/teacher-auth/change-password`, { oldPassword, newPassword }).then(r => r.data);

export const getTeacherAuthStatus = () =>
  axiosForBackend.get<{ isLoggedIn: boolean }>(`${base}/teacher-auth/status`).then(r => r.data);

// === 班级门户（学生端） ===
export interface PortalTask {
  kind: 'assignment' | 'checkin';
  id: string;
  title: string;
  subject: string;
  accessCode: string;
  deadline: string | null;
  done: boolean;
  score: string | null;
  taskType?: string;
  requirement?: string;
}

export interface PortalTaskboard {
  classCode: string;
  items: PortalTask[];
  pendingCount: number;
}

export const portalBind = (code: string, name: string) =>
  axiosForBackend
    .post<{ mode: 'class' | 'assignment' | 'checkin'; code?: string; name: string }>(
      `${base}/portal/bind`,
      { code, name },
    )
    .then((r) => r.data);

export const portalTasks = (name: string) =>
  axiosForBackend
    .get<PortalTaskboard>(`${base}/portal/tasks`, { params: { name } })
    .then((r) => r.data);

export const portalClassCode = () =>
  axiosForBackend.get<{ classCode: string }>(`${base}/portal/class-code`).then((r) => r.data);

// === 老师端：班级码 / 删除 ===
export const getClassCode = () =>
  axiosForBackend.get<{ classCode: string }>(`${base}/students/class-code`).then((r) => r.data);

export const setClassCode = (classCode: string) =>
  axiosForBackend.patch<{ classCode: string }>(`${base}/students/class-code`, { classCode }).then((r) => r.data);

export const deleteSubmission = (id: string) =>
  axiosForBackend.delete<{ ok: boolean }>(`${base}/submissions/${id}`).then((r) => r.data);

export const deleteCheckinRecord = (id: string) =>
  axiosForBackend.delete<{ ok: boolean }>(`${base}/checkin/records/${id}`).then((r) => r.data);

export const deleteStudentByName = (name: string) =>
  axiosForBackend.delete<{ ok: boolean; deleted: number }>(`${base}/students/by-name/${encodeURIComponent(name)}`).then((r) => r.data);

export const clearAllRecords = () =>
  axiosForBackend.delete<{ ok: boolean }>(`${base}/students/records/all`).then((r) => r.data);

// === 家长端 ===
const PARENT_TOKEN_KEY = 'parent_auth_token';

export function getParentToken(): string | null {
  try { return localStorage.getItem(PARENT_TOKEN_KEY); } catch { return null; }
}

export function setParentToken(token: string | null): void {
  try {
    if (token) localStorage.setItem(PARENT_TOKEN_KEY, token);
    else localStorage.removeItem(PARENT_TOKEN_KEY);
  } catch { /* ignore */ }
}

export const parentLogin = (username: string, password: string) =>
  axiosForBackend.post<ParentLoginResponse>(`${base}/parent-auth/login`, { username, password })
    .then(r => {
      if (r.data.token) setParentToken(r.data.token);
      return r.data;
    });

export const parentLogout = () =>
  axiosForBackend.post<{ ok: boolean }>(`${base}/parent-auth/logout`)
    .then(r => { setParentToken(null); return r.data; });

export const getParentOverview = () =>
  axiosForBackend.get<ParentOverview>(`${base}/parent/overview`).then(r => r.data);

export const listParents = () =>
  axiosForBackend.get<{ items: ParentAccount[] }>(`${base}/parents`)
    .then(r => (Array.isArray(r.data) ? r.data : r.data.items ?? []));

export const createParent = (body: { username: string; password: string; studentName: string }) =>
  axiosForBackend.post<{ id: string }>(`${base}/parents`, body).then(r => r.data);

export const updateParent = (id: string, body: { studentName?: string; password?: string }) =>
  axiosForBackend.patch<{ ok: boolean }>(`${base}/parents/${id}`, body).then(r => r.data);

export const deleteParent = (id: string) =>
  axiosForBackend.delete<{ ok: boolean }>(`${base}/parents/${id}`).then(r => r.data);
