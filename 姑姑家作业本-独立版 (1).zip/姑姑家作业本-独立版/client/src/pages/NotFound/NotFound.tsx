import { Link } from 'react-router-dom';

const NotFound = () => {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-6 text-center">
      <h1 className="text-2xl font-bold">页面不存在</h1>
      <p className="text-muted-foreground">这个地址可能已经失效了。</p>
      <Link to="/" className="text-primary underline">
        回到首页
      </Link>
    </div>
  );
};

export default NotFound;
