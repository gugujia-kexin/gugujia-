import { useState, FormEvent } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Lock, User, ArrowLeft, Sparkles } from 'lucide-react';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import { parentLogin, getParentToken } from '@client/src/api';
import logoUrl from '@/assets/logo.png';
import { Image } from '@client/src/components/ui/image';

const ParentLoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  if (getParentToken()) navigate('/parent', { replace: true });

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    if (!username.trim()) { setError('请输入家长账号'); return; }
    if (!password.trim()) { setError('请输入密码'); return; }
    setSubmitting(true);
    try {
      const data = await parentLogin(username.trim(), password);
      if (data.ok) navigate('/parent', { replace: true });
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { error?: { message?: string } } } })
        .response?.data?.error?.message;
      setError(msg || '账号或密码错误，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="mb-6">
        <Image src={logoUrl} alt="姑姑家 Auntie's Home" className="h-20 sm:h-24 w-auto mx-auto" />
      </motion.div>

      <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }} className="font-display text-3xl sm:text-4xl text-foreground mb-2">
        家长入口
      </motion.h1>
      <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.15 }} className="text-muted-foreground mb-8 flex items-center gap-2">
        <Sparkles size={14} className="text-warm-gold" />
        登录后查看孩子的作业与打卡记录
        <Sparkles size={14} className="text-warm-gold" />
      </motion.p>

      <motion.form initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }} onSubmit={handleSubmit} className="w-full max-w-sm space-y-4">
        <div className="space-y-2 text-left">
          <Label htmlFor="username">家长账号</Label>
          <div className="relative">
            <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input id="username" type="text" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="老师发给您的账号" className="pl-10 h-12 rounded-xl" autoFocus />
          </div>
        </div>
        <div className="space-y-2 text-left">
          <Label htmlFor="password">密码</Label>
          <div className="relative">
            <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="请输入密码" className="pl-10 h-12 rounded-xl" />
          </div>
          {error && <motion.p initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="text-sm text-status-wrong mt-2">{error}</motion.p>}
        </div>
        <Button type="submit" size="lg" className="w-full h-12 rounded-xl text-base btn-bounce" disabled={submitting}>
          {submitting ? '登录中...' : '进入家长端'}
        </Button>
      </motion.form>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.5 }} className="mt-10">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft size={16} /> 返回首页
        </Link>
      </motion.div>
    </div>
  );
};

export default ParentLoginPage;
