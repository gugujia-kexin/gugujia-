import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BookOpen, Mic, LogOut, User, MessageCircle } from 'lucide-react';
import { Button } from '@client/src/components/ui/button';
import { getParentOverview, parentLogout, getParentToken } from '@client/src/api';
import type { ParentOverview } from '@shared/api.interface';

const fmt = (iso: string) => {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

const statusText = (s: string) => (s === 'graded' ? '已批改' : '已提交');

const ParentDashboard = () => {
  const navigate = useNavigate();
  const [data, setData] = useState<ParentOverview | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!getParentToken()) { navigate('/parent/login', { replace: true }); return; }
    getParentOverview()
      .then(setData)
      .catch(() => { navigate('/parent/login', { replace: true }); })
      .finally(() => setLoading(false));
  }, [navigate]);

  const handleLogout = async () => {
    await parentLogout();
    navigate('/parent/login', { replace: true });
  };

  if (loading) return <div className="min-h-[60vh] flex items-center justify-center text-muted-foreground">加载中...</div>;
  if (!data) return <div className="min-h-[60vh] flex items-center justify-center">{error || '暂无数据'}</div>;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl text-foreground flex items-center gap-2">
            <User size={24} className="text-warm-gold" />
            {data.studentName}
          </h1>
          <p className="text-muted-foreground text-sm mt-1">孩子的作业与打卡记录（只读）</p>
        </div>
        <Button variant="outline" size="sm" onClick={handleLogout} className="gap-2">
          <LogOut size={16} /> 退出
        </Button>
      </div>

      <section className="mb-8">
        <h2 className="flex items-center gap-2 font-semibold text-lg mb-3">
          <BookOpen size={18} className="text-warm-gold" /> 作业记录
        </h2>
        {data.submissions.length === 0 && (
          <div className="bg-card border border-border rounded-xl p-6 text-center text-muted-foreground text-sm">暂无作业记录</div>
        )}
        <div className="space-y-3">
          {data.submissions.map((s, i) => (
            <motion.div key={`${s.assignmentTitle}-${i}`} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, delay: i * 0.05 }} className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-medium truncate">{s.assignmentTitle}</div>
                  <div className="text-xs text-muted-foreground mt-1">{fmt(s.submittedAt)}</div>
                </div>
                <div className="text-right shrink-0">
                  <div className="font-semibold text-warm-gold">{s.score ? `${s.score} 分` : '待批改'}</div>
                  <div className="text-xs text-muted-foreground">{statusText(s.status)}</div>
                </div>
              </div>
              {s.teacherComment && (
                <div className="mt-3 text-sm bg-background/60 rounded-lg p-3 flex gap-2">
                  <MessageCircle size={15} className="text-warm-gold shrink-0 mt-0.5" />
                  <span className="text-foreground/90">{s.teacherComment}</span>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="flex items-center gap-2 font-semibold text-lg mb-3">
          <Mic size={18} className="text-warm-gold" /> 打卡记录
        </h2>
        {data.checkins.length === 0 && (
          <div className="bg-card border border-border rounded-xl p-6 text-center text-muted-foreground text-sm">暂无打卡记录</div>
        )}
        <div className="space-y-3">
          {data.checkins.map((c, i) => (
            <motion.div key={`${c.taskTitle}-${i}`} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, delay: i * 0.05 }} className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-medium truncate">{c.taskTitle}</div>
                  <div className="text-xs text-muted-foreground mt-1">{fmt(c.submittedAt)}</div>
                </div>
                <div className="text-xs text-muted-foreground shrink-0">{statusText(c.status)}</div>
              </div>
              {c.note && <div className="mt-2 text-sm text-foreground/80">备注：{c.note}</div>}
              {c.teacherComment && (
                <div className="mt-3 text-sm bg-background/60 rounded-lg p-3 flex gap-2">
                  <MessageCircle size={15} className="text-warm-gold shrink-0 mt-0.5" />
                  <span className="text-foreground/90">{c.teacherComment}</span>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default ParentDashboard;
