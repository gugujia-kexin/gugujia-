import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Sparkles, ArrowRight, BookOpen, Mic2, Lightbulb } from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import { portalBind } from '@/api';
import Sticker from '@/components/Sticker';
import logoUrl from '@/assets/logo.png';
import { Image } from '@client/src/components/ui/image';

const StudentJoin: React.FC = () => {
  const navigate = useNavigate();
  const { playClick } = useSoundEffects();
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [rememberName, setRememberName] = useState(true);
  const [loading, setLoading] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem('studentName');
    if (saved) {
      setName(saved);
      setRememberName(true);
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    playClick();

    if (!code.trim()) {
      toast.error('请输入班级码');
      return;
    }
    if (!name.trim()) {
      toast.error('请输入你的姓名');
      return;
    }
    if (name.trim().length > 20) {
      toast.error('姓名最多 20 个字哦');
      return;
    }
    if (!/^[A-Za-z0-9]{4,20}$/.test(code.trim())) {
      toast.error('码是 4-20 位字母或数字哦');
      return;
    }

    setLoading(true);
    try {
      const entry = await portalBind(code.trim(), name.trim());
      if (rememberName) {
        localStorage.setItem('studentName', name.trim());
      } else {
        localStorage.removeItem('studentName');
      }
      const n = encodeURIComponent(name.trim());
      if (entry.mode === 'class') {
        localStorage.setItem('classCode', code.trim().toUpperCase());
        navigate(`/student/home?name=${n}`);
      } else if (entry.mode === 'assignment') {
        navigate(`/student/assignment/${code.trim().toUpperCase()}?name=${n}`);
      } else {
        navigate(`/student/checkin/${code.trim().toUpperCase()}?name=${n}`);
      }
    } catch (err: unknown) {
      logger.error('进入小书房失败', err);
      const msg = (err as { response?: { data?: { message?: string | string[] } } })?.response?.data?.message;
      toast.error(Array.isArray(msg) ? msg[0] : (msg || '这个码没找到哦，再检查一下吧～'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-10rem)] flex items-center justify-center py-8">
      <motion.div
        initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="w-full max-w-md"
      >
        <div className="bg-card rounded-2xl shadow-lg border border-border p-6 sm:p-8 relative overflow-hidden">
          {/* 装饰星星 */}
          {!reducedMotion && (
            <>
              <motion.div
                animate={{ y: [0, -6, 0], rotate: [0, 8, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute top-6 right-6 text-warm-gold"
              >
                <Sparkles size={28} fill="currentColor" />
              </motion.div>
              <motion.div
                animate={{ y: [0, -4, 0], rotate: [0, -6, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
                className="absolute bottom-20 left-4 text-warm-gold opacity-70"
              >
                <Sparkles size={18} fill="currentColor" />
              </motion.div>
            </>
          )}

          {/* Logo + 标题 */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-accent/50 mb-4">
              <Image src={logoUrl} alt="姑姑家" className="w-14 h-14 object-contain" />
            </div>
            <h1 className="font-display text-3xl sm:text-4xl text-foreground mb-2">
              进入小书房
            </h1>
            <p className="text-muted-foreground text-base">
              输入班级码和名字，作业、打卡一次看全
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                班级码
              </label>
              <Input
                type="text"
                autoCapitalize="characters"
                maxLength={20}
                placeholder="班级码"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                className="h-14 text-2xl font-mono tnum text-center tracking-widest"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                你的姓名
              </label>
              <Input
                type="text"
                maxLength={20}
                placeholder="请输入你的姓名"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-12 text-lg"
              />
            </div>

            <label className="flex items-center gap-2 cursor-pointer select-none text-sm text-muted-foreground">
              <input
                type="checkbox"
                checked={rememberName}
                onChange={(e) => setRememberName(e.target.checked)}
                className="w-4 h-4 rounded border-border text-primary focus:ring-primary accent-primary"
              />
              记住我的名字
            </label>

            <Button
              type="submit"
              size="lg"
              className="w-full h-14 text-lg font-medium btn-bounce"
              disabled={loading}
            >
              {loading ? '正在验证...' : (
                <>
                  进小书房
                  <ArrowRight size={20} />
                </>
              )}
            </Button>
          </form>

          {/* 底部链接 */}
          <div className="mt-6 pt-6 border-t border-border space-y-3">
            <div className="flex items-start gap-3 p-3 rounded-xl bg-accent/30">
              <div className="w-10 h-10 rounded-xl bg-destructive/10 text-destructive flex items-center justify-center flex-shrink-0">
                <Mic2 size={20} />
              </div>
              <div className="flex-1">
                <div className="font-medium text-foreground text-sm">作业和打卡都在清单里</div>
                <div className="text-xs text-muted-foreground">用班级码进来一次，所有任务一目了然，不用一个个输码</div>
              </div>
              <Sticker name="haode" size={54} animation="wobble" delay={0.3} className="self-center" />
            </div>

            <Link
              to="/student/knowledge"
              onClick={playClick}
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-accent/50 transition-colors group"
            >
              <div className="w-10 h-10 rounded-xl bg-warm-gold/20 text-warning flex items-center justify-center flex-shrink-0">
                <Lightbulb size={20} />
              </div>
              <div className="flex-1">
                <div className="font-medium text-foreground">知识点学习</div>
                <div className="text-xs text-muted-foreground">看看有趣的知识点</div>
              </div>
              <ArrowRight size={16} className="text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 transition-all" />
            </Link>
          </div>

          {/* 小印章 + 表情 */}
          <div className="mt-4 flex items-center justify-center gap-2">
            <span className="teacher-seal text-[10px]">可心老师</span>
          </div>

        </div>
      </motion.div>
    </div>
  );
};

export default StudentJoin;
