import { useState, useEffect, useMemo, useCallback } from 'react';
import { useParams, useNavigate, useSearchParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronLeft, ChevronRight, ArrowLeft, Check, X,
  Star, Sparkles, Send, AlertCircle,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { SUBJECT_LABELS, QUESTION_TYPE_LABELS } from '@shared/api.interface';
import type { Question, Assignment } from '@shared/api.interface';
import { getAssignmentByCode, submitAssignment } from '@/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import logoUrl from '@/assets/logo.png';
import { Image } from '@client/src/components/ui/image';

const StudentAssignment: React.FC = () => {
  const { code = '' } = useParams<{ code: string }>();
  const navigate = useNavigate();
  const { playCorrect, playWrong, playClick, playWin } = useSoundEffects();

  const [assignment, setAssignment] = useState<Assignment | null>(null);
  const [loading, setLoading] = useState(true);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [alreadySubmitted, setAlreadySubmitted] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [searchParams] = useSearchParams();

  const studentName = searchParams.get('name') || '';

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    if (!code) return;
    if (!studentName) {
      navigate('/student');
      return;
    }
    setLoading(true);
    getAssignmentByCode(code)
      .then((data: Assignment) => {
        setAssignment(data);
        setQuestions(data.questions || []);
      })
      .catch((err: unknown) => {
        logger.error('加载作业失败', err);
        toast.error('作业加载失败，请检查访问码');
      })
      .finally(() => setLoading(false));
  }, [code, studentName, navigate]);

  const currentQuestion = questions[currentIndex];
  const isLast = currentIndex === questions.length - 1;
  const progress = questions.length > 0 ? ((currentIndex + 1) / questions.length) * 100 : 0;

  const currentAnswer = currentQuestion ? answers[currentQuestion.id] ?? '' : '';

  const checkAnswer = useCallback((answer: string) => {
    if (!currentQuestion) return;
    const q = currentQuestion;
    const correctAnswer = q.correctAnswer;

    let isCorrect = false;
    if (q.type === 'choice' || q.type === 'true_false') {
      isCorrect = answer === correctAnswer;
    } else if (q.type === 'multi_choice') {
      const a = answer.split(',').sort().join(',');
      const c = correctAnswer.split(',').sort().join(',');
      isCorrect = a === c;
    } else if (q.type === 'fill') {
      isCorrect = answer.trim() === correctAnswer.trim();
    }

    if (isCorrect) {
      setFeedback('correct');
      playCorrect();
    } else {
      setFeedback('wrong');
      playWrong();
    }

    // 0.8 秒后跳下一题（最后一题不自动跳）
    if (!isLast) {
      setTimeout(() => {
        setFeedback(null);
        setCurrentIndex((prev) => prev + 1);
      }, 800);
    } else {
      setTimeout(() => {
        setFeedback(null);
      }, 800);
    }
  }, [currentQuestion, isLast, playCorrect, playWrong]);

  const handleChoiceSelect = (value: string) => {
    if (feedback || !currentQuestion) return;
    playClick();

    const q = currentQuestion;
    if (q.type === 'choice' || q.type === 'true_false') {
      setAnswers((prev) => ({ ...prev, [q.id]: value }));
      checkAnswer(value);
    } else if (q.type === 'multi_choice') {
      const current = answers[q.id] ? answers[q.id].split(',') : [];
      const idx = current.indexOf(value);
      let next: string[];
      if (idx >= 0) {
        next = current.filter((v) => v !== value);
      } else {
        next = [...current, value];
      }
      setAnswers((prev) => ({ ...prev, [q.id]: next.join(',') }));
    }
  };

  const handleFillSubmit = () => {
    if (feedback || !currentQuestion) return;
    const val = answers[currentQuestion.id] || '';
    if (!val.trim()) {
      toast.error('请填写答案');
      return;
    }
    playClick();
    checkAnswer(val);
  };

  const handleFillChange = (val: string) => {
    if (!currentQuestion) return;
    setAnswers((prev) => ({ ...prev, [currentQuestion.id]: val }));
  };

  const handleMultiSubmit = () => {
    if (feedback || !currentQuestion) return;
    const val = answers[currentQuestion.id] || '';
    if (!val) {
      toast.error('请至少选择一个选项');
      return;
    }
    playClick();
    checkAnswer(val);
  };

  const handlePrev = () => {
    playClick();
    if (currentIndex > 0) {
      setFeedback(null);
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleNext = () => {
    playClick();
    if (!isLast) {
      setFeedback(null);
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handleSubmitClick = () => {
    playClick();
    const unanswered = questions.filter((q) => !answers[q.id]?.trim()).length;
    if (unanswered > 0) {
      toast.warning(`还有 ${unanswered} 道题没答哦`);
    }
    setShowConfirm(true);
  };

  const handleSubmit = async () => {
    if (!assignment) return;
    setSubmitting(true);
    try {
      const answersArr = questions
        .filter((q) => answers[q.id])
        .map((q) => ({ questionId: q.id, studentAnswer: answers[q.id] }));
      const result = await submitAssignment({
        accessCode: code,
        studentName,
        answers: answersArr,
      });
      playWin();
      navigate(`/student/result/${result.id}`);
    } catch (err: unknown) {
      logger.error('提交失败', err);
      const msg = (err as { response?: { data?: { error?: { message?: string } } } })?.response?.data?.error?.message;
      if (msg && (msg.includes('已提交') || msg.includes('重复'))) {
        setAlreadySubmitted(true);
        setShowConfirm(false);
      } else {
        toast.error(msg || '提交失败，请稍后再试');
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <AssignmentSkeleton />;
  }

  if (!assignment || questions.length === 0) {
    return (
      <div className="text-center py-16">
        <p className="text-muted-foreground mb-4">作业不存在或还没有题目</p>
        <Button variant="outline" onClick={() => navigate('/student')}>
          <ArrowLeft size={16} /> 返回
        </Button>
      </div>
    );
  }

  if (alreadySubmitted) {
    return (
      <div className="max-w-md mx-auto py-16">
        <motion.div
          initial={reducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          className="bg-card rounded-2xl shadow-lg border border-border p-8 text-center"
        >
          <div className="w-20 h-20 rounded-full bg-warm-gold/20 flex items-center justify-center mx-auto mb-6">
            <AlertCircle size={40} className="text-warning" />
          </div>
          <h1 className="font-display text-2xl sm:text-3xl mb-2">你已经提交过啦</h1>
          <p className="text-muted-foreground mb-6">
            {studentName} 同学，这份作业你之前已经提交过了哦～
            <br />
            可以等可心老师批改后查看结果
          </p>
          <div className="space-y-3">
            <Button
              className="w-full h-12"
              onClick={() => navigate('/student')}
            >
              <ArrowLeft size={18} /> 返回首页
            </Button>
          </div>
          <div className="mt-6">
            <span className="teacher-seal text-[10px]">可心老师</span>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* 返回 + 作业标题 */}
      <div className="flex items-center gap-3 mb-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/student')} aria-label="返回">
          <ArrowLeft size={20} />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="font-display text-xl truncate">{assignment.title}</div>
          <div className="text-xs text-muted-foreground">
            {SUBJECT_LABELS[assignment.subject]} · 共 {questions.length} 题
          </div>
        </div>
      </div>

      {/* 进度条 */}
      <div className="bg-muted rounded-full h-3 mb-6 overflow-hidden">
        <motion.div
          className="h-full bg-primary rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
        />
      </div>
      <div className="text-right text-sm text-muted-foreground mb-4 tnum">
        第 {currentIndex + 1} / {questions.length} 题
      </div>

      {/* 答题卡 */}
      <AnimatePresence mode="wait">
        {currentQuestion && (
          <motion.div
            key={currentQuestion.id}
            initial={reducedMotion ? { opacity: 0 } : { opacity: 0, x: 20 }}
            animate={feedback === 'wrong' && !reducedMotion
              ? { x: [-6, 6, -4, 4, 0] }
              : { opacity: 1, x: 0 }}
            exit={reducedMotion ? { opacity: 0 } : { opacity: 0, x: -20 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className={`bg-card rounded-2xl shadow-lg border-2 p-6 sm:p-8 relative overflow-hidden ${
              feedback === 'correct'
                ? 'border-status-correct'
                : feedback === 'wrong'
                  ? 'border-status-wrong'
                  : 'border-border'
            }`}
          >
            {/* 星星爆炸效果 */}
            {feedback === 'correct' && !reducedMotion && (
              <StarBurst />
            )}

            {/* logo 水印 */}
            <div className="absolute top-4 right-4 opacity-10">
              <Image src={logoUrl} alt="" className="w-16 h-16" />
            </div>

            {/* 标签 */}
            <div className="flex items-center gap-2 mb-4">
              <Badge variant="default" className="text-xs">
                {SUBJECT_LABELS[currentQuestion.subject]}
              </Badge>
              <Badge variant="secondary" className="text-xs">
                {QUESTION_TYPE_LABELS[currentQuestion.type]}
              </Badge>
              {feedback === 'correct' && (
                <Badge className="bg-status-correct text-white ml-auto">
                  <Check size={14} className="mr-1" /> 答对啦
                </Badge>
              )}
              {feedback === 'wrong' && (
                <Badge variant="destructive" className="ml-auto">
                  <X size={14} className="mr-1" /> 答错了
                </Badge>
              )}
            </div>

            {/* 题干 */}
            <div className="text-lg sm:text-xl font-medium mb-6 leading-relaxed">
              <span className="text-primary font-bold mr-2">
                {currentIndex + 1}.
              </span>
              {currentQuestion.title}
            </div>

            {/* 选项区 */}
            <div className="space-y-3 mb-6">
              {currentQuestion.type === 'choice' &&
                currentQuestion.options.map((opt) => (
                  <motion.button
                    key={opt.value}
                    whileHover={!reducedMotion && !feedback ? { scale: 1.02, y: -2 } : {}}
                    whileTap={!reducedMotion && !feedback ? { scale: 0.98 } : {}}
                    onClick={() => handleChoiceSelect(opt.value)}
                    disabled={!!feedback}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                      currentAnswer === opt.value
                        ? feedback === 'correct'
                          ? 'border-status-correct bg-status-correct/10'
                          : feedback === 'wrong'
                            ? 'border-status-wrong bg-status-wrong/10'
                            : 'border-primary bg-primary/10'
                        : opt.value === currentQuestion.correctAnswer && feedback === 'wrong'
                          ? 'border-status-correct bg-status-correct/10'
                          : 'border-border bg-background hover:border-primary/50'
                    } disabled:cursor-default`}
                  >
                    <span className="font-bold text-primary mr-3">
                      {opt.label}.
                    </span>
                    <span>{opt.value}</span>
                  </motion.button>
                ))}

              {currentQuestion.type === 'multi_choice' &&
                currentQuestion.options.map((opt) => {
                  const selected = currentAnswer.split(',').includes(opt.value);
                  return (
                    <motion.button
                      key={opt.value}
                      whileHover={!reducedMotion && !feedback ? { scale: 1.02, y: -2 } : {}}
                      whileTap={!reducedMotion && !feedback ? { scale: 0.98 } : {}}
                      onClick={() => handleChoiceSelect(opt.value)}
                      disabled={!!feedback}
                      className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                        selected
                          ? 'border-primary bg-primary/10'
                          : 'border-border bg-background hover:border-primary/50'
                      } disabled:cursor-default`}
                    >
                      <span className="font-bold text-primary mr-3">
                        {opt.label}.
                      </span>
                      <span>{opt.value}</span>
                    </motion.button>
                  );
                })}

              {currentQuestion.type === 'multi_choice' && !feedback && (
                <Button
                  onClick={handleMultiSubmit}
                  className="w-full h-12 mt-2"
                >
                  确认答案
                </Button>
              )}

              {currentQuestion.type === 'true_false' && (
                <div className="grid grid-cols-2 gap-4">
                  <motion.button
                    whileHover={!reducedMotion && !feedback ? { scale: 1.05, y: -2 } : {}}
                    whileTap={!reducedMotion && !feedback ? { scale: 0.95 } : {}}
                    onClick={() => handleChoiceSelect('true')}
                    disabled={!!feedback}
                    className={`p-6 rounded-xl border-2 text-center transition-all ${
                      currentAnswer === 'true'
                        ? feedback === 'correct'
                          ? 'border-status-correct bg-status-correct/10'
                          : feedback === 'wrong'
                            ? 'border-status-wrong bg-status-wrong/10'
                            : 'border-primary bg-primary/10'
                        : currentQuestion.correctAnswer === 'true' && feedback === 'wrong'
                          ? 'border-status-correct bg-status-correct/10'
                          : 'border-border bg-background hover:border-status-correct/50'
                    } disabled:cursor-default`}
                  >
                    <Check size={40} className="mx-auto text-status-correct mb-2" strokeWidth={3} />
                    <div className="font-bold text-lg">正确</div>
                  </motion.button>
                  <motion.button
                    whileHover={!reducedMotion && !feedback ? { scale: 1.05, y: -2 } : {}}
                    whileTap={!reducedMotion && !feedback ? { scale: 0.95 } : {}}
                    onClick={() => handleChoiceSelect('false')}
                    disabled={!!feedback}
                    className={`p-6 rounded-xl border-2 text-center transition-all ${
                      currentAnswer === 'false'
                        ? feedback === 'correct'
                          ? 'border-status-correct bg-status-correct/10'
                          : feedback === 'wrong'
                            ? 'border-status-wrong bg-status-wrong/10'
                            : 'border-primary bg-primary/10'
                        : currentQuestion.correctAnswer === 'false' && feedback === 'wrong'
                          ? 'border-status-correct bg-status-correct/10'
                          : 'border-border bg-background hover:border-status-wrong/50'
                    } disabled:cursor-default`}
                  >
                    <X size={40} className="mx-auto text-status-wrong mb-2" strokeWidth={3} />
                    <div className="font-bold text-lg">错误</div>
                  </motion.button>
                </div>
              )}

              {currentQuestion.type === 'fill' && (
                <div className="space-y-3">
                  <Input
                    type="text"
                    placeholder="请输入答案..."
                    value={currentAnswer}
                    onChange={(e) => handleFillChange(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !feedback) handleFillSubmit();
                    }}
                    disabled={!!feedback}
                    className="h-14 text-lg"
                  />
                  {!feedback && (
                    <Button onClick={handleFillSubmit} className="w-full h-12">
                      提交答案
                    </Button>
                  )}
                </div>
              )}

              {currentQuestion.type === 'essay' && (
                <div className="space-y-3">
                  <Textarea
                    placeholder="请输入你的答案...（简答题由老师批改）"
                    value={currentAnswer}
                    onChange={(e) => handleFillChange(e.target.value)}
                    className="min-h-[160px] text-base"
                  />
                  <p className="text-xs text-muted-foreground">
                    简答题由可心老师亲自批改，提交后可以看到分数哦～
                  </p>
                </div>
              )}
            </div>

            {/* 解析（答错时显示） */}
            {feedback === 'wrong' && currentQuestion.explanation && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="mb-4 p-4 rounded-xl bg-warning/20 border border-warning/30"
              >
                <div className="font-medium text-warning-foreground mb-1">
                  💡 正确答案：{currentQuestion.correctAnswer}
                </div>
                <div className="text-sm text-foreground/80">
                  {currentQuestion.explanation}
                </div>
              </motion.div>
            )}

            {/* 按钮区 */}
            <div className="flex items-center justify-between gap-3 pt-2">
              <Button
                variant="outline"
                onClick={handlePrev}
                disabled={currentIndex === 0}
                className="h-12 px-4"
              >
                <ChevronLeft size={20} /> 上一题
              </Button>

              {!isLast ? (
                <Button
                  onClick={handleNext}
                  disabled={feedback ? false : !currentAnswer}
                  className="h-12 px-6"
                >
                  下一题 <ChevronRight size={20} />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmitClick}
                  className="h-12 px-6 bg-status-correct hover:bg-status-correct/90"
                >
                  <Send size={18} /> 提交作业
                </Button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 提交确认弹窗 */}
      <AlertDialog open={showConfirm} onOpenChange={setShowConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl">确认提交？</AlertDialogTitle>
            <AlertDialogDescription>
              {studentName && <span className="block mb-2">{studentName} 同学</span>}
              提交后就不能改答案啦，确认都检查好了吗？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={submitting}>再看看</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                handleSubmit();
              }}
              disabled={submitting}
              className="bg-status-correct hover:bg-status-correct/90"
            >
              {submitting ? '提交中...' : '确认提交'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

const StarBurst: React.FC = () => {
  const stars = Array.from({ length: 8 });
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {stars.map((_, i) => {
        const angle = (i / stars.length) * 360;
        const distance = 60 + Math.random() * 30;
        const x = Math.cos((angle * Math.PI) / 180) * distance;
        const y = Math.sin((angle * Math.PI) / 180) * distance;
        const delay = i * 0.03;
        const size = 16 + Math.random() * 16;
        return (
          <motion.span
            key={i}
            initial={{ opacity: 0, scale: 0, x: '50%', y: '50%', rotate: 0 }}
            animate={{
              opacity: [0, 1, 0],
              scale: [0, 1.2, 0.5],
              x: `calc(50% + ${x}px)`,
              y: `calc(50% + ${y}px)`,
              rotate: angle + 180,
            }}
            transition={{ duration: 0.8, delay, ease: 'easeOut' }}
            className="absolute top-1/2 left-1/2 text-warm-gold"
          >
            <Star size={size} fill="currentColor" />
          </motion.span>
        );
      })}
      {/* 闪光效果 */}
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: [0, 0.4, 0], scale: [0.5, 1.5, 2] }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-40 h-40 rounded-full bg-warm-gold/30 blur-xl"
      />
    </div>
  );
};

const AssignmentSkeleton: React.FC = () => (
  <div className="max-w-2xl mx-auto">
    <Skeleton className="h-10 w-48 mb-4" />
    <Skeleton className="h-3 w-full mb-4 rounded-full" />
    <div className="text-right mb-4">
      <Skeleton className="h-4 w-20 ml-auto" />
    </div>
    <div className="bg-card rounded-2xl border border-border p-6 sm:p-8 space-y-6">
      <div className="flex gap-2">
        <Skeleton className="h-6 w-16" />
        <Skeleton className="h-6 w-20" />
      </div>
      <Skeleton className="h-6 w-full" />
      <Skeleton className="h-6 w-3/4" />
      <div className="space-y-3">
        <Skeleton className="h-14 w-full rounded-xl" />
        <Skeleton className="h-14 w-full rounded-xl" />
        <Skeleton className="h-14 w-full rounded-xl" />
        <Skeleton className="h-14 w-full rounded-xl" />
      </div>
      <div className="flex justify-between">
        <Skeleton className="h-12 w-28" />
        <Skeleton className="h-12 w-28" />
      </div>
    </div>
  </div>
);

export default StudentAssignment;
