import { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Check, X, RotateCcw, Home,
  Lightbulb, Star, Sparkles, Clock,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { QUESTION_TYPE_LABELS } from '@shared/api.interface';
import type { Submission, Question } from '@shared/api.interface';
import { getSubmission } from '@/api';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import logoUrl from '@/assets/logo.png';
import { Image } from '@client/src/components/ui/image';
import Sticker from '@/components/Sticker';

const StudentResult: React.FC = () => {
  const { id = '' } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { playWin, playClick } = useSoundEffects();

  const [submission, setSubmission] = useState<Submission | null>(null);
  const [loading, setLoading] = useState(true);
  const [showContent, setShowContent] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    getSubmission(id)
      .then((data: Submission) => {
        setSubmission(data);
        // 延迟一下再播，等用户第一次交互后
        setTimeout(() => {
          playWin();
          setShowContent(true);
        }, 300);
      })
      .catch((err: unknown) => {
        logger.error('加载结果失败', err);
        toast.error('加载结果失败');
      })
      .finally(() => setLoading(false));
  }, [id, playWin]);

  const stats = useMemo(() => {
    if (!submission?.answers || !submission.questions) {
      return { correct: 0, total: 0, accuracy: 0 };
    }
    const total = submission.questions.length;
    const correct = submission.answers.filter(
      (a) => a.isCorrect === true,
    ).length;
    const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;
    return { correct, total, accuracy };
  }, [submission]);

  const scoreNum = useMemo(() => {
    if (!submission) return 0;
    const score = parseFloat(submission.autoScore);
    return isNaN(score) ? 0 : score;
  }, [submission]);

  if (loading) {
    return <ResultSkeleton />;
  }

  if (!submission) {
    return (
      <div className="text-center py-16">
        <p className="text-muted-foreground mb-4">未找到提交记录</p>
        <Button variant="outline" onClick={() => navigate('/student')}>
          <ArrowLeft size={16} /> 返回
        </Button>
      </div>
    );
  }

  const circumference = 2 * Math.PI * 80;
  const offset = circumference - (scoreNum / 100) * circumference;

  return (
    <div className="max-w-2xl mx-auto relative">
      {/* 背景撒星星 */}
      {!reducedMotion && <ConfettiStars />}

      {/* 返回 */}
      <div className="mb-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/student')} aria-label="返回">
          <ArrowLeft size={20} />
        </Button>
      </div>

      <AnimatePresence>
        {showContent && (
          <motion.div
            initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
          >
            {/* 提交成功提示条 */}
            <motion.div
              initial={reducedMotion ? { opacity: 0, y: -10 } : { opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.1 }}
              className="bg-status-correct/10 border border-status-correct/30 rounded-2xl p-3 mb-6 relative"
            >
              <div className="flex items-center gap-2">
                <div className="flex-1 text-center">
                  <div className="font-display text-xl sm:text-2xl text-foreground mb-1">
                    作业已提交 🎉
                  </div>
                  <div className="text-xs text-muted-foreground">
                    等可心老师批改后，就可以看到评语啦
                  </div>
                </div>
                <Sticker name="thanks" size={84} animation="bounce" />
              </div>
            </motion.div>

            {/* 标题 */}
            <div className="text-center mb-8">
              <motion.div
                initial={reducedMotion ? {} : { scale: 0, rotate: -8 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 0.3, type: 'spring', stiffness: 200 }}
                className="inline-block mb-2"
              >
                <Sticker
                  name={scoreNum >= 90 ? 'wow' : scoreNum >= 75 ? 'happy' : scoreNum >= 60 ? 'haode' : 'wronged'}
                  size={132}
                  animation="bounce"
                  delay={0.35}
                />
              </motion.div>
              <h1 className="font-display text-3xl sm:text-4xl text-foreground mb-2">
                {submission.studentName}同学，完成啦！
              </h1>
              <p className="text-muted-foreground">
                你真棒！来看看自己的表现吧 🌟
              </p>
            </div>

            {/* 得分圆环 */}
            <div className="bg-card rounded-2xl shadow-lg border border-border p-6 sm:p-8 mb-6 relative overflow-hidden">
              <div className="absolute top-4 right-4 opacity-10">
                <Image src={logoUrl} alt="" className="w-16 h-16" />
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-6">
                {/* 圆环 */}
                <div className="relative w-48 h-48 flex-shrink-0">
                  <svg width="192" height="192" className="transform -rotate-90">
                    <circle
                      cx="96"
                      cy="96"
                      r="80"
                      stroke="hsl(30 25% 88%)"
                      strokeWidth="16"
                      fill="none"
                    />
                    <motion.circle
                      cx="96"
                      cy="96"
                      r="80"
                      stroke={scoreNum >= 60 ? 'hsl(142 65% 50%)' : 'hsl(45 95% 58%)'}
                      strokeWidth="16"
                      fill="none"
                      strokeLinecap="round"
                      strokeDasharray={circumference}
                      initial={{ strokeDashoffset: circumference }}
                      animate={{ strokeDashoffset: reducedMotion ? offset : offset }}
                      transition={{ duration: reducedMotion ? 0 : 1.5, delay: 0.3, ease: 'easeOut' }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <motion.div
                      initial={{ opacity: 0, scale: 0.5 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.5, duration: 0.5 }}
                      className="text-center"
                    >
                      <div className={`font-display text-5xl tnum ${
                        scoreNum >= 60 ? 'text-status-correct' : 'text-warning'
                      }`}>
                        {scoreNum}
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">分</div>
                    </motion.div>
                  </div>
                </div>

                {/* 统计 */}
                <div className="flex-1 w-full space-y-4">
                  <div className="flex items-center justify-between p-3 rounded-xl bg-status-correct/10 border border-status-correct/20">
                    <div className="flex items-center gap-2">
                      <Check size={20} className="text-status-correct" />
                      <span>答对</span>
                    </div>
                    <span className="font-bold text-xl tnum text-status-correct">
                      {stats.correct} 题
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl bg-muted">
                    <div className="flex items-center gap-2">
                      <span className="w-5 text-center">📝</span>
                      <span>共</span>
                    </div>
                    <span className="font-bold text-xl tnum">
                      {stats.total} 题
                    </span>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-xl bg-warm-gold/10 border border-warning/20">
                    <div className="flex items-center gap-2">
                      <Sparkles size={20} className="text-warning" />
                      <span>正确率</span>
                    </div>
                    <span className="font-bold text-xl tnum text-warning-foreground">
                      {stats.accuracy}%
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* 逐题回顾 */}
            <div className="mb-6">
              <h2 className="font-display text-xl mb-4 flex items-center gap-2">
                📖 逐题回顾
              </h2>
              <div className="space-y-3">
                {submission.questions?.map((q: Question, idx: number) => {
                  const answer = submission.answers?.find(
                    (a) => a.questionId === q.id,
                  );
                  const isCorrect = answer?.isCorrect === true;
                  const isEssay = q.type === 'essay';
                  const studentAnswer = answer?.studentAnswer || '（未作答）';

                  return (
                    <motion.div
                      key={q.id}
                      initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 * idx, duration: 0.3 }}
                      className={`bg-card rounded-xl border-2 p-4 ${
                        isEssay
                          ? 'border-warning/40 bg-warning/[0.03]'
                          : isCorrect
                            ? 'border-status-correct/40 bg-status-correct/[0.03]'
                            : 'border-status-wrong/40 bg-status-wrong/[0.03]'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${
                          isEssay
                            ? 'bg-warning text-white'
                            : isCorrect ? 'bg-status-correct text-white' : 'bg-status-wrong text-white'
                        }`}>
                          {isEssay ? <Clock size={14} /> : isCorrect ? <Check size={16} /> : <X size={16} />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="secondary" className="text-xs">
                              {QUESTION_TYPE_LABELS[q.type]}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              第 {idx + 1} 题
                            </Badge>
                          </div>
                          <div className="font-medium mb-2">{q.title}</div>

                          <div className="space-y-1 text-sm">
                            <div className="flex gap-2">
                              <span className="text-muted-foreground shrink-0">你的答案：</span>
                              <span className={isEssay ? 'text-warning-foreground font-medium' : isCorrect ? 'text-status-correct font-medium' : 'text-status-wrong font-medium'}>
                                {formatAnswer(q.type, studentAnswer)}
                              </span>
                            </div>
                            {isEssay ? (
                              <div className="flex gap-2 items-center">
                                <span className="text-muted-foreground shrink-0">状态：</span>
                                <span className="inline-flex items-center gap-1 text-warning-foreground font-medium">
                                  <Clock size={14} /> 待老师批改
                                </span>
                              </div>
                            ) : !isCorrect && (
                              <div className="flex gap-2">
                                <span className="text-muted-foreground shrink-0">正确答案：</span>
                                <span className="text-status-correct font-medium">
                                  {formatAnswer(q.type, q.correctAnswer)}
                                </span>
                              </div>
                            )}
                            {q.explanation && (
                              <div className="mt-2 p-3 rounded-lg bg-accent/50 text-sm">
                                <span className="text-warning-foreground font-medium">💡 解析：</span>
                                {q.explanation}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* 底部按钮 */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                size="lg"
                className="flex-1 h-12"
                onClick={() => {
                  playClick();
                  navigate('/');
                }}
              >
                <Home size={18} /> 返回首页
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="flex-1 h-12"
                onClick={() => {
                  playClick();
                  navigate('/student');
                }}
              >
                <RotateCcw size={18} /> 再做一次
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="flex-1 h-12"
                onClick={() => {
                  playClick();
                  navigate('/student/knowledge');
                }}
              >
                <Lightbulb size={18} /> 查看知识点
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const formatAnswer = (type: string, answer: string): string => {
  if (type === 'true_false') {
    return answer === 'true' ? '✓ 正确' : answer === 'false' ? '✗ 错误' : answer;
  }
  if (type === 'multi_choice') {
    return answer.split(',').sort().join('、') || '（未作答）';
  }
  return answer;
};

const ConfettiStars: React.FC = () => {
  const stars = Array.from({ length: 15 });
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {stars.map((_, i) => {
        const left = Math.random() * 100;
        const delay = Math.random() * 2;
        const size = 12 + Math.random() * 16;
        const duration = 3 + Math.random() * 2;
        return (
          <motion.div
            key={i}
            className="absolute text-warm-gold"
            style={{
              left: `${left}%`,
              top: '-40px',
            }}
            animate={{
              y: ['0vh', '110vh'],
              rotate: [0, 360],
              opacity: [0, 1, 1, 0],
            }}
            transition={{
              duration,
              delay,
              repeat: Infinity,
              ease: 'linear',
            }}
          >
            <Star size={size} fill="currentColor" />
          </motion.div>
        );
      })}
    </div>
  );
};

const ResultSkeleton: React.FC = () => (
  <div className="max-w-2xl mx-auto">
    <Skeleton className="h-10 w-10 mb-4 rounded-full" />
    <div className="text-center mb-8">
      <Skeleton className="h-20 w-20 rounded-full mx-auto mb-4" />
      <Skeleton className="h-10 w-64 mx-auto mb-2" />
      <Skeleton className="h-5 w-48 mx-auto" />
    </div>
    <div className="bg-card rounded-2xl border border-border p-6 sm:p-8 mb-6">
      <div className="flex flex-col sm:flex-row items-center gap-6">
        <Skeleton className="w-48 h-48 rounded-full" />
        <div className="flex-1 w-full space-y-4">
          <Skeleton className="h-14 w-full rounded-xl" />
          <Skeleton className="h-14 w-full rounded-xl" />
          <Skeleton className="h-14 w-full rounded-xl" />
        </div>
      </div>
    </div>
    <Skeleton className="h-7 w-32 mb-4" />
    <div className="space-y-3">
      {[1, 2, 3].map((i) => (
        <Skeleton key={i} className="h-24 w-full rounded-xl" />
      ))}
    </div>
  </div>
);

export default StudentResult;
