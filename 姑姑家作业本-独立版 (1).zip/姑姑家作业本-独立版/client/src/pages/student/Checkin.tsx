import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Mic2, Square, Play, Pause,
  RotateCcw, Send, CheckCircle, Clock,
  FileText,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { SUBJECT_LABELS, SUBJECT_EMOJIS } from '@shared/api.interface';
import type { CheckinTask } from '@shared/api.interface';
import { getCheckinTaskByCode, submitCheckin } from '@/api';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import logoUrl from '@/assets/logo.png';
import Sticker from '@/components/Sticker';

const StudentCheckin: React.FC = () => {
  const { code = '' } = useParams<{ code: string }>();
  const navigate = useNavigate();
  const { playClick, playCorrect } = useSoundEffects();

  const [task, setTask] = useState<CheckinTask | null>(null);
  const [loading, setLoading] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string>('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [note, setNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [alreadySubmitted, setAlreadySubmitted] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [searchParams] = useSearchParams();

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const studentName = searchParams.get('name') || '';

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    if (!code) return;
    if (!studentName) {
      navigate('/student/checkin');
      return;
    }
    setLoading(true);
    getCheckinTaskByCode(code)
      .then((data: CheckinTask) => setTask(data))
      .catch((err: unknown) => {
        logger.error('加载打卡任务失败', err);
        toast.error('任务加载失败');
      })
      .finally(() => setLoading(false));
  }, [code, studentName, navigate]);

  // 音频播放结束
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const onEnded = () => setIsPlaying(false);
    audio.addEventListener('ended', onEnded);
    return () => audio.removeEventListener('ended', onEnded);
  }, [audioUrl]);

  const formatTime = (sec: number): string => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
          setAudioUrl(reader.result as string);
        };
        // 停止所有轨道
        streamRef.current?.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      };

      mediaRecorder.start();
      setIsRecording(true);
      setDuration(0);
      setAudioUrl('');

      // 计时
      timerRef.current = window.setInterval(() => {
        setDuration((prev) => prev + 1);
      }, 1000);

      playClick();
    } catch (err: unknown) {
      logger.error('无法获取麦克风权限', err);
      toast.error('无法获取麦克风权限，请检查浏览器设置');
    }
  }, [playClick]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      playClick();
    }
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, [isRecording, playClick]);

  const togglePlay = () => {
    if (!audioUrl || !audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().catch((err: unknown) => {
        logger.error('播放失败', err);
      });
      setIsPlaying(true);
    }
    playClick();
  };

  const reRecord = () => {
    setAudioUrl('');
    setDuration(0);
    setIsPlaying(false);
    playClick();
  };

  const handleSubmit = async () => {
    if (!task) return;
    if (!audioUrl) {
      toast.error('请先录制一段音频哦');
      return;
    }
    if (duration < 2) {
      toast.error('录音时间太短啦，至少录 2 秒吧');
      return;
    }

    setSubmitting(true);
    try {
      await submitCheckin({
        taskId: task.id,
        studentName,
        audioUrl,
        note: note.trim(),
      });
      playCorrect();
      setSubmitted(true);
    } catch (err: unknown) {
      logger.error('提交打卡失败', err);
      const msg = (err as { response?: { data?: { error?: { message?: string } } } })?.response?.data?.error?.message;
      if (msg && (msg.includes('已提交') || msg.includes('重复'))) {
        setAlreadySubmitted(true);
      } else {
        toast.error(msg || '提交失败，请稍后再试');
      }
    } finally {
      setSubmitting(false);
    }
  };

  // 清理
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      streamRef.current?.getTracks().forEach((track) => track.stop());
    };
  }, []);

  if (loading) {
    return <CheckinSkeleton />;
  }

  if (!task) {
    return (
      <div className="text-center py-16">
        <p className="text-muted-foreground mb-4">任务不存在</p>
        <Button variant="outline" onClick={() => navigate('/student/checkin')}>
          <ArrowLeft size={16} /> 返回
        </Button>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="max-w-md mx-auto">
        <motion.div
          initial={reducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          className="bg-card rounded-2xl shadow-lg border border-border p-8 text-center relative overflow-hidden"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            className="flex justify-center mx-auto mb-3"
          >
            <Sticker name="thanks" size={132} animation="bounce" />
          </motion.div>

          <h1 className="font-display text-2xl sm:text-3xl mb-2">打卡成功 🎉</h1>
          <p className="text-muted-foreground mb-6">
            已提交给可心老师，等待点评～
          </p>

          <div className="bg-accent/30 rounded-xl p-4 mb-6 text-left">
            <div className="text-sm text-muted-foreground mb-1">提交内容：</div>
            <div className="font-medium">{task.title}</div>
            <div className="text-sm text-muted-foreground mt-1">
              {studentName} 同学 · 时长 {formatTime(duration)}
              {note && ` · 有备注`}
            </div>
          </div>

          <div className="space-y-3">
            <Button
              variant="outline"
              className="w-full h-12"
              onClick={() => navigate('/')}
            >
              返回首页
            </Button>
          </div>

          <div className="mt-6">
            <span className="teacher-seal text-[10px]">可心老师</span>
          </div>
        </motion.div>
      </div>
    );
  }

  if (alreadySubmitted) {
    return (
      <div className="max-w-md mx-auto py-16">
        <motion.div
          initial={reducedMotion ? { opacity: 0 } : { opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          className="bg-card rounded-2xl shadow-lg border border-border p-8 text-center"
        >
          <div className="w-20 h-20 rounded-full bg-warm-gold/20 flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={40} className="text-warning" />
          </div>
          <h1 className="font-display text-2xl sm:text-3xl mb-2">你已经打过卡啦</h1>
          <p className="text-muted-foreground mb-6">
            {studentName} 同学，今天的打卡你已经提交过了哦～
            <br />
            等可心老师点评吧
          </p>
          <div className="space-y-3">
            <Button
              className="w-full h-12"
              onClick={() => navigate('/')}
            >
              返回首页
            </Button>
          </div>
          <div className="mt-6">
            <span className="teacher-seal text-[10px]">可心老师</span>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto">
      {/* 返回 + 标题 */}
      <div className="flex items-center gap-3 mb-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/student/checkin')} aria-label="返回">
          <ArrowLeft size={20} />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="font-display text-xl sm:text-2xl truncate">{task.title}</div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Badge variant="secondary" className="text-xs">
              {SUBJECT_EMOJIS[task.subject]} {SUBJECT_LABELS[task.subject]}
            </Badge>
            <Badge variant="default" className="text-xs">
              录音打卡
            </Badge>
          </div>
        </div>
      </div>

      {/* 要求说明 */}
      <div className="bg-card rounded-2xl border border-border p-5 mb-6 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <FileText size={18} className="text-primary" />
          <span className="font-medium">打卡要求</span>
        </div>
        <div className="text-foreground/90 whitespace-pre-wrap leading-relaxed">
          {task.requirement}
        </div>
      </div>

      {/* 录音区 */}
      <motion.div
        className={`bg-card rounded-2xl border-2 p-6 mb-6 shadow-sm ${
          isRecording ? 'border-destructive' : 'border-border'
        }`}
        animate={isRecording && !reducedMotion
          ? { boxShadow: ['0 4px 16px hsl(355 78% 62% / 0.2)', '0 4px 24px hsl(355 78% 62% / 0.3)', '0 4px 16px hsl(355 78% 62% / 0.2)'] }
          : {}}
        transition={isRecording ? { duration: 1.5, repeat: Infinity } : {}}
      >
        {/* 录音按钮 */}
        <div className="flex flex-col items-center">
          {!audioUrl && (
            <motion.button
              whileTap={!reducedMotion ? { scale: 0.95 } : {}}
              onClick={isRecording ? stopRecording : startRecording}
              className={`w-24 h-24 rounded-full flex items-center justify-center mb-4 transition-all ${
                isRecording
                  ? 'bg-destructive text-white'
                  : 'bg-primary text-primary-foreground hover:bg-primary/90'
              } shadow-lg btn-bounce`}
              aria-label={isRecording ? '停止录音' : '开始录音'}
            >
              {isRecording ? (
                <Square size={32} fill="currentColor" />
              ) : (
                <Mic2 size={36} />
              )}
            </motion.button>
          )}

          {audioUrl && !isRecording && (
            <div className="w-full">
              <div className="flex items-center justify-center gap-4 mb-4">
                <motion.button
                  whileTap={!reducedMotion ? { scale: 0.9 } : {}}
                  onClick={togglePlay}
                  className="w-16 h-16 rounded-full bg-status-correct text-white flex items-center justify-center shadow-md btn-bounce"
                  aria-label={isPlaying ? '暂停' : '播放'}
                >
                  {isPlaying ? <Pause size={24} /> : <Play size={24} className="ml-1" />}
                </motion.button>
              </div>
              <audio ref={audioRef} src={audioUrl} className="hidden" />
            </div>
          )}

          {/* 时长显示 */}
          <div className="flex items-center gap-2 text-lg font-mono tnum text-foreground mb-4">
            <Clock size={18} className={isRecording ? 'text-destructive animate-pulse' : 'text-muted-foreground'} />
            {formatTime(duration)}
          </div>

          {/* 波形动画（录音中） */}
          {isRecording && <WaveformAnimation />}

          {/* 已录完 - 播放波形显示 */}
          {audioUrl && !isRecording && (
            <div className="flex items-center justify-center gap-1 h-12 mb-4">
              {Array.from({ length: 24 }).map((_, i) => (
                <motion.div
                  key={i}
                  className="w-1.5 bg-status-correct rounded-full"
                  animate={isPlaying && !reducedMotion
                    ? { height: [8, 20 + Math.random() * 20, 8] }
                    : { height: 12 }}
                  transition={{
                    duration: 0.5,
                    repeat: isPlaying ? Infinity : 0,
                    delay: i * 0.03,
                    ease: 'easeInOut',
                  }}
                />
              ))}
            </div>
          )}

          {/* 操作按钮 */}
          {audioUrl && !isRecording && (
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={reRecord}
                className="flex-1 h-10"
              >
                <RotateCcw size={16} /> 重录
              </Button>
            </div>
          )}

          {!audioUrl && (
            <p className="text-sm text-muted-foreground text-center">
              {isRecording ? '正在录音...点击按钮停止' : '点击大按钮开始录音'}
            </p>
          )}
        </div>
      </motion.div>

      {/* 备注 */}
      <div className="mb-6">
        <label className="text-sm font-medium text-foreground mb-2 block">
          备注（选填）
        </label>
        <Textarea
          placeholder="有什么想跟可心老师说的..."
          value={note}
          onChange={(e) => setNote(e.target.value)}
          className="min-h-[100px]"
          maxLength={500}
        />
        <div className="text-right text-xs text-muted-foreground mt-1 tnum">
          {note.length}/500
        </div>
      </div>

      {/* 提交按钮 */}
      <Button
        size="lg"
        className="w-full h-14 text-lg font-medium"
        onClick={handleSubmit}
        disabled={submitting || !audioUrl}
      >
        {submitting ? '提交中...' : (
          <>
            <Send size={20} />
            提交打卡
          </>
        )}
      </Button>

      {studentName && (
        <p className="text-center text-sm text-muted-foreground mt-3">
          当前同学：{studentName}
        </p>
      )}
    </div>
  );
};

const WaveformAnimation: React.FC = () => (
  <div className="flex items-center justify-center gap-1 h-12 mb-4">
    {Array.from({ length: 20 }).map((_, i) => (
      <motion.div
        key={i}
        className="w-1.5 bg-destructive rounded-full"
        animate={{ height: [10, 30 + Math.random() * 15, 10] }}
        transition={{
          duration: 0.6 + Math.random() * 0.4,
          repeat: Infinity,
          delay: i * 0.05,
          ease: 'easeInOut',
        }}
      />
    ))}
  </div>
);

const CheckinSkeleton: React.FC = () => (
  <div className="max-w-xl mx-auto">
    <div className="flex items-center gap-3 mb-4">
      <Skeleton className="h-10 w-10 rounded-full" />
      <div>
        <Skeleton className="h-6 w-48 mb-1" />
        <Skeleton className="h-4 w-32" />
      </div>
    </div>
    <Skeleton className="h-32 w-full rounded-2xl mb-6" />
    <Skeleton className="h-64 w-full rounded-2xl mb-6" />
    <Skeleton className="h-14 w-full rounded-xl" />
  </div>
);

export default StudentCheckin;
