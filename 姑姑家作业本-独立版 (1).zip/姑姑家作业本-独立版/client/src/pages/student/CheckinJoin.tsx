import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Mic2, Sparkles } from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import { getCheckinTaskByCode } from '@/api';
import logoUrl from '@/assets/logo.png';
import { Image } from '@client/src/components/ui/image';

const StudentCheckinJoin: React.FC = () => {
  const navigate = useNavigate();
  const { playClick } = useSoundEffects();
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [rememberName, setRememberName] = useState(true);
  const [loading, setLoading] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem('studentName');
    if (saved) {
      setName(saved);
      setRememberName(true);
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    playClick();

    if (!code.trim()) {
      toast.error('请输入打卡访问码');
      return;
    }
    if (!name.trim()) {
      toast.error('请输入你的姓名');
      return;
    }
    if (name.trim().length > 20) {
      toast.error('姓名最多 20 个字哦');
      return;
    }
    if (!/^[A-Za-z0-9]{4,20}$/.test(code.trim())) {
      toast.error('访问码是 4-20 位字母或数字哦');
      return;
    }

    setLoading(true);
    try {
      await getCheckinTaskByCode(code.trim());
      if (rememberName) {
        localStorage.setItem('studentName', name.trim());
      } else {
        localStorage.removeItem('studentName');
      }
      navigate(`/student/checkin/${code.trim()}?name=${encodeURIComponent(name.trim())}`);
    } catch (err: unknown) {
      logger.error('进入打卡失败', err);
      const msg = (err as { response?: { data?: { error?: { message?: string } } } })?.response?.data?.error?.message;
      toast.error(msg || '访问码不对哦，再检查一下吧～');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-10rem)] flex items-center justify-center py-8">
      <motion.div
        initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="w-full max-w-md"
      >
        <div className="bg-card rounded-2xl shadow-lg border border-border p-6 sm:p-8 relative overflow-hidden">
          {/* 装饰 */}
          {!reducedMotion && (
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute top-6 right-6 text-destructive"
            >
              <Mic2 size={28} fill="currentColor" />
            </motion.div>
          )}

          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-destructive/10 mb-4">
              <Image src={logoUrl} alt="姑姑家" className="w-14 h-14 object-contain" />
            </div>
            <h1 className="font-display text-3xl sm:text-4xl text-foreground mb-2">
              打卡任务
            </h1>
            <p className="text-muted-foreground text-base">
              输入打卡访问码，开始今天的练习吧！
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                打卡访问码
              </label>
              <Input
                type="text"
                autoCapitalize="characters"
                maxLength={20}
                placeholder="请输入访问码"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                className="h-14 text-2xl font-mono tnum text-center tracking-widest"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                你的姓名
              </label>
              <Input
                type="text"
                maxLength={20}
                placeholder="请输入你的姓名"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-12 text-lg"
              />
            </div>

            <label className="flex items-center gap-2 cursor-pointer select-none text-sm text-muted-foreground">
              <input
                type="checkbox"
                checked={rememberName}
                onChange={(e) => setRememberName(e.target.checked)}
                className="w-4 h-4 rounded border-border text-primary focus:ring-primary accent-primary"
              />
              记住我的名字
            </label>

            <Button
              type="submit"
              size="lg"
              variant="destructive"
              className="w-full h-14 text-lg font-medium btn-bounce"
              disabled={loading}
            >
              {loading ? '正在验证...' : (
                <>
                  <Mic2 size={20} />
                  进入打卡
                </>
              )}
            </Button>
          </form>

          <div className="mt-6 pt-6 border-t border-border">
            <Link
              to="/student"
              onClick={playClick}
              className="flex items-center justify-center gap-2 text-muted-foreground hover:text-primary transition-colors"
            >
              <ArrowLeft size={16} />
              返回作业入口
            </Link>
          </div>

          <div className="mt-4 text-center">
            <span className="teacher-seal text-[10px]">可心老师</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default StudentCheckinJoin;
