import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft, BookOpen, Mic2, Clock, CheckCircle2,
  ChevronDown, ChevronUp, Sparkles, Lightbulb,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { SUBJECT_LABELS, SUBJECT_EMOJIS } from '@shared/api.interface';
import { portalTasks, type PortalTask, type PortalTaskboard } from '@/api';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import Sticker from '@/components/Sticker';
import { useSoundEffects } from '@/hooks/useSoundEffects';

function formatDeadline(value: string | null): string {
  if (!value) return '不限时间';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '不限时间';
  const now = Date.now();
  const md = `${d.getMonth() + 1}月${d.getDate()}日`;
  const hh = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  if (d.getTime() < now) return `已截止 ${md}`;
  const today = new Date();
  if (d.toDateString() === today.toDateString()) return `今天 ${hh} 前`;
  return `${md} ${hh} 前`;
}

const StudentHome: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { playClick } = useSoundEffects();
  const name = (searchParams.get('name') || localStorage.getItem('studentName') || '').trim();

  const [board, setBoard] = useState<PortalTaskboard | null>(null);
  const [loading, setLoading] = useState(true);
  const [showDone, setShowDone] = useState(false);

  useEffect(() => {
    if (!name) {
      navigate('/student', { replace: true });
      return;
    }
    localStorage.setItem('studentName', name);
    portalTasks(name)
      .then(setBoard)
      .catch((err: unknown) => {
        logger.error('加载任务清单失败', err);
        toast.error('清单没拉下来，退回首页重试一下');
      })
      .finally(() => setLoading(false));
  }, [name, navigate]);

  const openTask = (task: PortalTask) => {
    playClick();
    if (task.kind === 'assignment') {
      navigate(`/student/assignment/${task.accessCode}?name=${encodeURIComponent(name)}`);
    } else {
      navigate(`/student/checkin/${task.accessCode}?name=${encodeURIComponent(name)}`);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4 py-6">
        <Skeleton className="h-36 w-full rounded-2xl" />
        <Skeleton className="h-24 w-full rounded-2xl" />
        <Skeleton className="h-24 w-full rounded-2xl" />
      </div>
    );
  }

  const pending = board?.items.filter((i) => !i.done) ?? [];
  const done = board?.items.filter((i) => i.done) ?? [];

  return (
    <div className="space-y-6 py-6">
      <button
        type="button"
        onClick={() => navigate('/student')}
        className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft size={16} />
        换个名字 / 重新进
      </button>

      {/* 问候卡 */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="relative overflow-hidden rounded-2xl bg-card border border-border shadow-sm p-5 min-h-[152px]"
      >
        <div className="pr-28">
          <div className="text-sm text-muted-foreground">我的小书房</div>
          <h1 className="font-display text-2xl text-foreground mt-1">
            {name}，{pending.length > 0 ? `还有 ${pending.length} 个任务` : '今天都做完啦'}
          </h1>
          <p className="text-sm text-muted-foreground mt-2">
            {pending.length > 0
              ? '做完一个就打个勾，慢慢来～'
              : '真棒，休息一下，或者去看看知识点吧。'}
          </p>
        </div>
        <div className="absolute right-3 bottom-0">
          <Sticker
            name={pending.length > 0 ? 'happy' : 'thanks'}
            size={104}
            animation={pending.length > 0 ? 'bounce' : 'float'}
          />
        </div>
      </motion.div>

      {/* 待完成 */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg text-foreground flex items-center gap-2">
            <Clock size={18} className="text-primary" />
            待完成
          </h2>
          <span className="text-sm text-muted-foreground tnum">{pending.length} 个</span>
        </div>

        {pending.length === 0 ? (
          <div className="rounded-2xl border border-border bg-card p-8 text-center relative overflow-hidden">
            <div className="flex justify-center">
              <Sticker name="daze" size={120} animation="float" />
            </div>
            <p className="mt-2 text-muted-foreground text-sm">老师还没布置新任务，等着就好～</p>
          </div>
        ) : (
          <div className="space-y-3">
            {pending.map((task) => (
              <TaskCard key={task.id} task={task} onOpen={() => openTask(task)} />
            ))}
          </div>
        )}
      </div>

      {/* 已完成 */}
      {done.length > 0 && (
        <div className="space-y-3">
          <button
            type="button"
            onClick={() => {
              playClick();
              setShowDone((v) => !v);
            }}
            className="w-full flex items-center justify-between px-1"
          >
            <h2 className="font-display text-lg text-foreground flex items-center gap-2">
              <CheckCircle2 size={18} className="text-[hsl(142_65%_42%)]" />
              已完成
            </h2>
            <span className="text-sm text-muted-foreground flex items-center gap-1 tnum">
              {done.length} 个
              {showDone ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </span>
          </button>

          {showDone && (
            <div className="space-y-3">
              {done.map((task) => (
                <TaskCard key={task.id} task={task} dim onOpen={() => openTask(task)} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* 知识点入口 */}
      <Link
        to="/student/knowledge"
        onClick={playClick}
        className="flex items-center gap-3 p-4 rounded-2xl bg-card border border-border hover:bg-accent/40 transition-colors"
      >
        <div className="w-10 h-10 rounded-xl bg-warm-gold/20 text-warning flex items-center justify-center flex-shrink-0">
          <Lightbulb size={20} />
        </div>
        <div className="flex-1">
          <div className="font-medium text-foreground">知识点学习</div>
          <div className="text-xs text-muted-foreground">看看有趣的知识点</div>
        </div>
        <Sparkles size={16} className="text-muted-foreground" />
      </Link>
    </div>
  );
};

const TaskCard: React.FC<{ task: PortalTask; onOpen: () => void; dim?: boolean }> = ({
  task,
  onOpen,
  dim,
}) => {
  const isCheckin = task.kind === 'checkin';
  const emoji = SUBJECT_EMOJIS[task.subject as keyof typeof SUBJECT_EMOJIS] ?? '📘';
  const subjectLabel = SUBJECT_LABELS[task.subject as keyof typeof SUBJECT_LABELS] ?? task.subject;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl border border-border bg-card p-4 shadow-sm ${
        dim ? 'opacity-70' : ''
      }`}
    >
      <div className="flex items-start gap-3">
        <div
          className={`h-11 w-11 rounded-xl flex items-center justify-center text-xl flex-shrink-0 ${
            isCheckin ? 'bg-destructive/10' : 'bg-primary/10'
          }`}
        >
          {isCheckin ? <Mic2 size={20} className="text-destructive" /> : emoji}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium text-foreground truncate">{task.title}</span>
            <Badge variant="secondary" className="rounded-full text-[11px] px-2 py-0.5">
              {isCheckin ? '打卡' : '作业'}
            </Badge>
          </div>
          <div className="mt-1 text-xs text-muted-foreground flex items-center gap-2 flex-wrap">
            <span>{subjectLabel}</span>
            <span className="text-border">·</span>
            <span className={task.deadline && new Date(task.deadline).getTime() < Date.now() ? 'text-destructive' : ''}>
              {formatDeadline(task.deadline)}
            </span>
            {task.done && task.score && (
              <>
                <span className="text-border">·</span>
                <span className="text-[hsl(142_65%_38%)] tnum">得分 {task.score}</span>
              </>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={onOpen}
          className={`flex-shrink-0 self-center rounded-full px-4 h-9 text-sm font-medium transition-colors ${
            task.done
              ? 'border border-border text-muted-foreground hover:text-foreground'
              : 'bg-primary text-primary-foreground hover:opacity-90'
          }`}
        >
          {task.done ? '再做一次' : isCheckin ? '去打卡' : '开始做'}
        </button>
      </div>
    </motion.div>
  );
};

export default StudentHome;
