import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, BookOpen, Image, Video, FileText,
  Lightbulb, Search, X,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import {
  SUBJECTS, SUBJECT_LABELS, SUBJECT_EMOJIS,
  KNOWLEDGE_TYPES, KNOWLEDGE_TYPE_LABELS,
} from '@shared/api.interface';
import type { KnowledgePoint, KnowledgeType, Subject } from '@shared/api.interface';
import { listKnowledge } from '@/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import { Image as UIImage } from '@client/src/components/ui/image';

const TYPE_ICONS: Record<KnowledgeType, React.FC<{ size?: number }>> = {
  text: FileText,
  image: Image,
  video: Video,
};

const StudentKnowledge: React.FC = () => {
  const navigate = useNavigate();
  const { playClick } = useSoundEffects();

  const [items, setItems] = useState<KnowledgePoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [subject, setSubject] = useState<Subject | 'all'>('all');
  const [type, setType] = useState<KnowledgeType | 'all'>('all');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<KnowledgePoint | null>(null);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subject, type]);

  const loadData = async () => {
    setLoading(true);
    try {
      const params: { subject?: Subject; contentType?: KnowledgeType; pageSize: number } = {
        pageSize: 50,
      };
      if (subject !== 'all') params.subject = subject;
      if (type !== 'all') params.contentType = type;
      const result = await listKnowledge(params);
      setItems(result.items);
    } catch (err: unknown) {
      logger.error('加载知识点失败', err);
      toast.error('加载失败');
    } finally {
      setLoading(false);
    }
  };

  const filteredItems = useMemo(() => {
    if (!search.trim()) return items;
    const q = search.toLowerCase();
    return items.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q),
    );
  }, [items, search]);

  const typeTabs: { key: KnowledgeType | 'all'; label: string; icon: React.FC<{ size?: number }> }[] = [
    { key: 'all', label: '全部', icon: Lightbulb },
    ...KNOWLEDGE_TYPES.map((t) => ({
      key: t,
      label: KNOWLEDGE_TYPE_LABELS[t],
      icon: TYPE_ICONS[t],
    })),
  ];

  return (
    <div className="max-w-4xl mx-auto">
      {/* 顶部 */}
      <div className="flex items-center gap-3 mb-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/student')} aria-label="返回">
          <ArrowLeft size={20} />
        </Button>
        <h1 className="font-display text-2xl sm:text-3xl">知识点学习</h1>
      </div>

      {/* 学科筛选 - 横滚 tab */}
      <div className="flex gap-2 overflow-x-auto pb-2 mb-4 -mx-4 px-4 sm:mx-0 sm:px-0">
        <motion.button
          whileTap={!reducedMotion ? { scale: 0.95 } : {}}
          onClick={() => { playClick(); setSubject('all'); }}
          className={`shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all ${
            subject === 'all'
              ? 'bg-primary text-primary-foreground shadow-sm'
              : 'bg-card border border-border text-foreground hover:border-primary/50'
          }`}
        >
          全部学科
        </motion.button>
        {SUBJECTS.map((s) => (
          <motion.button
            key={s}
            whileTap={!reducedMotion ? { scale: 0.95 } : {}}
            onClick={() => { playClick(); setSubject(s); }}
            className={`shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all ${
              subject === s
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'bg-card border border-border text-foreground hover:border-primary/50'
            }`}
          >
            <span className="mr-1">{SUBJECT_EMOJIS[s]}</span>
            {SUBJECT_LABELS[s]}
          </motion.button>
        ))}
      </div>

      {/* 类型筛选 + 搜索 */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex gap-1 flex-wrap">
          {typeTabs.map((tab) => {
            const Icon = tab.icon;
            const active = type === tab.key;
            return (
              <motion.button
                key={tab.key}
                whileTap={!reducedMotion ? { scale: 0.95 } : {}}
                onClick={() => { playClick(); setType(tab.key); }}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  active
                    ? 'bg-accent text-accent-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
                }`}
              >
                <Icon size={14} />
                {tab.label}
              </motion.button>
            );
          })}
        </div>
        <div className="flex-1">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="搜索知识点..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 h-10"
            />
          </div>
        </div>
      </div>

      {/* 卡片网格 */}
      {loading ? (
        <KnowledgeSkeleton />
      ) : filteredItems.length === 0 ? (
        <div className="text-center py-16 bg-card rounded-2xl border border-border">
          <div className="w-16 h-16 rounded-full bg-accent/50 flex items-center justify-center mx-auto mb-4">
            <BookOpen size={28} className="text-muted-foreground" />
          </div>
          <p className="text-muted-foreground mb-2">暂无知识点</p>
          <p className="text-sm text-muted-foreground/70">
            换个筛选条件试试吧～
          </p>
        </div>
      ) : (
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          <AnimatePresence>
            {filteredItems.map((item, idx) => (
              <motion.div
                key={item.id}
                initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05, duration: 0.3 }}
                whileHover={!reducedMotion ? { y: -4 } : {}}
                onClick={() => { playClick(); setSelected(item); }}
                className="bg-card rounded-xl border border-border overflow-hidden cursor-pointer card-hover"
              >
                {/* 封面 */}
                <div className="aspect-video bg-accent/30 relative overflow-hidden">
                  {item.coverUrl ? (
                    <UIImage
                      src={item.coverUrl}
                      alt={item.title}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-4xl">
                      {SUBJECT_EMOJIS[item.subject]}
                    </div>
                  )}
                  <Badge
                    variant="default"
                    className="absolute top-2 left-2 text-xs"
                  >
                    {KNOWLEDGE_TYPE_LABELS[item.contentType]}
                  </Badge>
                </div>

                {/* 内容 */}
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm">{SUBJECT_EMOJIS[item.subject]}</span>
                    <span className="text-xs text-muted-foreground">
                      {SUBJECT_LABELS[item.subject]}
                    </span>
                  </div>
                  <h3 className="font-medium text-foreground mb-1 line-clamp-1">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {item.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      )}

      {/* 详情弹窗 */}
      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          {selected && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="default" className="text-xs">
                    {KNOWLEDGE_TYPE_LABELS[selected.contentType]}
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    {SUBJECT_EMOJIS[selected.subject]} {SUBJECT_LABELS[selected.subject]}
                  </Badge>
                </div>
                <DialogTitle className="font-display text-xl">
                  {selected.title}
                </DialogTitle>
                <DialogDescription>
                  {selected.description}
                </DialogDescription>
              </DialogHeader>

              <div className="mt-2">
                {selected.contentType === 'text' && (
                  <div className="prose prose-sm max-w-none p-4 bg-accent/20 rounded-xl">
                    <p className="whitespace-pre-wrap text-foreground leading-relaxed">
                      {selected.contentText}
                    </p>
                  </div>
                )}

                {selected.contentType === 'image' && (
                  <div className="rounded-xl overflow-hidden">
                    {selected.attachmentUrl ? (
                      <UIImage
                        src={selected.attachmentUrl}
                        alt={selected.title}
                        className="w-full h-auto"
                      />
                    ) : (
                      <div className="aspect-video bg-accent/30 flex items-center justify-center text-muted-foreground">
                        <Image size={48} />
                      </div>
                    )}
                  </div>
                )}

                {selected.contentType === 'video' && (
                  <div className="rounded-xl overflow-hidden bg-black">
                    {selected.attachmentUrl ? (
                      <video
                        src={selected.attachmentUrl}
                        controls
                        className="w-full"
                      />
                    ) : (
                      <div className="aspect-video bg-accent/30 flex items-center justify-center text-muted-foreground">
                        <Video size={48} />
                      </div>
                    )}
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

const KnowledgeSkeleton: React.FC = () => (
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
    {[1, 2, 3, 4, 5, 6].map((i) => (
      <div key={i} className="bg-card rounded-xl border border-border overflow-hidden">
        <Skeleton className="aspect-video w-full" />
        <div className="p-4 space-y-2">
          <Skeleton className="h-4 w-20" />
          <Skeleton className="h-5 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-2/3" />
        </div>
      </div>
    ))}
  </div>
);

export default StudentKnowledge;
