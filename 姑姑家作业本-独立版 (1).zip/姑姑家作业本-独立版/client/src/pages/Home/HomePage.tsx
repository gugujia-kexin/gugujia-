import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { GraduationCap, BookOpen, Users } from 'lucide-react';
import logoUrl from '@/assets/logo.png';
import { Image } from '@client/src/components/ui/image';

const entries = [
  {
    to: '/student',
    icon: BookOpen,
    title: '学生入口',
    desc: '输班级码，做作业、打卡',
    primary: true,
  },
  {
    to: '/teacher',
    icon: GraduationCap,
    title: '老师入口',
    desc: '布置作业、批改点评、管理家长',
    primary: false,
  },
  {
    to: '/parent',
    icon: Users,
    title: '家长入口',
    desc: '看孩子的作业成绩和评语',
    primary: false,
  },
];

const HomePage = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="float mb-6"
      >
        <Image
          src={logoUrl}
          alt="姑姑家 Auntie's Home"
          className="h-24 sm:h-32 w-auto mx-auto"
        />
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="font-display text-4xl sm:text-5xl text-foreground mb-2"
      >
        姑姑家
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="text-base text-muted-foreground mb-10"
      >
        可心老师的线上小书房
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="flex flex-col gap-4 w-full max-w-sm"
      >
        {entries.map((e, i) => (
          <Link
            key={e.to}
            to={e.to}
            className={`card-hover flex items-center gap-4 rounded-2xl p-5 text-left shadow-sm btn-bounce ${
              e.primary
                ? 'bg-primary text-primary-foreground shadow-md'
                : 'bg-card border-2 border-border'
            }`}
            style={{ animationDelay: `${0.1 * i}s` }}
          >
            <e.icon size={34} className={e.primary ? '' : 'text-primary'} />
            <span className="min-w-0">
              <span className="block font-display text-xl mb-0.5">{e.title}</span>
              <span className={`block text-sm ${e.primary ? 'opacity-90' : 'text-muted-foreground'}`}>
                {e.desc}
              </span>
            </span>
          </Link>
        ))}
      </motion.div>
    </div>
  );
};

export default HomePage;
