import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Plus,
  Pencil,
  Trash2,
  ClipboardList,
  Copy,
  Eye,
  Calendar as CalendarDays,
  Users,
  AlertTriangle,
  RefreshCw,
  Lock,
  Unlock,
  Clock,
  MoreHorizontal,
  X,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import * as api from '@/api';
import { getApiErrorMessage } from '@/lib/api-error';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Badge } from '@client/src/components/ui/badge';
import { Skeleton } from '@client/src/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@client/src/components/ui/dropdown-menu';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import { Calendar } from '@client/src/components/ui/calendar';
import {
  SUBJECTS,
  SUBJECT_LABELS,
  SUBJECT_EMOJIS,
  type Subject,
  type Assignment,
} from '@shared/api.interface';

const subjectColor: Record<Subject, string> = {
  chinese: 'bg-[hsl(16_85%_62%)]/15 text-[hsl(16_85%_45%)]',
  math: 'bg-[hsl(220_70%_60%)]/15 text-[hsl(220_70%_45%)]',
  english: 'bg-[hsl(45_95%_50%)]/20 text-[hsl(45_95%_40%)]',
  physics: 'bg-[hsl(260_65%_60%)]/15 text-[hsl(260_65%_45%)]',
  chemistry: 'bg-[hsl(142_65%_50%)]/15 text-[hsl(142_65%_40%)]',
  biology: 'bg-[hsl(145_55%_50%)]/15 text-[hsl(145_55%_40%)]',
  geography: 'bg-[hsl(195_70%_55%)]/15 text-[hsl(195_70%_45%)]',
  history: 'bg-[hsl(30_65%_55%)]/15 text-[hsl(30_65%_40%)]',
  politics: 'bg-[hsl(355_78%_62%)]/15 text-[hsl(355_78%_45%)]',
};

const AssignmentsSkeleton = () => (
  <div className="space-y-6">
    <div className="flex items-center justify-between">
      <Skeleton className="h-9 w-32" />
      <Skeleton className="h-9 w-28" />
    </div>
    <div className="flex gap-3">
      <Skeleton className="h-9 w-32" />
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="rounded-2xl border p-5 space-y-3">
          <div className="flex items-center justify-between">
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-5 w-14 rounded-full" />
          </div>
          <div className="space-y-2 pt-2">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-4 w-28" />
          </div>
          <div className="flex gap-2 pt-3 border-t border-border">
            <Skeleton className="h-7 w-7 rounded-md flex-1" />
            <Skeleton className="h-7 w-7 rounded-md flex-1" />
            <Skeleton className="h-7 w-7 rounded-md flex-1" />
          </div>
        </div>
      ))}
    </div>
  </div>
);

const formatDeadline = (deadline: string | null): string => {
  if (!deadline) return '';
  const date = new Date(deadline);
  return `${date.getFullYear()}/${String(date.getMonth() + 1).padStart(2, '0')}/${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
};

const TeacherAssignments: React.FC = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [regenerateId, setRegenerateId] = useState<string | null>(null);
  const [deadlinePickerId, setDeadlinePickerId] = useState<string | null>(null);

  const subject = (searchParams.get('subject') as Subject) || undefined;

  const { data, isLoading } = useQuery({
    queryKey: ['assignments', { subject }],
    queryFn: () =>
      api.listAssignments({
        subject,
        pageSize: 100,
      }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.deleteAssignment(id),
    retry: false,
    onSuccess: () => {
      toast.success('作业已删除');
      queryClient.invalidateQueries({ queryKey: ['assignments'] });
      setDeleteId(null);
    },
    onError: (error) => {
      logger.error('删除作业失败', error);
      toast.error(getApiErrorMessage(error, '删除失败'));
    },
  });

  const regenerateMutation = useMutation({
    mutationFn: (id: string) => api.regenerateAssignmentCode(id),
    retry: false,
    onSuccess: (data) => {
      toast.success(`新访问码：${data.accessCode}`);
      queryClient.invalidateQueries({ queryKey: ['assignments'] });
      setRegenerateId(null);
    },
    onError: (error) => {
      logger.error('重新生成访问码失败', error);
      toast.error(getApiErrorMessage(error, '生成失败'));
    },
  });

  const closeMutation = useMutation({
    mutationFn: (id: string) => api.closeAssignment(id),
    retry: false,
    onSuccess: () => {
      toast.success('作业已关闭');
      queryClient.invalidateQueries({ queryKey: ['assignments'] });
    },
    onError: (error) => {
      logger.error('关闭作业失败', error);
      toast.error(getApiErrorMessage(error, '操作失败'));
    },
  });

  const reopenMutation = useMutation({
    mutationFn: (id: string) => api.reopenAssignment(id),
    retry: false,
    onSuccess: () => {
      toast.success('作业已重新开放');
      queryClient.invalidateQueries({ queryKey: ['assignments'] });
    },
    onError: (error) => {
      logger.error('重新开放作业失败', error);
      toast.error(getApiErrorMessage(error, '操作失败'));
    },
  });

  const updateDeadlineMutation = useMutation({
    mutationFn: ({ id, deadline }: { id: string; deadline: string | null }) =>
      api.updateAssignmentDeadline(id, deadline),
    retry: false,
    onSuccess: () => {
      toast.success('截止时间已更新');
      queryClient.invalidateQueries({ queryKey: ['assignments'] });
      setDeadlinePickerId(null);
    },
    onError: (error) => {
      logger.error('更新截止时间失败', error);
      toast.error(getApiErrorMessage(error, '更新失败'));
    },
  });

  const updateFilter = (key: string, value: string | undefined) => {
    const next = new URLSearchParams(searchParams);
    if (value) {
      next.set(key, value);
    } else {
      next.delete(key);
    }
    setSearchParams(next);
  };

  const handleCopyCode = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      toast.success('访问码已复制');
    } catch {
      toast.error('复制失败，请手动复制');
    }
  };

  const assignments: Assignment[] = data?.items ?? [];

  return (
    <div className="space-y-6">
      {/* 标题区 */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="font-display text-3xl md:text-4xl text-foreground">
            作业管理
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            共 {data?.total ?? 0} 份作业
          </p>
        </div>
        <Button onClick={() => navigate('/teacher/assignments/new')} data-ai-section-type="button">
          <Plus size={16} />
          布置作业
        </Button>
      </div>

      {/* 筛选区 */}
      <Card className="rounded-2xl border-card-border">
        <CardContent className="p-4 flex gap-3 items-center">
          <Select
            value={subject ?? 'all'}
            onValueChange={(v) => updateFilter('subject', v === 'all' ? undefined : v)}
          >
            <SelectTrigger className="w-32">
              <SelectValue placeholder="全部学科" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部学科</SelectItem>
              {SUBJECTS.map((s) => (
                <SelectItem key={s} value={s}>
                  {SUBJECT_EMOJIS[s]} {SUBJECT_LABELS[s]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* 作业卡片列表 */}
      {isLoading ? (
        <AssignmentsSkeleton />
      ) : assignments.length === 0 ? (
        <Card className="rounded-2xl border-card-border">
          <CardContent className="p-12 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full bg-accent/50 flex items-center justify-center mb-4">
              <ClipboardList size={28} className="text-muted-foreground" />
            </div>
            <h3 className="font-medium text-foreground mb-1">暂无作业</h3>
            <p className="text-sm text-muted-foreground mb-4">
              点击下方按钮布置你的第一份作业吧
            </p>
            <Button onClick={() => navigate('/teacher/assignments/new')}>
              <Plus size={16} />
              布置作业
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div
          data-ai-section-type="card-list"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {assignments.map((item) => (
            <Card
              key={item.id}
              className="hover-elevate transition-all rounded-2xl border-card-border group"
            >
              <CardContent className="p-5 space-y-4">
                {/* 标题 + 状态 */}
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-medium text-foreground leading-snug line-clamp-2 flex-1">
                    {item.title}
                  </h3>
                  <div className="flex flex-col items-end gap-1 flex-shrink-0">
                    <div className="flex items-center gap-1 flex-wrap justify-end">
                      <Badge
                        variant={item.isPublished ? 'default' : 'outline'}
                        className="rounded-full text-xs"
                      >
                        {item.isPublished ? '已发布' : '未发布'}
                      </Badge>
                      {item.isClosed && (
                        <Badge variant="destructive" className="rounded-full text-xs">
                          已关闭
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                {/* 学科标签 */}
                <Badge
                  variant="outline"
                  className={`${subjectColor[item.subject]} border-0 rounded-full`}
                >
                  {SUBJECT_EMOJIS[item.subject]} {SUBJECT_LABELS[item.subject]}
                </Badge>

                {/* 详情 */}
                <div className="space-y-2 text-sm text-muted-foreground pt-2 border-t border-border">
                  <div className="flex items-center gap-2">
                    <FileQuestionIcon size={14} />
                    <span className="tnum">{item.questionIds?.length ?? 0} 道题</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Copy size={14} />
                    <span className="tnum font-mono">{item.accessCode}</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 px-2 text-xs"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCopyCode(item.accessCode);
                      }}
                    >
                      复制
                    </Button>
                  </div>
                  {item.deadline && (
                    <div className="flex items-center gap-2">
                      <CalendarDays size={14} />
                      <span>截止 {formatDeadline(item.deadline)}</span>
                    </div>
                  )}
                  {item.submissionCount !== undefined && (
                    <div className="flex items-center gap-2">
                      <Users size={14} />
                      <span className="tnum">
                        {item.submissionCount}/{item.allowRetry && item.maxSubmissions > 1 ? item.maxSubmissions : '∞'} 次
                      </span>
                    </div>
                  )}
                </div>

                {/* 操作区 */}
                <div className="flex items-center gap-1 pt-2 border-t border-border">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="flex-1"
                    onClick={() => navigate(`/teacher/assignments/${item.id}/edit`)}
                  >
                    <Pencil size={14} />
                    编辑
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="flex-1"
                    onClick={() =>
                      navigate(`/teacher/submissions?assignmentId=${item.id}`)
                    }
                  >
                    <Eye size={14} />
                    提交
                  </Button>
                  <Popover
                    open={deadlinePickerId === item.id}
                    onOpenChange={(open) => !open && setDeadlinePickerId(null)}
                  >
                    <PopoverTrigger asChild>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-9 px-2"
                        onClick={() => setDeadlinePickerId(item.id)}
                        aria-label="延长截止"
                        title="延长截止"
                      >
                        <Clock size={14} />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-3" align="end">
                      <div className="space-y-3">
                        <div className="text-sm font-medium text-foreground">
                          选择新的截止时间
                        </div>
                        <Calendar
                          mode="single"
                          selected={item.deadline ? new Date(item.deadline) : undefined}
                          onSelect={(date: Date | undefined) => {
                            if (date) {
                              const d = new Date(date);
                              d.setHours(23, 59, 0, 0);
                              updateDeadlineMutation.mutate({
                                id: item.id,
                                deadline: d.toISOString(),
                              });
                            }
                          }}
                          initialFocus
                        />
                        <div className="flex items-center justify-between pt-2 border-t border-border">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() =>
                              updateDeadlineMutation.mutate({
                                id: item.id,
                                deadline: null,
                              })
                            }
                          >
                            <X size={14} />
                            清除截止
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setDeadlinePickerId(null)}
                          >
                            取消
                          </Button>
                        </div>
                      </div>
                    </PopoverContent>
                  </Popover>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-9 px-2"
                        aria-label="更多操作"
                      >
                        <MoreHorizontal size={14} />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem
                        onClick={() => setRegenerateId(item.id)}
                        className="cursor-pointer"
                      >
                        <RefreshCw size={14} className="mr-2" />
                        重新生成码
                      </DropdownMenuItem>
                      {item.isClosed ? (
                        <DropdownMenuItem
                          onClick={() => reopenMutation.mutate(item.id)}
                          className="cursor-pointer"
                        >
                          <Unlock size={14} className="mr-2" />
                          重新开放
                        </DropdownMenuItem>
                      ) : (
                        <DropdownMenuItem
                          onClick={() => closeMutation.mutate(item.id)}
                          className="cursor-pointer"
                        >
                          <Lock size={14} className="mr-2" />
                          关闭作业
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                  <AlertDialog
                    open={deleteId === item.id}
                    onOpenChange={(open) => !open && setDeleteId(null)}
                  >
                    <AlertDialogTrigger asChild>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-destructive hover:text-destructive h-9 px-2"
                        onClick={() => setDeleteId(item.id)}
                        aria-label="删除作业"
                        title="删除"
                      >
                        <Trash2 size={14} />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle className="flex items-center gap-2">
                          <AlertTriangle
                            size={20}
                            className="text-destructive"
                          />
                          确认删除作业？
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          删除后学生将无法再通过访问码进入，提交记录也将受到影响。
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>取消</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive hover:bg-destructive/90"
                          onClick={() => deleteMutation.mutate(item.id)}
                          disabled={deleteMutation.isPending}
                        >
                          {deleteMutation.isPending && deleteId === item.id && (
                            <span className="animate-spin mr-1">⏳</span>
                          )}
                          删除
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>

                  {/* 重新生成码确认弹窗 */}
                  <AlertDialog
                    open={regenerateId === item.id}
                    onOpenChange={(open) => !open && setRegenerateId(null)}
                  >
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle className="flex items-center gap-2">
                          <RefreshCw size={20} className="text-amber-500" />
                          重新生成访问码？
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          重新生成后原访问码将失效，学生需要使用新访问码进入作业。
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>取消</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => regenerateMutation.mutate(item.id)}
                          disabled={regenerateMutation.isPending}
                        >
                          {regenerateMutation.isPending && regenerateId === item.id && (
                            <span className="animate-spin mr-1">⏳</span>
                          )}
                          确认生成
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

const FileQuestionIcon = (props: React.ComponentProps<typeof ClipboardList>) => (
  <ClipboardList size={14} {...props} />
);

export default TeacherAssignments;
