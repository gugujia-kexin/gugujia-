import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams, useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { ArrowLeft, Save, X } from 'lucide-react';
import { Card } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import { Label } from '@client/src/components/ui/label';
import { Skeleton } from '@client/src/components/ui/skeleton';
import { Switch } from '@client/src/components/ui/switch';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@client/src/components/ui/select';
import * as api from '@/api';
import type { CheckinTask, Subject, CheckinType } from '@shared/api.interface';
import {
  SUBJECTS, SUBJECT_LABELS,
  CHECKIN_TYPES, CHECKIN_TYPE_LABELS,
} from '@shared/api.interface';

const CheckinCreate: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const isEdit = !!id;

  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState<Subject | ''>('');
  const [taskType, setTaskType] = useState<CheckinType | ''>('');
  const [requirement, setRequirement] = useState('');
  const [deadline, setDeadline] = useState('');
  const [isPublished, setIsPublished] = useState(false);
  const [allowRetry, setAllowRetry] = useState(false);
  const [maxSubmissions, setMaxSubmissions] = useState(1);

  const { data: task, isLoading } = useQuery({
    queryKey: ['checkinTask', id],
    queryFn: () => api.getCheckinTask(id!),
    enabled: isEdit,
  });

  useEffect(() => {
    if (task) {
      const t: CheckinTask = task;
      setTitle(t.title);
      setSubject(t.subject);
      setTaskType(t.taskType);
      setRequirement(t.requirement);
      setDeadline(t.deadline ? t.deadline.slice(0, 16) : '');
      setIsPublished(t.isPublished);
      setAllowRetry(t.allowRetry ?? false);
      setMaxSubmissions(t.maxSubmissions ?? 1);
    }
  }, [task]);

  const createMutation = useMutation({
    mutationFn: (body: Partial<CheckinTask>) =>
      isEdit ? api.updateCheckinTask(id!, body) : api.createCheckinTask(body),
    retry: false,
    onSuccess: () => {
      toast.success(isEdit ? '打卡任务已更新' : '打卡任务已创建');
      queryClient.invalidateQueries({ queryKey: ['checkinTasks'] });
      navigate('/teacher/checkin');
    },
    onError: (err: any) => {
      const msg = err.response?.data?.error?.message || '保存失败，请稍后重试';
      toast.error(msg);
      logger.error('保存打卡任务失败', err);
    },
  });

  const handleSave = () => {
    if (!title.trim()) {
      toast.error('请输入标题');
      return;
    }
    if (!subject) {
      toast.error('请选择学科');
      return;
    }
    if (!taskType) {
      toast.error('请选择类型');
      return;
    }
    createMutation.mutate({
      title: title.trim(),
      subject: subject as Subject,
      taskType: taskType as CheckinType,
      requirement,
      deadline: deadline || null,
      isPublished,
      allowRetry,
      maxSubmissions: allowRetry ? maxSubmissions : 1,
    });
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-40" />
        <Card className="p-6 space-y-4">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-24 w-full" />
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 头部 */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)} aria-label="返回">
          <ArrowLeft className="size-5" />
        </Button>
        <h1 className="font-display text-2xl text-foreground">
          {isEdit ? '编辑打卡任务' : '新建打卡任务'}
        </h1>
      </div>

      <Card className="p-6">
        <div className="space-y-5 max-w-2xl">
          <div>
            <Label htmlFor="title" className="mb-1.5 block">
              标题 <span className="text-red-500">*</span>
            </Label>
            <Input
              id="title"
              placeholder="输入打卡任务标题"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="subject" className="mb-1.5 block">
                学科 <span className="text-red-500">*</span>
              </Label>
              <Select value={subject} onValueChange={(v) => setSubject(v as Subject)}>
                <SelectTrigger className="w-full" id="subject">
                  <SelectValue placeholder="选择学科" />
                </SelectTrigger>
                <SelectContent>
                  {SUBJECTS.map((s) => (
                    <SelectItem key={s} value={s}>{SUBJECT_LABELS[s]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="taskType" className="mb-1.5 block">
                类型 <span className="text-red-500">*</span>
              </Label>
              <Select value={taskType} onValueChange={(v) => setTaskType(v as CheckinType)}>
                <SelectTrigger className="w-full" id="taskType">
                  <SelectValue placeholder="选择类型" />
                </SelectTrigger>
                <SelectContent>
                  {CHECKIN_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>{CHECKIN_TYPE_LABELS[t]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="requirement" className="mb-1.5 block">要求说明</Label>
            <Textarea
              id="requirement"
              placeholder="描述打卡要求和注意事项..."
              value={requirement}
              onChange={(e) => setRequirement(e.target.value)}
              rows={4}
            />
          </div>

          <div>
            <Label htmlFor="deadline" className="mb-1.5 block">截止时间</Label>
            <Input
              id="deadline"
              type="datetime-local"
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
              className="max-w-xs"
            />
          </div>

          <div className="flex items-center justify-between py-3 px-4 rounded-lg bg-secondary/30 border border-border">
            <div>
              <div className="font-medium text-foreground">发布状态</div>
              <div className="text-sm text-muted-foreground">
                {isPublished ? '学生可以看到此打卡任务' : '仅老师可见'}
              </div>
            </div>
            <Switch
              checked={isPublished}
              onCheckedChange={setIsPublished}
              aria-label="是否发布"
            />
          </div>

          <div className="flex items-center justify-between py-3 px-4 rounded-lg bg-secondary/30 border border-border">
            <div>
              <div className="font-medium text-foreground">允许重做</div>
              <div className="text-sm text-muted-foreground">
                {allowRetry ? '学生可以多次提交打卡' : '每位学生只能提交一次'}
              </div>
            </div>
            <Switch
              checked={allowRetry}
              onCheckedChange={setAllowRetry}
              aria-label="是否允许重做"
            />
          </div>

          {allowRetry && (
            <div>
              <Label htmlFor="maxSubmissions" className="mb-1.5 block">最大提交次数</Label>
              <Input
                id="maxSubmissions"
                type="number"
                min={1}
                max={10}
                value={maxSubmissions}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setMaxSubmissions(Math.min(10, Math.max(1, val || 1)));
                }}
                className="max-w-[120px]"
              />
              <p className="text-xs text-muted-foreground mt-1">范围 1-10 次</p>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4 border-t border-border">
            <Button variant="outline" onClick={() => navigate(-1)}>
              <X className="size-4" />
              取消
            </Button>
            <Button onClick={handleSave} disabled={createMutation.isPending}>
              <Save className="size-4" />
              {createMutation.isPending ? '保存中...' : '保存'}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default CheckinCreate;
