import { useEffect, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import {
  FileQuestion,
  ClipboardList,
  Clock,
  Users,
  Plus,
  BookOpen,
  Mic,
  Star,
  CheckCircle2,
  Loader2,
  KeyRound,
  Copy,
  Pencil,
  Check,
  Trash2,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as api from '@/api';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Badge } from '@client/src/components/ui/badge';
import { Skeleton } from '@client/src/components/ui/skeleton';
import Sticker from '@/components/Sticker';
import { toast } from 'sonner';
import {
  SUBMISSION_STATUS_LABELS,
  type SubmissionStatus,
} from '@shared/api.interface';

const statCards = [
  { key: 'questions', label: '题目总数', icon: FileQuestion, color: 'text-primary' },
  { key: 'assignments', label: '作业总数', icon: ClipboardList, color: 'text-[hsl(45_95%_45%)]' },
  { key: 'pending', label: '待批改', icon: Clock, color: 'text-[hsl(45_95%_50%)]' },
  { key: 'students', label: '学生数', icon: Users, color: 'text-[hsl(142_65%_45%)]' },
];

const quickActions = [
  { label: '新建题目', to: '/teacher/questions/new', icon: Plus, desc: '录入新题目到题库' },
  { label: '布置作业', to: '/teacher/assignments/new', icon: ClipboardList, desc: '从题库选题布置' },
  { label: '查看打卡', to: '/teacher/checkin', icon: Mic, desc: '查看学生打卡记录' },
];

const DashboardSkeleton = () => (
  <div className="space-y-8">
    <div>
      <Skeleton className="h-9 w-40" />
      <Skeleton className="mt-2 h-5 w-64" />
    </div>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="rounded-2xl border p-5 space-y-3">
          <Skeleton className="h-8 w-8 rounded-lg" />
          <Skeleton className="h-7 w-16" />
          <Skeleton className="h-3 w-20" />
        </div>
      ))}
    </div>
    <div className="space-y-3">
      <Skeleton className="h-6 w-32" />
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="rounded-2xl border p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Skeleton className="h-9 w-9 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-3 w-32" />
            </div>
          </div>
          <Skeleton className="h-5 w-16 rounded-full" />
        </div>
      ))}
    </div>
  </div>
);

const TeacherDashboard: React.FC = () => {
  const { data: questions, isLoading: questionsLoading } = useQuery({
    queryKey: ['questions', { pageSize: 1 }],
    queryFn: () => api.listQuestions({ pageSize: 1 }),
  });

  const { data: assignments, isLoading: assignmentsLoading } = useQuery({
    queryKey: ['assignments', { pageSize: 1 }],
    queryFn: () => api.listAssignments({ pageSize: 1 }),
  });

  const { data: submissions, isLoading: submissionsLoading } = useQuery({
    queryKey: ['submissions', { pageSize: 5 }],
    queryFn: () => api.listSubmissions({ pageSize: 5 }),
  });

  const { data: students, isLoading: studentsLoading } = useQuery({
    queryKey: ['students-list'],
    queryFn: () => api.listStudents(),
  });

  const { data: pendingSubmissions } = useQuery({
    queryKey: ['submissions', { status: 'submitted' satisfies SubmissionStatus, pageSize: 1 }],
    queryFn: () => api.listSubmissions({ status: 'submitted', pageSize: 1 }),
  });

  const queryClient = useQueryClient();
  const [classCode, setClassCode] = useState('');
  const [editingCode, setEditingCode] = useState(false);
  const [codeDraft, setCodeDraft] = useState('');
  const [savingCode, setSavingCode] = useState(false);

  useEffect(() => {
    api.getClassCode()
      .then((r) => {
        setClassCode(r.classCode);
        setCodeDraft(r.classCode);
      })
      .catch(() => { /* 忽略：拿不到就用空 */ });
  }, []);

  const saveClassCode = async () => {
    const next = codeDraft.trim().toUpperCase();
    if (!/^[A-Za-z0-9]{4,20}$/.test(next)) {
      toast.error('班级码用 4-20 位字母或数字');
      return;
    }
    setSavingCode(true);
    try {
      const r = await api.setClassCode(next);
      setClassCode(r.classCode);
      setEditingCode(false);
      toast.success('班级码改好了，以后学生用这个进');
    } catch {
      toast.error('没保存成功，再试一次');
    } finally {
      setSavingCode(false);
    }
  };

  const copyClassCode = async () => {
    try {
      await navigator.clipboard.writeText(classCode);
      toast.success('复制好了，发给学生就行');
    } catch {
      toast.error('复制不了，手动记一下：' + classCode);
    }
  };

  const removeSubmission = async (id: string, who: string) => {
    if (!window.confirm(`删掉「${who}」这条提交？删了不能恢复。`)) return;
    try {
      await api.deleteSubmission(id);
      toast.success('已删除');
      queryClient.invalidateQueries();
    } catch {
      toast.error('删除失败，再试一次');
    }
  };

  const isLoading = questionsLoading || assignmentsLoading || submissionsLoading || studentsLoading;

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  const stats = [
    { ...statCards[0], value: questions?.total ?? 0 },
    { ...statCards[1], value: assignments?.total ?? 0 },
    { ...statCards[2], value: pendingSubmissions?.total ?? 0 },
    { ...statCards[3], value: students?.length ?? 0 },
  ];

  const handleViewSubmission = (id: string) => {
    logger.info('查看提交详情', id);
  };

  return (
    <div className="space-y-8">
      {/* 标题区 */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div className="flex items-end gap-3">
          <div>
            <h1 className="font-display text-3xl md:text-4xl text-foreground">工作台</h1>
            <p className="mt-2 text-muted-foreground">欢迎回来，可心老师 ☀️</p>
          </div>
          <Sticker name="smart" size={64} animation="float" delay={0.2} />
        </div>
        <div className="teacher-seal">可心老师</div>
      </div>

      {/* 班级码 */}
      <Card className="rounded-2xl border-card-border overflow-hidden">
        <CardContent className="p-4 flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center flex-shrink-0">
            <KeyRound size={20} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs text-muted-foreground">学生用的班级码</div>
            {editingCode ? (
              <input
                value={codeDraft}
                onChange={(e) => setCodeDraft(e.target.value.toUpperCase())}
                maxLength={20}
                autoFocus
                className="mt-1 w-full max-w-[220px] h-9 rounded-lg border border-border bg-background px-3 font-mono tnum text-lg tracking-widest"
              />
            ) : (
              <div className="font-mono tnum text-xl font-semibold text-foreground tracking-widest">
                {classCode || '—'}
              </div>
            )}
          </div>
          {editingCode ? (
            <div className="flex items-center gap-2">
              <Button size="sm" className="rounded-full" onClick={saveClassCode} disabled={savingCode}>
                <Check size={16} />
                {savingCode ? '保存中' : '保存'}
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="rounded-full"
                onClick={() => {
                  setEditingCode(false);
                  setCodeDraft(classCode);
                }}
              >
                取消
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-1">
              <Button size="sm" variant="outline" className="rounded-full" onClick={copyClassCode}>
                <Copy size={14} />
                复制
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="rounded-full"
                onClick={() => {
                  setCodeDraft(classCode);
                  setEditingCode(true);
                }}
              >
                <Pencil size={14} />
                修改
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 统计卡片 */}
      <div
        data-ai-section-type="card-stat"
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
      >
        {stats.map((stat) => (
          <Card
            key={stat.key}
            className="hover-elevate transition-all cursor-default rounded-2xl border-card-border"
          >
            <CardContent className="p-5">
              <div className={`${stat.color} mb-3`}>
                <stat.icon size={28} strokeWidth={2} />
              </div>
              <div className="tnum text-3xl font-semibold text-foreground">
                {stat.value}
              </div>
              <div className="mt-1 text-sm text-muted-foreground">
                {stat.label}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 最近提交 + 快捷操作 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 最近提交 */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl text-foreground">最近提交</h2>
            <Link
              to="/teacher/submissions"
              className="text-sm text-primary hover:underline"
            >
              查看全部
            </Link>
          </div>

          <Card className="rounded-2xl border-card-border overflow-hidden">
            {submissions?.items?.length ? (
              <div className="divide-y divide-border">
                {submissions.items.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-4 hover:bg-accent/50 transition-colors cursor-pointer"
                    onClick={() => handleViewSubmission(item.id)}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleViewSubmission(item.id);
                    }}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-medium text-sm flex-shrink-0">
                        {item.studentName?.slice(0, 1) ?? '学'}
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-foreground truncate">
                          {item.studentName}
                        </div>
                        <div className="text-xs text-muted-foreground truncate">
                          作业：{item.assignmentTitle || '作业'}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 flex-shrink-0">
                      <div className="tnum text-sm font-medium text-foreground">
                        {item.teacherScore ?? item.autoScore}
                        <span className="text-xs text-muted-foreground ml-0.5">分</span>
                      </div>
                      <Badge
                        variant={item.status === 'graded' ? 'default' : 'secondary'}
                        className="rounded-full"
                      >
                        {SUBMISSION_STATUS_LABELS[item.status]}
                      </Badge>
                      <button
                        type="button"
                        aria-label="删除这条提交"
                        className="h-8 w-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                        onClick={(e) => {
                          e.stopPropagation();
                          removeSubmission(item.id, item.studentName);
                        }}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-12 text-center">
                <div className="mx-auto w-16 h-16 rounded-full bg-accent/50 flex items-center justify-center mb-3">
                  <BookOpen size={28} className="text-muted-foreground" />
                </div>
                <p className="text-muted-foreground text-sm">暂无提交记录</p>
              </div>
            )}
          </Card>
        </div>

        {/* 快捷操作 */}
        <div className="space-y-3">
          <h2 className="font-display text-xl text-foreground">快捷操作</h2>
          <div data-ai-section-type="card-menu" className="space-y-3">
            {quickActions.map((action) => (
              <Link key={action.to} to={action.to}>
                <Card className="hover-elevate transition-all rounded-2xl border-card-border h-full">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center flex-shrink-0">
                      <action.icon size={20} strokeWidth={2} />
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-foreground">
                        {action.label}
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {action.desc}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          <div className="mt-6 p-4 rounded-2xl bg-gradient-to-br from-primary/10 to-[hsl(45_95%_58%)]/20 border border-primary/20">
            <div className="flex items-center gap-2 mb-2">
              <Star size={18} className="text-[hsl(45_95%_50%)] fill-[hsl(45_95%_50%)]" />
              <span className="font-medium text-foreground text-sm">今日提示</span>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              试着给刚交作业的小朋友写句鼓励的话吧，孩子们都很期待可心老师的评语呢～
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;
