import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Search, User, ChevronDown, ChevronUp, TrendingUp, Clock, AlertCircle, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Card } from '@client/src/components/ui/card';
import { Input } from '@client/src/components/ui/input';
import { Skeleton } from '@client/src/components/ui/skeleton';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import { Empty, EmptyTitle, EmptyDescription, EmptyMedia } from '@client/src/components/ui/empty';
import * as api from '@/api';
import {
  SUBMISSION_STATUS_LABELS,
  type StudentStats,
  type ListResponse,
  type Submission,
  type SubmissionStatus,
} from '@shared/api.interface';

const Students: React.FC = () => {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [expandedName, setExpandedName] = useState<string | null>(null);

  const { data: statsData, isLoading, isError, error } = useQuery({
    queryKey: ['studentStats', { studentName: search || undefined }],
    queryFn: () => api.getStudentStats({ studentName: search || undefined }),
  });

  const stats: StudentStats[] = statsData
    ? ('items' in (statsData as unknown as object)
        ? ((statsData as unknown) as ListResponse<StudentStats>).items
        : (statsData as StudentStats[]))
    : [];

  if (isError) {
    logger.error('加载学生统计失败', error);
  }

  const { data: submissionsData } = useQuery({
    queryKey: ['studentSubmissions', expandedName],
    queryFn: () =>
      expandedName
        ? api.listSubmissions({ studentName: expandedName, pageSize: 20 })
        : Promise.resolve({ items: [], total: 0 }),
    enabled: !!expandedName,
  });

  const studentSubmissions: Submission[] = submissionsData?.items ?? [];

  const { data: assignmentsData } = useQuery({
    queryKey: ['assignments-all', { pageSize: 100 }],
    queryFn: () => api.listAssignments({ pageSize: 100 }),
  });
  const assignmentMap = new Map((assignmentsData?.items ?? []).map((a) => [a.id, a]));

  const statusBadgeClass = (s: SubmissionStatus): string => {
    return s === 'submitted'
      ? 'bg-amber-100 text-amber-700 border-amber-200'
      : 'bg-green-100 text-green-700 border-green-200';
  };

  const scoreColor = (score: number): string => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-amber-600';
    if (score >= 60) return 'text-orange-500';
    return 'text-red-500';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="font-display text-3xl text-foreground">学生统计</h1>
        <Button
          variant="outline"
          size="sm"
          className="rounded-full text-muted-foreground hover:text-destructive"
          onClick={async () => {
            if (!window.confirm('清空全部提交和打卡记录？（题目、作业、打卡任务都保留，只清学生提交的数据）')) return;
            try {
              await api.clearAllRecords();
              toast.success('清空了，学生名单已重置');
              queryClient.invalidateQueries();
            } catch {
              toast.error('清空失败，再试一次');
            }
          }}
        >
          <Trash2 className="size-4 mr-1" />
          清空全部提交记录
        </Button>
      </div>

      <Card className="p-4">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input
            placeholder="搜索学生姓名"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </Card>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="p-5">
              <div className="flex items-center gap-4">
                <Skeleton className="h-12 w-12 rounded-full" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-4 w-48" />
                </div>
                <Skeleton className="h-8 w-16 rounded-md" />
              </div>
            </Card>
          ))}
        </div>
      ) : !stats.length ? (
        <Empty>
          <EmptyMedia variant="icon">
            <User className="size-6" />
          </EmptyMedia>
          <EmptyTitle>暂无学生数据</EmptyTitle>
          <EmptyDescription>学生完成作业后会出现在这里</EmptyDescription>
        </Empty>
      ) : (
        <div className="space-y-3">
          {stats.map((s: StudentStats) => {
            const isExpanded = expandedName === s.studentName;
            const submissions = isExpanded ? studentSubmissions : [];
            return (
              <Card key={s.studentName} className="overflow-hidden">
                <div
                  className="p-5 hover-elevate transition-all cursor-pointer"
                  onClick={() => setExpandedName(isExpanded ? null : s.studentName)}
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-4 min-w-0 flex-1">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <User className="size-5 text-primary" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h3 className="text-lg font-semibold text-foreground mb-1 truncate">
                          {s.studentName}
                        </h3>
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
                          <span className="text-muted-foreground">
                            提交次数：<span className="tnum font-medium text-foreground">{s.submissionCount}</span>
                          </span>
                          <span className="text-muted-foreground">
                            平均分：<span className={`tnum font-medium ${scoreColor(s.avgScore)}`}>{s.avgScore.toFixed(1)}</span>
                          </span>
                          <span className="text-muted-foreground">
                            最近得分：<span className={`tnum font-medium ${scoreColor(s.latestScore)}`}>{s.latestScore}</span>
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label={`删除 ${s.studentName}`}
                        className="text-muted-foreground hover:text-destructive"
                        onClick={async (e) => {
                          e.stopPropagation();
                          if (!window.confirm(`删掉「${s.studentName}」的全部记录？删了不能恢复。`)) return;
                          try {
                            await api.deleteStudentByName(s.studentName);
                            toast.success('已删除');
                            queryClient.invalidateQueries();
                          } catch {
                            toast.error('删除失败，再试一次');
                          }
                        }}
                      >
                        <Trash2 className="size-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="shrink-0">
                        {isExpanded ? '收起' : '查看详情'}
                        {isExpanded ? <ChevronUp className="size-4" /> : <ChevronDown className="size-4" />}
                      </Button>
                    </div>
                  </div>
                </div>

                {isExpanded && (
                  <div className="border-t border-border p-5 bg-secondary/30">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                          <Clock className="size-4 text-muted-foreground" />
                          历史提交（最近 {submissions.length} 条）
                        </h4>
                        <div className="space-y-2">
                          {submissions.length > 0 ? (
                            submissions.map((sub) => {
                              const asn = assignmentMap.get(sub.assignmentId);
                              const score = sub.teacherScore ?? sub.autoScore;
                              return (
                                <div
                                  key={sub.id}
                                  className="flex items-center justify-between text-sm bg-card rounded-lg p-3 border border-border"
                                >
                                  <div className="min-w-0 flex-1 mr-3">
                                    <p className="text-foreground truncate font-medium">{asn?.title ?? '作业'}</p>
                                    <p className="text-xs text-muted-foreground mt-0.5">
                                      {new Date(sub.submittedAt).toLocaleDateString('zh-CN', {
                                        month: 'short',
                                        day: 'numeric',
                                      })}
                                    </p>
                                  </div>
                                  <div className="flex items-center gap-2 shrink-0">
                                    <span
                                      className={`font-mono tnum text-base font-medium ${
                                        Number(score) >= 80
                                          ? 'text-green-600'
                                          : Number(score) >= 60
                                          ? 'text-amber-600'
                                          : 'text-red-500'
                                      }`}
                                    >
                                      {score}
                                    </span>
                                    <Badge variant="outline" className={statusBadgeClass(sub.status)}>
                                      {SUBMISSION_STATUS_LABELS[sub.status]}
                                    </Badge>
                                  </div>
                                </div>
                              );
                            })
                          ) : (
                            <p className="text-sm text-muted-foreground italic">暂无提交记录</p>
                          )}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                          <AlertCircle className="size-4 text-amber-500" />
                          高频错题 Top 5
                        </h4>
                        <div className="space-y-2">
                          {s.wrongQuestionIds.length > 0 ? (
                            s.wrongQuestionIds.slice(0, 5).map((item, idx) => (
                              <div
                                key={item.questionId}
                                className="flex items-center justify-between text-sm bg-card rounded-lg p-3 border border-border"
                              >
                                <div className="flex items-center gap-2 min-w-0">
                                  <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-red-100 text-red-600 text-xs font-medium shrink-0">
                                    {idx + 1}
                                  </span>
                                  <span className="text-foreground truncate">
                                    题目 {item.questionId.slice(0, 8)}...
                                  </span>
                                </div>
                                <span className="text-muted-foreground tnum shrink-0">错 {item.count} 次</span>
                              </div>
                            ))
                          ) : (
                            <p className="text-sm text-muted-foreground italic">暂无错题记录</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default Students;
