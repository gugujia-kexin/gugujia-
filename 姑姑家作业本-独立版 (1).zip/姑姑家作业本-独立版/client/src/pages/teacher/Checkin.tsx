import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, ClipboardList, Users, Calendar as CalendarDays, Copy, BookOpen, RefreshCw, Lock, Unlock, Clock, MoreHorizontal, X } from 'lucide-react';
import { Card } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import { Skeleton } from '@client/src/components/ui/skeleton';
import { Empty, EmptyTitle, EmptyDescription, EmptyMedia } from '@client/src/components/ui/empty';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@client/src/components/ui/select';
import {
  AlertDialog, AlertDialogTrigger, AlertDialogContent, AlertDialogHeader,
  AlertDialogTitle, AlertDialogDescription, AlertDialogFooter,
  AlertDialogAction, AlertDialogCancel,
} from '@client/src/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@client/src/components/ui/dropdown-menu';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import { Calendar } from '@client/src/components/ui/calendar';
import {
  Pagination, PaginationContent, PaginationItem, PaginationLink,
  PaginationPrevious, PaginationNext,
} from '@client/src/components/ui/pagination';
import * as api from '@/api';
import type { CheckinTask, Subject } from '@shared/api.interface';
import {
  SUBJECTS, SUBJECT_LABELS,
  CHECKIN_TYPE_LABELS,
} from '@shared/api.interface';

const PAGE_SIZE = 10;

const Checkin: React.FC = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [subject, setSubject] = useState<Subject | 'all'>('all');
  const [page, setPage] = useState(1);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [regenerateId, setRegenerateId] = useState<string | null>(null);
  const [deadlinePickerId, setDeadlinePickerId] = useState<string | null>(null);

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ['checkinTasks', { subject: subject === 'all' ? undefined : subject, page, pageSize: PAGE_SIZE }],
    queryFn: () => api.listCheckinTasks({
      subject: subject === 'all' ? undefined : subject,
      page,
      pageSize: PAGE_SIZE,
    }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.deleteCheckinTask(id),
    retry: false,
    onSuccess: () => {
      toast.success('打卡任务已删除');
      queryClient.invalidateQueries({ queryKey: ['checkinTasks'] });
      setDeleteId(null);
    },
    onError: (err: any) => {
      const msg = err.response?.data?.error?.message || '删除失败，请稍后重试';
      toast.error(msg);
      logger.error('删除打卡任务失败', err);
    },
  });

  const regenerateMutation = useMutation({
    mutationFn: (id: string) => api.regenerateCheckinTaskCode(id),
    retry: false,
    onSuccess: (data) => {
      toast.success(`新访问码：${data.accessCode}`);
      queryClient.invalidateQueries({ queryKey: ['checkinTasks'] });
      setRegenerateId(null);
    },
    onError: (err: any) => {
      const msg = err.response?.data?.error?.message || '生成失败，请稍后重试';
      toast.error(msg);
      logger.error('重新生成访问码失败', err);
    },
  });

  const closeMutation = useMutation({
    mutationFn: (id: string) => api.closeCheckinTask(id),
    retry: false,
    onSuccess: () => {
      toast.success('打卡任务已关闭');
      queryClient.invalidateQueries({ queryKey: ['checkinTasks'] });
    },
    onError: (err: any) => {
      const msg = err.response?.data?.error?.message || '操作失败，请稍后重试';
      toast.error(msg);
      logger.error('关闭打卡任务失败', err);
    },
  });

  const reopenMutation = useMutation({
    mutationFn: (id: string) => api.reopenCheckinTask(id),
    retry: false,
    onSuccess: () => {
      toast.success('打卡任务已重新开放');
      queryClient.invalidateQueries({ queryKey: ['checkinTasks'] });
    },
    onError: (err: any) => {
      const msg = err.response?.data?.error?.message || '操作失败，请稍后重试';
      toast.error(msg);
      logger.error('重新开放打卡任务失败', err);
    },
  });

  const updateDeadlineMutation = useMutation({
    mutationFn: ({ id, deadline }: { id: string; deadline: string | null }) =>
      api.updateCheckinTaskDeadline(id, deadline),
    retry: false,
    onSuccess: () => {
      toast.success('截止时间已更新');
      queryClient.invalidateQueries({ queryKey: ['checkinTasks'] });
      setDeadlinePickerId(null);
    },
    onError: (err: any) => {
      const msg = err.response?.data?.error?.message || '更新失败，请稍后重试';
      toast.error(msg);
      logger.error('更新截止时间失败', err);
    },
  });

  if (isError) {
    logger.error('加载打卡任务失败', error);
  }

  const totalPages = data ? Math.max(1, Math.ceil(data.total / PAGE_SIZE)) : 1;

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code).then(() => {
      toast.success('访问码已复制');
    }).catch(() => {
      toast.error('复制失败');
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl text-foreground">打卡任务</h1>
        <Button onClick={() => navigate('/teacher/checkin/new')}>
          <Plus className="size-4" />
          新建打卡
        </Button>
      </div>

      {/* 筛选栏 */}
      <Card className="p-4">
        <div className="max-w-xs">
          <Select value={subject} onValueChange={(v) => { setSubject(v as Subject | 'all'); setPage(1); }}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="选择学科" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部学科</SelectItem>
              {SUBJECTS.map((s) => (
                <SelectItem key={s} value={s}>{SUBJECT_LABELS[s]}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* 任务列表 */}
      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="p-5">
              <div className="flex items-center justify-between">
                <div className="space-y-2 flex-1 mr-4">
                  <Skeleton className="h-5 w-48" />
                  <Skeleton className="h-4 w-64" />
                  <Skeleton className="h-4 w-32" />
                </div>
                <Skeleton className="h-8 w-24 rounded-md" />
              </div>
            </Card>
          ))}
        </div>
      ) : !data?.items.length ? (
        <Empty>
          <EmptyMedia variant="icon">
            <ClipboardList className="size-6" />
          </EmptyMedia>
          <EmptyTitle>暂无打卡任务</EmptyTitle>
          <EmptyDescription>创建第一个打卡任务吧</EmptyDescription>
        </Empty>
      ) : (
        <>
          <div className="space-y-3" data-ai-section-type="card-list">
            {data.items.map((task: CheckinTask) => (
              <Card key={task.id} className="p-5 hover-elevate transition-all">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <h3 className="text-lg font-semibold text-foreground truncate">
                        {task.title}
                      </h3>
                      <Badge variant="outline" className="text-xs">
                        {SUBJECT_LABELS[task.subject]}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {CHECKIN_TYPE_LABELS[task.taskType]}
                      </Badge>
                      {task.isPublished && (
                        <Badge variant="default" className="text-xs bg-green-100 text-green-700 border-green-200">
                          已发布
                        </Badge>
                      )}
                      {task.isClosed && (
                        <Badge variant="destructive" className="text-xs">
                          已关闭
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                      {task.requirement || '暂无要求说明'}
                    </p>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
                      <div className="flex items-center gap-1.5">
                        <span className="text-muted-foreground">访问码：</span>
                        <code className="px-2 py-0.5 rounded bg-primary/10 text-primary font-mono text-xs">
                          {task.accessCode}
                        </code>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          aria-label="复制访问码"
                          onClick={() => copyCode(task.accessCode)}
                        >
                          <Copy className="size-3.5 text-muted-foreground" />
                        </Button>
                      </div>
                      <div className="flex items-center gap-1.5 text-muted-foreground">
                        <Users className="size-4" />
                        <span><span className="tnum text-foreground font-medium">{task.recordCount ?? 0}</span>/{task.allowRetry && task.maxSubmissions > 1 ? task.maxSubmissions : '∞'} 次</span>
                      </div>
                      {task.deadline && (
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                          <CalendarDays className="size-4" />
                          <span>截止：{new Date(task.deadline).toLocaleDateString('zh-CN')}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 sm:flex-col sm:items-end">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => navigate(`/teacher/checkin/${task.id}/records`)} 
                    >
                      <BookOpen className="size-4" />
                      查看记录
                    </Button>
                    <div className="flex items-center gap-1">
                      <Popover
                        open={deadlinePickerId === task.id}
                        onOpenChange={(open) => !open && setDeadlinePickerId(null)}
                      >
                        <PopoverTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            aria-label="延长截止"
                            onClick={() => setDeadlinePickerId(task.id)}
                          >
                            <Clock className="size-4" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-3" align="end">
                          <div className="space-y-3">
                            <div className="text-sm font-medium text-foreground">
                              选择新的截止时间
                            </div>
                            <Calendar
                              mode="single"
                              selected={task.deadline ? new Date(task.deadline) : undefined}
                              onSelect={(date: Date | undefined) => {
                                if (date) {
                                  const d = new Date(date);
                                  d.setHours(23, 59, 0, 0);
                                  updateDeadlineMutation.mutate({
                                    id: task.id,
                                    deadline: d.toISOString(),
                                  });
                                }
                              }}
                              initialFocus
                            />
                            <div className="flex items-center justify-between pt-2 border-t border-border">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() =>
                                  updateDeadlineMutation.mutate({
                                    id: task.id,
                                    deadline: null,
                                  })
                                }
                              >
                                <X className="size-4" />
                                清除截止
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => setDeadlinePickerId(null)}
                              >
                                取消
                              </Button>
                            </div>
                          </div>
                        </PopoverContent>
                      </Popover>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            aria-label="更多操作"
                          >
                            <MoreHorizontal className="size-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => setRegenerateId(task.id)}
                            className="cursor-pointer"
                          >
                            <RefreshCw className="size-4 mr-2" />
                            重新生成码
                          </DropdownMenuItem>
                          {task.isClosed ? (
                            <DropdownMenuItem
                              onClick={() => reopenMutation.mutate(task.id)}
                              className="cursor-pointer"
                            >
                              <Unlock className="size-4 mr-2" />
                              重新开放
                            </DropdownMenuItem>
                          ) : (
                            <DropdownMenuItem
                              onClick={() => closeMutation.mutate(task.id)}
                              className="cursor-pointer"
                            >
                              <Lock className="size-4 mr-2" />
                              关闭任务
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label="编辑"
                        onClick={() => navigate(`/teacher/checkin/${task.id}/edit`)} 
                      >
                        <Pencil className="size-4" />
                      </Button>
                      <AlertDialog open={deleteId === task.id} onOpenChange={(open) => !open && setDeleteId(null)}>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            aria-label="删除"
                            onClick={() => setDeleteId(task.id)}
                            className="text-red-500 hover:text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>确认删除</AlertDialogTitle>
                            <AlertDialogDescription>
                              确定要删除打卡任务「{task.title}」吗？此操作不可撤销。
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>取消</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-destructive hover:bg-destructive/90"
                              onClick={() => deleteMutation.mutate(task.id)}
                            >
                              {deleteMutation.isPending ? '删除中...' : '删除'}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>

                      {/* 重新生成码确认弹窗 */}
                      <AlertDialog
                        open={regenerateId === task.id}
                        onOpenChange={(open) => !open && setRegenerateId(null)}
                      >
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle className="flex items-center gap-2">
                              <RefreshCw size={20} className="text-amber-500" />
                              重新生成访问码？
                            </AlertDialogTitle>
                            <AlertDialogDescription>
                              重新生成后原访问码将失效，学生需要使用新访问码进入打卡。
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>取消</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => regenerateMutation.mutate(task.id)}
                              disabled={regenerateMutation.isPending}
                            >
                              {regenerateMutation.isPending && regenerateId === task.id ? '生成中...' : '确认生成'}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                    className={page <= 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                  />
                </PaginationItem>
                {Array.from({ length: totalPages }).map((_, i) => (
                  <PaginationItem key={i}>
                    <PaginationLink
                      isActive={page === i + 1}
                      onClick={() => setPage(i + 1)}
                      className="cursor-pointer"
                    >
                      {i + 1}
                    </PaginationLink>
                  </PaginationItem>
                ))}
                <PaginationItem>
                  <PaginationNext
                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                    className={page >= totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}
    </div>
  );
};

export default Checkin;
