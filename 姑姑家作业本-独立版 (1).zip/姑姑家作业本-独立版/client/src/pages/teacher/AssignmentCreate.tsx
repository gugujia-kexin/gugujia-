import { useState, useMemo } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  Search,
  Plus,
  Trash2,
  ChevronUp,
  ChevronDown,
  Loader2,
  FileQuestion,
  Check,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import * as api from '@/api';
import { getApiErrorMessage } from '@/lib/api-error';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import { Switch } from '@client/src/components/ui/switch';
import { Badge } from '@client/src/components/ui/badge';
import { Skeleton } from '@client/src/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import { Checkbox } from '@client/src/components/ui/checkbox';
import {
  SUBJECTS,
  SUBJECT_LABELS,
  SUBJECT_EMOJIS,
  QUESTION_TYPE_LABELS,
  DIFFICULTY_LABELS,
  type Subject,
  type Question,
  type Assignment,
} from '@shared/api.interface';

const formSchema = z.object({
  title: z.string().min(1, '请输入作业标题'),
  subject: z.string().min(1, '请选择学科'),
  description: z.string(),
  deadline: z.string().optional(),
  isPublished: z.boolean(),
  allowRetry: z.boolean(),
  maxSubmissions: z.number().min(1).max(10),
  questionIds: z.array(z.string()),
});

type FormValues = {
  title: string;
  subject: Subject;
  description: string;
  deadline: string;
  isPublished: boolean;
  allowRetry: boolean;
  maxSubmissions: number;
  questionIds: string[];
};

const subjectColor: Record<Subject, string> = {
  chinese: 'bg-[hsl(16_85%_62%)]/15 text-[hsl(16_85%_45%)]',
  math: 'bg-[hsl(220_70%_60%)]/15 text-[hsl(220_70%_45%)]',
  english: 'bg-[hsl(45_95%_50%)]/20 text-[hsl(45_95%_40%)]',
  physics: 'bg-[hsl(260_65%_60%)]/15 text-[hsl(260_65%_45%)]',
  chemistry: 'bg-[hsl(142_65%_50%)]/15 text-[hsl(142_65%_40%)]',
  biology: 'bg-[hsl(145_55%_50%)]/15 text-[hsl(145_55%_40%)]',
  geography: 'bg-[hsl(195_70%_55%)]/15 text-[hsl(195_70%_45%)]',
  history: 'bg-[hsl(30_65%_55%)]/15 text-[hsl(30_65%_40%)]',
  politics: 'bg-[hsl(355_78%_62%)]/15 text-[hsl(355_78%_45%)]',
};

const TeacherAssignmentCreate: React.FC = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { id } = useParams<{ id: string }>();
  const isEdit = !!id;

  const [bankSubject, setBankSubject] = useState<Subject | 'all'>('all');
  const [searchKeyword, setSearchKeyword] = useState('');

  const defaultValues: FormValues = {
    title: '',
    subject: 'chinese' as Subject,
    description: '',
    deadline: '',
    isPublished: false,
    allowRetry: false,
    maxSubmissions: 1,
    questionIds: [],
  };

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema) as unknown as Parameters<
      typeof useForm<FormValues>
    >[0]['resolver'],
    defaultValues,
  });

  const { data: assignment, isLoading: loadingAssignment } = useQuery({
    queryKey: ['assignment', id],
    queryFn: () => api.getAssignment(id!),
    enabled: isEdit,
  });

  const selectedSubject = form.watch('subject');
  const selectedIds = form.watch('questionIds') ?? [];

  // 题目列表
  const { data: questionsData, isLoading: loadingQuestions } = useQuery({
    queryKey: ['questions', { subject: bankSubject === 'all' ? undefined : bankSubject }],
    queryFn: () =>
      api.listQuestions({
        subject: bankSubject === 'all' ? undefined : bankSubject,
        pageSize: 100,
      }),
  });

  const allQuestions: Question[] = questionsData?.items ?? [];

  // 按学科和关键词过滤
  const filteredQuestions = useMemo(() => {
    if (!searchKeyword.trim()) return allQuestions;
    const kw = searchKeyword.toLowerCase();
    return allQuestions.filter(
      (q) => q.title.toLowerCase().includes(kw),
    );
  }, [allQuestions, searchKeyword]);

  const selectedQuestions = useMemo(() => {
    const map = new Map(allQuestions.map((q) => [q.id, q]));
    return selectedIds
      .map((qid) => map.get(qid))
      .filter((q): q is Question => !!q);
  }, [allQuestions, selectedIds]);

  // 预填充
  useMemo(() => {
    if (assignment && isEdit) {
      form.reset({
        title: assignment.title,
        subject: assignment.subject,
        description: assignment.description,
        deadline: assignment.deadline ?? '',
        isPublished: assignment.isPublished,
        allowRetry: assignment.allowRetry ?? false,
        maxSubmissions: assignment.maxSubmissions ?? 1,
        questionIds: assignment.questionIds ?? [],
      });
      setBankSubject(assignment.subject);
    }
  }, [assignment, isEdit, form]);

  const toggleQuestion = (qid: string) => {
    const current = form.getValues('questionIds') ?? [];
    const idx = current.indexOf(qid);
    if (idx >= 0) {
      const next = [...current];
      next.splice(idx, 1);
      form.setValue('questionIds', next, { shouldDirty: true });
    } else {
      form.setValue('questionIds', [...current, qid], { shouldDirty: true });
    }
  };

  const moveQuestion = (index: number, direction: 'up' | 'down') => {
    const current = [...(form.getValues('questionIds') ?? [])];
    const target = direction === 'up' ? index - 1 : index + 1;
    if (target < 0 || target >= current.length) return;
    [current[index], current[target]] = [current[target], current[index]];
    form.setValue('questionIds', current, { shouldDirty: true });
  };

  const removeQuestion = (qid: string) => {
    const current = form.getValues('questionIds') ?? [];
    form.setValue(
      'questionIds',
      current.filter((q) => q !== qid),
      { shouldDirty: true },
    );
  };

  const createMutation = useMutation({
    mutationFn: (body: Parameters<typeof api.createAssignment>[0]) =>
      api.createAssignment(body),
    retry: false,
    onSuccess: () => {
      toast.success('作业已创建');
      queryClient.invalidateQueries({ queryKey: ['assignments'] });
      navigate('/teacher/assignments');
    },
    onError: (error) => {
      logger.error('创建作业失败', error);
      toast.error(getApiErrorMessage(error, '创建失败'));
    },
  });

  const updateMutation = useMutation({
    mutationFn: (body: Parameters<typeof api.updateAssignment>[1]) =>
      api.updateAssignment(id!, body),
    retry: false,
    onSuccess: () => {
      toast.success('作业已更新');
      queryClient.invalidateQueries({ queryKey: ['assignments'] });
      navigate('/teacher/assignments');
    },
    onError: (error) => {
      logger.error('更新作业失败', error);
      toast.error(getApiErrorMessage(error, '更新失败'));
    },
  });

  const onSubmit = (values: FormValues) => {
    const body = {
      title: values.title,
      subject: values.subject,
      questionIds: values.questionIds,
      description: values.description,
      deadline: values.deadline || null,
      isPublished: values.isPublished,
      allowRetry: values.allowRetry,
      maxSubmissions: values.allowRetry ? values.maxSubmissions : 1,
    } satisfies Parameters<typeof api.createAssignment>[0];

    if (isEdit) {
      updateMutation.mutate(body);
    } else {
      createMutation.mutate(body);
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  if (isEdit && loadingAssignment) {
    return (
      <div className="space-y-6">
        <div className="h-9 w-32 animate-pulse bg-accent rounded-md" />
        <Skeleton className="h-64 w-full rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 标题区 */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)} aria-label="返回">
          <ArrowLeft size={18} />
        </Button>
        <div>
          <h1 className="font-display text-3xl md:text-4xl text-foreground">
            {isEdit ? '编辑作业' : '布置作业'}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {isEdit ? '修改作业信息' : '从题库选题，布置一份新作业'}
          </p>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* 基础信息 */}
          <Card className="rounded-2xl border-card-border">
            <CardContent className="p-6 space-y-5">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      作业标题 <span aria-hidden="true" className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input placeholder="例如：第三单元小测验" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        学科 <span aria-hidden="true" className="text-destructive">*</span>
                      </FormLabel>
                      <Select
                        onValueChange={(v) => {
                          field.onChange(v);
                          setBankSubject(v as Subject);
                        }}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="选择学科" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {SUBJECTS.map((s) => (
                            <SelectItem key={s} value={s}>
                              {SUBJECT_EMOJIS[s]} {SUBJECT_LABELS[s]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="deadline"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>截止时间（选填）</FormLabel>
                      <FormControl>
                        <Input
                          type="datetime-local"
                          {...field}
                          value={field.value || ''}
                        />
                      </FormControl>
                      <FormDescription>留空表示不限时</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>作业说明（选填）</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="写一写作业要求、注意事项..."
                        className="min-h-[80px] resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="isPublished"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border border-border p-4">
                    <div>
                      <FormLabel className="!mb-0">发布作业</FormLabel>
                      <FormDescription>
                        发布后学生可通过访问码进入答题
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="allowRetry"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border border-border p-4">
                    <div>
                      <FormLabel className="!mb-0">允许重做</FormLabel>
                      <FormDescription>
                        开启后学生可以多次提交作业
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              {form.watch('allowRetry') && (
                <FormField
                  control={form.control}
                  name="maxSubmissions"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>最大提交次数</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min={1}
                          max={10}
                          {...field}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            field.onChange(Math.min(10, Math.max(1, val || 1)));
                          }}
                          className="max-w-[120px]"
                        />
                      </FormControl>
                      <FormDescription>范围 1-10 次</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </CardContent>
          </Card>

          {/* 题目选择 */}
          <Card className="rounded-2xl border-card-border">
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-foreground">选择题目</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    已选 <span className="tnum font-medium text-foreground">{selectedIds.length}</span> 道题
                  </p>
                </div>
              </div>

              {/* 筛选题库 */}
              <div className="flex flex-wrap gap-3 items-center p-3 bg-accent/30 rounded-xl">
                <span className="text-sm text-muted-foreground">题库筛选：</span>
                <Select
                  value={bankSubject}
                  onValueChange={(v) => setBankSubject(v as Subject | 'all')}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="全部学科" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部学科</SelectItem>
                    {SUBJECTS.map((s) => (
                      <SelectItem key={s} value={s}>
                        {SUBJECT_EMOJIS[s]} {SUBJECT_LABELS[s]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="relative flex-1 min-w-[200px]">
                  <Search
                    size={16}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                  />
                  <Input
                    placeholder="搜索题干..."
                    className="pl-9"
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                  />
                </div>
              </div>

              {/* 题库列表 */}
              <div className="max-h-[360px] overflow-y-auto space-y-2 pr-1 -mr-1">
                {loadingQuestions ? (
                  <div className="space-y-2">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <Skeleton key={i} className="h-14 w-full rounded-lg" />
                    ))}
                  </div>
                ) : filteredQuestions.length === 0 ? (
                  <div className="py-8 text-center">
                    <FileQuestion
                      size={32}
                      className="mx-auto text-muted-foreground mb-2"
                    />
                    <p className="text-sm text-muted-foreground">
                      暂无符合条件的题目
                    </p>
                  </div>
                ) : (
                  filteredQuestions.map((q) => {
                    const checked = selectedIds.includes(q.id);
                    return (
                      <div
                        key={q.id}
                        onClick={() => toggleQuestion(q.id)}
                        className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                          checked
                            ? 'border-primary bg-primary/5'
                            : 'border-border hover:bg-accent/50'
                        }`}
                        role="button"
                        tabIndex={0}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') toggleQuestion(q.id);
                        }}
                      >
                        <div className="pt-0.5">
                          <Checkbox checked={checked} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-foreground line-clamp-2">
                            {q.title}
                          </p>
                          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                            <Badge
                              variant="outline"
                              className={`${subjectColor[q.subject]} border-0 rounded-full text-[11px]`}
                            >
                              {SUBJECT_EMOJIS[q.subject]}{' '}
                              {SUBJECT_LABELS[q.subject]}
                            </Badge>
                            <Badge
                              variant="secondary"
                              className="rounded-full text-[11px]"
                            >
                              {QUESTION_TYPE_LABELS[q.type]}
                            </Badge>
                            <span className="text-[11px] text-muted-foreground">
                              {DIFFICULTY_LABELS[q.difficulty]}
                            </span>
                          </div>
                        </div>
                        {checked && (
                          <div className="text-primary flex-shrink-0">
                            <Check size={18} />
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </CardContent>
          </Card>

          {/* 已选题目排序 */}
          {selectedQuestions.length > 0 && (
            <Card className="rounded-2xl border-card-border">
              <CardContent className="p-6 space-y-3">
                <h3 className="font-medium text-foreground">已选题目（可调整顺序）</h3>
                <div className="space-y-2">
                  {selectedQuestions.map((q, index) => (
                    <div
                      key={q.id}
                      className="flex items-center gap-3 p-3 rounded-lg bg-accent/30 border border-border"
                    >
                      <div className="h-7 w-7 rounded-md bg-primary/10 text-primary flex items-center justify-center text-sm font-medium tnum flex-shrink-0">
                        {index + 1}
                      </div>
                      <p className="flex-1 text-sm text-foreground line-clamp-1 min-w-0">
                        {q.title}
                      </p>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={() => moveQuestion(index, 'up')}
                          disabled={index === 0}
                          aria-label="上移"
                          className="h-7 w-7 p-0"
                        >
                          <ChevronUp size={16} />
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={() => moveQuestion(index, 'down')}
                          disabled={index === selectedQuestions.length - 1}
                          aria-label="下移"
                          className="h-7 w-7 p-0"
                        >
                          <ChevronDown size={16} />
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={() => removeQuestion(q.id)}
                          aria-label="移除"
                          className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* 底部操作 */}
          <div className="flex items-center justify-end gap-3 sticky bottom-0 z-10 py-3 bg-background/90 backdrop-blur-sm border-t border-border -mx-4 sm:-mx-6 px-4 sm:px-6">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate('/teacher/assignments')}
            >
              取消
            </Button>
            <Button type="submit" disabled={isPending}>
              {isPending && <Loader2 size={16} className="animate-spin" />}
              {isEdit ? '保存修改' : '创建作业'}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default TeacherAssignmentCreate;
