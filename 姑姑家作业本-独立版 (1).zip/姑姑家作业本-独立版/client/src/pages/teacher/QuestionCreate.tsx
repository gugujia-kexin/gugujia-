import { useEffect } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, Loader2 } from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import * as api from '@/api';
import { getApiErrorMessage } from '@/lib/api-error';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import { Checkbox } from '@client/src/components/ui/checkbox';
import {
  SUBJECTS,
  SUBJECT_LABELS,
  SUBJECT_EMOJIS,
  QUESTION_TYPES,
  QUESTION_TYPE_LABELS,
  DIFFICULTIES,
  DIFFICULTY_LABELS,
  type Subject,
  type QuestionType,
  type Difficulty,
  type QuestionOption,
} from '@shared/api.interface';

const formSchema = z.object({
  subject: z.string().min(1, '请选择学科'),
  type: z.string().min(1, '请选择题型'),
  difficulty: z.string().min(1, '请选择难度'),
  title: z.string().min(1, '请输入题干'),
  options: z.array(z.object({ label: z.string(), value: z.string() })),
  correctAnswer: z.string().min(1, '请填写正确答案'),
  correctAnswers: z.array(z.string()),
  explanation: z.string(),
  tags: z.string(),
});

type FormValues = {
  subject: Subject;
  type: QuestionType;
  difficulty: Difficulty;
  title: string;
  options: QuestionOption[];
  correctAnswer: string;
  correctAnswers: string[];
  explanation: string;
  tags: string;
};

const optionLabels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

const TeacherQuestionCreate: React.FC = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { id } = useParams<{ id: string }>();
  const isEdit = !!id;

  const defaultValues: FormValues = {
    subject: 'chinese' as Subject,
    type: 'choice' as QuestionType,
    difficulty: 'medium' as Difficulty,
    title: '',
    options: [
      { label: 'A', value: '' },
      { label: 'B', value: '' },
    ],
    correctAnswer: '',
    correctAnswers: [],
    explanation: '',
    tags: '',
  };

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema) as unknown as Parameters<
      typeof useForm<FormValues>
    >[0]['resolver'],
    defaultValues,
  });

  const { fields, append, remove, update } = useFieldArray({
    control: form.control,
    name: 'options',
  });

  const questionType = form.watch('type');
  const showOptions = questionType === 'choice' || questionType === 'multi_choice';

  const { data: question, isLoading: loadingQuestion } = useQuery({
    queryKey: ['question', id],
    queryFn: () => api.getQuestion(id!),
    enabled: isEdit,
  });

  useEffect(() => {
    if (question && isEdit) {
      const opts = (question.options ?? []) as QuestionOption[];
      form.reset({
        subject: question.subject,
        type: question.type,
        difficulty: question.difficulty,
        title: question.title,
        options: opts.length
          ? opts
          : [
              { label: 'A', value: '' },
              { label: 'B', value: '' },
            ],
        correctAnswer: question.type === 'multi_choice' ? '' : question.correctAnswer,
        correctAnswers:
          question.type === 'multi_choice'
            ? question.correctAnswer
                .split(',')
                .map((s: string) => s.trim())
                .filter(Boolean)
            : [],
        explanation: question.explanation,
        tags: (question.tags ?? []).join(', '),
      });
    }
  }, [question, isEdit, form]);

  const createMutation = useMutation({
    mutationFn: (body: Parameters<typeof api.createQuestion>[0]) =>
      api.createQuestion(body),
    retry: false,
    onSuccess: () => {
      toast.success('题目已创建');
      queryClient.invalidateQueries({ queryKey: ['questions'] });
      navigate('/teacher/questions');
    },
    onError: (error) => {
      logger.error('创建题目失败', error);
      toast.error(getApiErrorMessage(error, '创建失败'));
    },
  });

  const updateMutation = useMutation({
    mutationFn: (body: Parameters<typeof api.updateQuestion>[1]) =>
      api.updateQuestion(id!, body),
    retry: false,
    onSuccess: () => {
      toast.success('题目已更新');
      queryClient.invalidateQueries({ queryKey: ['questions'] });
      navigate('/teacher/questions');
    },
    onError: (error) => {
      logger.error('更新题目失败', error);
      toast.error(getApiErrorMessage(error, '更新失败'));
    },
  });

  const addOption = () => {
    const nextLabel = optionLabels[fields.length] || String(fields.length + 1);
    append({ label: nextLabel, value: '' });
  };

  const onSubmit = (values: FormValues) => {
    let correctAnswer = values.correctAnswer;
    if (values.type === 'multi_choice') {
      correctAnswer = values.correctAnswers.join(',');
    }
    if (values.type === 'true_false') {
      correctAnswer = values.correctAnswer;
    }

    const tags = values.tags
      .split(/[,，\n]/)
      .map((t) => t.trim())
      .filter(Boolean);

    const body = {
      subject: values.subject,
      type: values.type,
      difficulty: values.difficulty,
      title: values.title,
      options: showOptions ? values.options.filter((o) => o.value.trim()) : [],
      correctAnswer,
      explanation: values.explanation,
      tags,
    } satisfies Parameters<typeof api.createQuestion>[0];

    if (isEdit) {
      updateMutation.mutate(body);
    } else {
      createMutation.mutate(body);
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  if (isEdit && loadingQuestion) {
    return (
      <div className="space-y-6">
        <div className="h-9 w-32 animate-pulse bg-accent rounded-md" />
        <Card className="rounded-2xl">
          <CardContent className="p-6 space-y-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="space-y-2">
                <div className="h-4 w-20 bg-accent rounded animate-pulse" />
                <div className="h-9 w-full bg-accent rounded animate-pulse" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 标题区 */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)} aria-label="返回">
          <ArrowLeft size={18} />
        </Button>
        <div>
          <h1 className="font-display text-3xl md:text-4xl text-foreground">
            {isEdit ? '编辑题目' : '新建题目'}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {isEdit ? '修改题目信息' : '录入一道新题目到题库'}
          </p>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card className="rounded-2xl border-card-border">
            <CardContent className="p-6 space-y-5">
              {/* 学科 / 题型 / 难度 */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>学科</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="选择学科" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {SUBJECTS.map((s) => (
                            <SelectItem key={s} value={s}>
                              {SUBJECT_EMOJIS[s]} {SUBJECT_LABELS[s]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>题型</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="选择题型" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {QUESTION_TYPES.map((t) => (
                            <SelectItem key={t} value={t}>
                              {QUESTION_TYPE_LABELS[t]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="difficulty"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>难度</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="选择难度" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {DIFFICULTIES.map((d) => (
                            <SelectItem key={d} value={d}>
                              {DIFFICULTY_LABELS[d]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* 题干 */}
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>题干</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="请输入题目内容..."
                        className="min-h-[100px] resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* 选项区（仅 choice / multi_choice） */}
              {showOptions && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <FormLabel className="!mb-0">选项</FormLabel>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addOption}
                      disabled={fields.length >= 8}
                    >
                      <Plus size={14} />
                      添加选项
                    </Button>
                  </div>

                  <div className="space-y-2">
                    {fields.map((field, index) => (
                      <div key={field.id} className="flex items-center gap-2">
                        <div className="h-9 w-9 flex items-center justify-center rounded-md bg-accent text-sm font-medium text-muted-foreground flex-shrink-0">
                          {optionLabels[index] || String(index + 1)}
                        </div>
                        <Input
                          placeholder={`选项 ${optionLabels[index] || index + 1} 的内容`}
                          className="flex-1"
                          {...form.register(`options.${index}.value` as const)}
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            if (fields.length <= 2) return;
                            remove(index);
                          }}
                          disabled={fields.length <= 2}
                          aria-label="删除选项"
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    ))}
                  </div>
                  <FormDescription>至少 2 个选项，最多 8 个</FormDescription>
                </div>
              )}

              {/* 正确答案（根据题型不同） */}
              {questionType === 'choice' && (
                <FormField
                  control={form.control}
                  name="correctAnswer"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>正确答案</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ''}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="选择正确选项" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {fields.map((_, index) => (
                            <SelectItem
                              key={index}
                              value={optionLabels[index] || String(index + 1)}
                            >
                              选项 {optionLabels[index] || index + 1}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {questionType === 'multi_choice' && (
                <FormField
                  control={form.control}
                  name="correctAnswers"
                  render={() => (
                    <FormItem>
                      <FormLabel>正确答案（多选）</FormLabel>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {fields.map((_, index) => {
                          const label = optionLabels[index] || String(index + 1);
                          const current = form.getValues('correctAnswers') ?? [];
                          const checked = current.includes(label);
                          return (
                            <label
                              key={index}
                              className="flex items-center gap-2 p-3 rounded-lg border border-border hover:bg-accent/50 cursor-pointer transition-colors"
                            >
                              <Checkbox
                                checked={checked}
                                onCheckedChange={(v) => {
                                  const now = [...current];
                                  if (v) {
                                    now.push(label);
                                  } else {
                                    const i = now.indexOf(label);
                                    if (i >= 0) now.splice(i, 1);
                                  }
                                  form.setValue('correctAnswers', now, {
                                    shouldValidate: true,
                                  });
                                }}
                              />
                              <span className="text-sm">选项 {label}</span>
                            </label>
                          );
                        })}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {questionType === 'true_false' && (
                <FormField
                  control={form.control}
                  name="correctAnswer"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>正确答案</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ''}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="选择对或错" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="true">✓ 正确</SelectItem>
                          <SelectItem value="false">✗ 错误</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {questionType === 'fill' && (
                <FormField
                  control={form.control}
                  name="correctAnswer"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>参考答案</FormLabel>
                      <FormControl>
                        <Input placeholder="请输入参考答案，多个用逗号分隔" {...field} />
                      </FormControl>
                      <FormDescription>支持多个答案，用英文逗号分隔</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {questionType === 'essay' && (
                <FormField
                  control={form.control}
                  name="correctAnswer"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>参考答案</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="请输入简答题的参考答案或评分要点..."
                          className="min-h-[100px] resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>简答题由老师手动批改，此处仅作参考</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {/* 解析 */}
              <FormField
                control={form.control}
                name="explanation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>解析（选填）</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="写一写这道题的讲解思路吧～"
                        className="min-h-[80px] resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* 标签 */}
              <FormField
                control={form.control}
                name="tags"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>标签（选填）</FormLabel>
                    <FormControl>
                      <Input placeholder="用逗号或回车分隔，如：重点, 常考" {...field} />
                    </FormControl>
                    <FormDescription>便于之后按标签检索题目</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* 底部操作 */}
          <div className="flex items-center justify-end gap-3 sticky bottom-0 z-10 py-3 bg-background/90 backdrop-blur-sm border-t border-border -mx-4 sm:-mx-6 px-4 sm:px-6">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate('/teacher/questions')}
            >
              取消
            </Button>
            <Button type="submit" disabled={isPending}>
              {isPending && <Loader2 size={16} className="animate-spin" />}
              {isEdit ? '保存修改' : '创建题目'}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default TeacherQuestionCreate;
