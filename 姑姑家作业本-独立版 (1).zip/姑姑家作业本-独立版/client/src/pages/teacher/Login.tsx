import { useState, FormEvent } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Lock, ArrowLeft, Sparkles } from 'lucide-react';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import { useTeacherAuth } from '@client/src/hooks/useTeacherAuth';
import logoUrl from '@/assets/logo.png';
import { Image } from '@client/src/components/ui/image';
import { logger } from '@lark-apaas/client-toolkit/logger';

const TeacherLoginPage = () => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isLoggedIn } = useTeacherAuth();

  const from = (location.state as { from?: { pathname: string } } | null)?.from?.pathname || '/teacher';

  if (isLoggedIn) {
    navigate(from, { replace: true });
  }

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    if (!password.trim()) {
      setError('请输入密码');
      return;
    }
    setSubmitting(true);
    try {
      const ok = await login(password);
      if (ok) {
        navigate(from, { replace: true });
      }
    } catch (err: unknown) {
      logger.error('登录失败', err);
      const msg = (err as { response?: { data?: { error?: { message?: string } } } })
        .response?.data?.error?.message;
      setError(msg || '密码错误，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-6"
      >
        <Image
          src={logoUrl}
          alt="姑姑家 Auntie's Home"
          className="h-20 sm:h-24 w-auto mx-auto"
        />
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="font-display text-3xl sm:text-4xl text-foreground mb-2"
      >
        老师入口
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.15 }}
        className="text-muted-foreground mb-8 flex items-center gap-2"
      >
        <Sparkles size={14} className="text-warm-gold" />
        请输入密码进入
        <Sparkles size={14} className="text-warm-gold" />
      </motion.p>

      <motion.form
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        onSubmit={handleSubmit}
        className="w-full max-w-sm space-y-4"
      >
        <div className="space-y-2 text-left">
          <Label htmlFor="password">密码</Label>
          <div className="relative">
            <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="请输入老师密码"
              className="pl-10 h-12 rounded-xl"
              autoFocus
            />
          </div>
          {error && (
            <motion.p
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="text-sm text-status-wrong mt-2"
            >
              {error}
            </motion.p>
          )}
        </div>

        <Button
          type="submit"
          size="lg"
          className="w-full h-12 rounded-xl text-base btn-bounce"
          disabled={submitting}
        >
          {submitting ? '登录中...' : '进入老师端'}
        </Button>
      </motion.form>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="mt-10"
      >
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft size={16} />
          返回首页
        </Link>
      </motion.div>
    </div>
  );
};

export default TeacherLoginPage;
