import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams, useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { ArrowLeft, User, Send, MessageSquare, Volume2 } from 'lucide-react';
import { Card } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Textarea } from '@client/src/components/ui/textarea';
import { Skeleton } from '@client/src/components/ui/skeleton';
import { Empty, EmptyTitle, EmptyDescription, EmptyMedia } from '@client/src/components/ui/empty';
import * as api from '@/api';
import type { CheckinRecord, CheckinTask } from '@shared/api.interface';

const CheckinRecords: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [commentMap, setCommentMap] = useState<Record<string, string>>({});

  const { data: task, isLoading: taskLoading } = useQuery({
    queryKey: ['checkinTask', id],
    queryFn: () => api.getCheckinTask(id!),
    enabled: !!id,
  });

  const { data: records, isLoading: recordsLoading, isError, error } = useQuery({
    queryKey: ['checkinRecords', id],
    queryFn: () => api.listCheckinRecords(id!),
    enabled: !!id,
  });

  const commentMutation = useMutation({
    mutationFn: ({ recordId, teacherComment }: { recordId: string; teacherComment: string }) =>
      api.commentCheckin(recordId, { teacherComment }),
    retry: false,
    onSuccess: (_, variables) => {
      toast.success('点评已提交');
      queryClient.invalidateQueries({ queryKey: ['checkinRecords', id] });
      setCommentMap(prev => {
        const next = { ...prev };
        delete next[variables.recordId];
        return next;
      });
    },
    onError: (err: any) => {
      const msg = err.response?.data?.error?.message || '提交失败，请稍后重试';
      toast.error(msg);
      logger.error('提交点评失败', err);
    },
  });

  const isLoading = taskLoading || recordsLoading;

  if (isError) {
    logger.error('加载打卡记录失败', error);
  }

  const handleSubmitComment = (recordId: string) => {
    const comment = commentMap[recordId]?.trim();
    if (!comment) {
      toast.error('请输入评语');
      return;
    }
    commentMutation.mutate({ recordId, teacherComment: comment });
  };

  return (
    <div className="space-y-6">
      {/* 头部 */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)} aria-label="返回">
          <ArrowLeft className="size-5" />
        </Button>
        <div>
          <h1 className="font-display text-2xl text-foreground">打卡记录</h1>
          {task && (
            <p className="text-sm text-muted-foreground mt-0.5">
              {(task as CheckinTask).title}
            </p>
          )}
        </div>
      </div>

      {/* 记录列表 */}
      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="p-5">
              <div className="flex items-start gap-3">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-10 w-full rounded-md" />
                  <Skeleton className="h-4 w-40" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : !records?.length ? (
        <Empty>
          <EmptyMedia variant="icon">
            <MessageSquare className="size-6" />
          </EmptyMedia>
          <EmptyTitle>暂无打卡记录</EmptyTitle>
          <EmptyDescription>学生打卡后会显示在这里</EmptyDescription>
        </Empty>
      ) : (
        <div className="space-y-4" data-ai-section-type="card-list">
          {records.map((record: CheckinRecord) => (
            <Card key={record.id} className="p-5">
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <User className="size-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-foreground">{record.studentName}</h3>
                    <span className="text-xs text-muted-foreground">
                      {new Date(record.submittedAt).toLocaleString('zh-CN')}
                    </span>
                  </div>

                  {/* 录音播放器 */}
                  {record.audioUrl && (
                    <div className="mb-3 flex items-center gap-3 p-3 bg-secondary/40 rounded-lg border border-border">
                      <Volume2 className="size-5 text-primary shrink-0" />
                      <audio
                        controls
                        src={record.audioUrl}
                        className="flex-1 h-8"
                        preload="metadata"
                      >
                        您的浏览器不支持音频播放
                      </audio>
                    </div>
                  )}

                  {/* 文字备注 */}
                  {record.note && (
                    <div className="mb-3 p-3 bg-secondary/30 rounded-lg border border-border">
                      <div className="text-xs text-muted-foreground mb-1">打卡备注</div>
                      <p className="text-foreground text-sm whitespace-pre-wrap">{record.note}</p>
                    </div>
                  )}

                  {/* 老师评语 */}
                  {record.teacherComment ? (
                    <div className="mt-3 pt-3 border-t border-border">
                      <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                        <MessageSquare className="size-3" />
                        老师评语
                      </div>
                      <p className="text-foreground text-sm bg-primary/5 p-3 rounded-lg border border-primary/20">
                        {record.teacherComment}
                      </p>
                    </div>
                  ) : (
                    <div className="mt-3 pt-3 border-t border-border">
                      <div className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                        <MessageSquare className="size-3" />
                        写点评
                      </div>
                      <div className="flex gap-2">
                        <Textarea
                          placeholder="写下你对这位同学的点评..."
                          value={commentMap[record.id] || ''}
                          onChange={(e) => setCommentMap(prev => ({ ...prev, [record.id]: e.target.value }))}
                          rows={2}
                          className="flex-1"
                        />
                        <Button
                          onClick={() => handleSubmitComment(record.id)}
                          disabled={commentMutation.isPending && commentMutation.variables?.recordId === record.id}
                          className="shrink-0 self-end"
                        >
                          <Send className="size-4" />
                          提交
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default CheckinRecords;
