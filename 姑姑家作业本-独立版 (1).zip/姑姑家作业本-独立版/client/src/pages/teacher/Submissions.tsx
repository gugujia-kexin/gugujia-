import { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Search, ChevronRight, Clock, CheckCircle2, User, Trash2 } from 'lucide-react';
import { Card } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import { Input } from '@client/src/components/ui/input';
import { Skeleton } from '@client/src/components/ui/skeleton';
import { Empty, EmptyTitle, EmptyDescription, EmptyMedia } from '@client/src/components/ui/empty';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@client/src/components/ui/select';
import {
  Pagination, PaginationContent, PaginationItem, PaginationLink,
  PaginationPrevious, PaginationNext,
} from '@client/src/components/ui/pagination';
import * as api from '@/api';
import type { Submission, Assignment, SubmissionStatus } from '@shared/api.interface';
import {
  SUBMISSION_STATUS_LABELS,
} from '@shared/api.interface';

const PAGE_SIZE = 10;

const Submissions: React.FC = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [assignmentId, setAssignmentId] = useState<string>('all');
  const [studentName, setStudentName] = useState<string>('');
  const [status, setStatus] = useState<SubmissionStatus | 'all'>('all');
  const [page, setPage] = useState(1);
  const [searchDebounced, setSearchDebounced] = useState('');

  const { data: assignments, isLoading: assignmentsLoading } = useQuery({
    queryKey: ['assignments', { pageSize: 100 }],
    queryFn: () => api.listAssignments({ pageSize: 100 }),
  });

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['submissions', { assignmentId: assignmentId === 'all' ? undefined : assignmentId, studentName: searchDebounced || undefined, status: status === 'all' ? undefined : status, page, pageSize: PAGE_SIZE }],
    queryFn: () => api.listSubmissions({
      assignmentId: assignmentId === 'all' ? undefined : assignmentId,
      studentName: searchDebounced || undefined,
      status: status === 'all' ? undefined : status,
      page,
      pageSize: PAGE_SIZE,
    }),
  });

  useEffect(() => {
    const timer = setTimeout(() => setSearchDebounced(studentName), 300);
    return () => clearTimeout(timer);
  }, [studentName]);

  const totalPages = data ? Math.max(1, Math.ceil(data.total / PAGE_SIZE)) : 1;

  if (isError) {
    logger.error('加载批改列表失败', error);
  }

  const statusBadgeVariant = (s: SubmissionStatus): 'default' | 'secondary' | 'outline' => {
    if (s === 'graded') return 'default';
    return 'secondary';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl text-foreground">批改中心</h1>
      </div>

      {/* 筛选栏 */}
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1">
            <Select value={assignmentId} onValueChange={(v) => { setAssignmentId(v); setPage(1); }}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="选择作业" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部作业</SelectItem>
                {assignments?.items.map((a: Assignment) => (
                  <SelectItem key={a.id} value={a.id}>{a.title}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              placeholder="搜索学生姓名"
              value={studentName}
              onChange={(e) => { setStudentName(e.target.value); setPage(1); }}
              className="pl-9"
            />
          </div>
          <div className="sm:w-40">
            <Select value={status} onValueChange={(v) => { setStatus(v as SubmissionStatus | 'all'); setPage(1); }}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部状态</SelectItem>
                <SelectItem value="submitted">待批改</SelectItem>
                <SelectItem value="graded">已批改</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {/* 列表 */}
      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Card key={i} className="p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 flex-1">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-5 w-24" />
                    <Skeleton className="h-4 w-40" />
                  </div>
                </div>
                <Skeleton className="h-8 w-20 rounded-md" />
              </div>
            </Card>
          ))}
        </div>
      ) : !data?.items.length ? (
        <Empty>
          <EmptyMedia variant="icon">
            <Clock className="size-6" />
          </EmptyMedia>
          <EmptyTitle>暂无提交记录</EmptyTitle>
          <EmptyDescription>学生提交后会在这里显示</EmptyDescription>
        </Empty>
      ) : (
        <div className="space-y-3">
          {data.items.map((s: Submission) => {
            const assignment = assignments?.items.find((a: Assignment) => a.id === s.assignmentId);
            return (
              <Card key={s.id} className="p-5 hover-elevate transition-all cursor-pointer" onClick={() => navigate(`/teacher/submissions/${s.id}`)}>
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4 min-w-0 flex-1">
                    <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <User className="size-5 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-lg font-semibold text-foreground truncate">{s.studentName}</h3>
                        <Badge
                          variant={statusBadgeVariant(s.status)}
                          className={s.status === 'submitted' ? 'bg-amber-100 text-amber-700 border-amber-200' : 'bg-green-100 text-green-700 border-green-200'}
                        >
                          {s.status === 'submitted' && <Clock className="size-3 mr-1" />}
                          {s.status === 'graded' && <CheckCircle2 className="size-3 mr-1" />}
                          {SUBMISSION_STATUS_LABELS[s.status]}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {assignment?.title ?? '作业'}
                      </p>
                      <div className="flex items-center gap-3 mt-1.5 text-sm">
                        <span className="text-muted-foreground">
                          自动得分：<span className="tnum font-medium text-foreground">{s.autoScore}</span>
                        </span>
                        {s.teacherScore !== null && (
                          <span className="text-muted-foreground">
                            老师得分：<span className="tnum font-medium text-primary">{s.teacherScore}</span>
                          </span>
                        )}
                        <span className="text-muted-foreground text-xs ml-auto">
                          {new Date(s.submittedAt).toLocaleString('zh-CN')}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      aria-label="删除这条提交"
                      className="text-muted-foreground hover:text-destructive"
                      onClick={async (e) => {
                        e.stopPropagation();
                        if (!window.confirm(`删掉「${s.studentName}」这条提交？删了不能恢复。`)) return;
                        try {
                          await api.deleteSubmission(s.id);
                          queryClient.invalidateQueries();
                        } catch {
                          logger.error('删除提交失败', s.id);
                        }
                      }}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="shrink-0">
                      去批改
                      <ChevronRight className="size-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}

          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                    className={page <= 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                  />
                </PaginationItem>
                {Array.from({ length: totalPages }).map((_, i) => (
                  <PaginationItem key={i}>
                    <PaginationLink
                      isActive={page === i + 1}
                      onClick={() => setPage(i + 1)}
                      className="cursor-pointer"
                    >
                      {i + 1}
                    </PaginationLink>
                  </PaginationItem>
                ))}
                <PaginationItem>
                  <PaginationNext
                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                    className={page >= totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </div>
      )}
    </div>
  );
};

export default Submissions;
