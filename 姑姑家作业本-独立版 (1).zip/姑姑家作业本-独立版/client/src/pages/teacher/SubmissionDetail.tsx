import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams, useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { ArrowLeft, Check, X, BookOpen, Clock, CheckCircle2 } from 'lucide-react';
import { Card } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import { Skeleton } from '@client/src/components/ui/skeleton';
import { Label } from '@client/src/components/ui/label';
import * as api from '@/api';
import type { Submission, Question, Answer } from '@shared/api.interface';
import {
  SUBJECT_LABELS, QUESTION_TYPE_LABELS, DIFFICULTY_LABELS,
  SUBMISSION_STATUS_LABELS,
} from '@shared/api.interface';

const SubmissionDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [teacherScore, setTeacherScore] = useState('');
  const [teacherComment, setTeacherComment] = useState('');

  const { data: submission, isLoading, isError, error } = useQuery({
    queryKey: ['submission', id],
    queryFn: () => api.getSubmission(id!),
    enabled: !!id,
  });

  const gradeMutation = useMutation({
    mutationFn: () => api.gradeSubmission(id!, {
      teacherScore: Number(teacherScore),
      teacherComment,
    }),
    retry: false,
    onSuccess: () => {
      toast.success('批改已提交');
      queryClient.invalidateQueries({ queryKey: ['submission', id] });
      queryClient.invalidateQueries({ queryKey: ['submissions'] });
    },
    onError: (err: any) => {
      const msg = err.response?.data?.error?.message || '提交失败，请稍后重试';
      toast.error(msg);
      logger.error('提交批改失败', err);
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-40" />
        <Card className="p-6">
          <Skeleton className="h-8 w-64 mb-4" />
          <Skeleton className="h-4 w-48 mb-2" />
          <Skeleton className="h-4 w-32" />
        </Card>
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i} className="p-6">
            <Skeleton className="h-6 w-32 mb-3" />
            <Skeleton className="h-5 w-full mb-2" />
            <Skeleton className="h-5 w-3/4" />
          </Card>
        ))}
      </div>
    );
  }

  if (isError || !submission) {
    logger.error('加载提交详情失败', error);
    return (
      <div className="text-center py-16 text-muted-foreground">
        加载失败，请返回重试
      </div>
    );
  }

  const s: Submission = submission;
  const questions: Question[] = s.questions ?? [];
  const answers: Answer[] = s.answers ?? [];
  const answerMap = new Map(answers.map(a => [a.questionId, a]));

  const handleSubmit = () => {
    if (teacherScore === '' || isNaN(Number(teacherScore))) {
      toast.error('请输入有效的老师得分');
      return;
    }
    gradeMutation.mutate();
  };

  return (
    <div className="space-y-6">
      {/* 返回按钮 + 标题 */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)} aria-label="返回">
          <ArrowLeft className="size-5" />
        </Button>
        <h1 className="font-display text-2xl text-foreground">批改详情</h1>
      </div>

      {/* 顶部信息卡 */}
      <Card className="p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
          <div>
            <h2 className="text-xl font-semibold text-foreground mb-1">{s.studentName}</h2>
            <p className="text-muted-foreground text-sm">
              <BookOpen className="size-4 inline mr-1 -mt-0.5" />
              作业：{questions.length > 0 ? '已加载题目' : '作业详情'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Badge
              variant="secondary"
              className={s.status === 'submitted' ? 'bg-amber-100 text-amber-700 border-amber-200' : 'bg-green-100 text-green-700 border-green-200'}
            >
              {s.status === 'submitted' && <Clock className="size-3 mr-1" />}
              {s.status === 'graded' && <CheckCircle2 className="size-3 mr-1" />}
              {SUBMISSION_STATUS_LABELS[s.status]}
            </Badge>
          </div>
        </div>
        <div className="flex flex-wrap gap-6 text-sm">
          <div>
            <span className="text-muted-foreground">提交时间：</span>
            <span className="text-foreground">{new Date(s.submittedAt).toLocaleString('zh-CN')}</span>
          </div>
          <div>
            <span className="text-muted-foreground">自动得分：</span>
            <span className="tnum font-medium text-foreground">{s.autoScore}</span>
          </div>
          {s.teacherScore !== null && (
            <div>
              <span className="text-muted-foreground">老师得分：</span>
              <span className="tnum font-medium text-primary">{s.teacherScore}</span>
            </div>
          )}
        </div>
      </Card>

      {/* 题目列表 */}
      <div className="space-y-4">
        <h3 className="font-display text-lg text-foreground">答题详情</h3>
        {questions.map((q: Question, idx: number) => {
          const ans = answerMap.get(q.id);
          const isCorrect = ans?.isCorrect;
          return (
            <Card key={q.id} className="p-5">
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary/10 text-primary text-sm font-medium">
                    {idx + 1}
                  </span>
                  <Badge variant="outline" className="text-xs">
                    {SUBJECT_LABELS[q.subject]}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {QUESTION_TYPE_LABELS[q.type]}
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {DIFFICULTY_LABELS[q.difficulty]}
                  </Badge>
                </div>
                {isCorrect !== null && isCorrect !== undefined && (
                  <div className={`flex items-center gap-1 text-sm font-medium ${isCorrect ? 'text-green-600' : 'text-red-500'}`}>
                    {isCorrect ? <Check className="size-4" /> : <X className="size-4" />}
                    {isCorrect ? '正确' : '错误'}
                  </div>
                )}
              </div>
              <p className="text-foreground mb-4 leading-relaxed">{q.title}</p>

              {q.options && q.options.length > 0 && (
                <div className="space-y-2 mb-4 pl-2">
                  {q.options.map((opt) => (
                    <div key={opt.label} className="text-sm text-muted-foreground">
                      <span className="font-medium text-foreground mr-2">{opt.label}.</span>
                      {opt.value}
                    </div>
                  ))}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-border">
                <div>
                  <div className="text-xs text-muted-foreground mb-1">学生答案</div>
                  <div className="text-foreground font-medium min-h-[1.5rem]">
                    {ans?.studentAnswer || <span className="text-muted-foreground italic">未作答</span>}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-1">正确答案</div>
                  <div className="text-green-600 font-medium min-h-[1.5rem]">
                    {q.correctAnswer}
                  </div>
                </div>
              </div>

              {ans && (
                <div className="mt-3 pt-3 border-t border-border text-sm">
                  <span className="text-muted-foreground">自动得分：</span>
                  <span className="tnum font-medium text-foreground">{ans.autoPoints}</span>
                </div>
              )}
            </Card>
          );
        })}
      </div>

      {/* 老师批改区 */}
      <Card className="p-6 border-2 border-primary/20">
        <h3 className="font-display text-lg text-foreground mb-4">老师批改</h3>
        <div className="space-y-4">
          <div>
            <Label htmlFor="teacherScore" className="mb-1.5 block">老师给分</Label>
            <Input
              id="teacherScore"
              type="number"
              placeholder="请输入分数"
              value={teacherScore || (s.teacherScore !== null ? s.teacherScore : '')}
              onChange={(e) => setTeacherScore(e.target.value)}
              className="max-w-xs"
            />
          </div>
          <div>
            <Label htmlFor="teacherComment" className="mb-1.5 block">老师评语</Label>
            <Textarea
              id="teacherComment"
              placeholder="写下你对这位同学的评语和建议..."
              value={teacherComment || s.teacherComment || ''}
              onChange={(e) => setTeacherComment(e.target.value)}
              rows={4}
            />
          </div>
          <div className="flex justify-end">
            <Button onClick={handleSubmit} disabled={gradeMutation.isPending}>
              {gradeMutation.isPending ? '提交中...' : '提交批改'}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default SubmissionDetail;
