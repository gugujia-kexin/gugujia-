import { useState, FormEvent } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { UserCheck, Trash2, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { Card } from '@client/src/components/ui/card';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import { Skeleton } from '@client/src/components/ui/skeleton';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import { Empty, EmptyTitle, EmptyDescription } from '@client/src/components/ui/empty';
import {
  listParents, createParent, deleteParent,
} from '@client/src/api';

const Parents: React.FC = () => {
  const queryClient = useQueryClient();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [studentName, setStudentName] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const { data: parents, isLoading } = useQuery({
    queryKey: ['parents'],
    queryFn: listParents,
  });

  const handleCreate = async (e: FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim() || !studentName.trim()) {
      toast.error('请填写账号、密码和绑定的学生姓名');
      return;
    }
    if (password.length < 6) {
      toast.error('密码至少 6 位');
      return;
    }
    setSubmitting(true);
    try {
      await createParent({ username: username.trim(), password, studentName: studentName.trim() });
      toast.success('家长账号已创建');
      setUsername(''); setPassword(''); setStudentName('');
      queryClient.invalidateQueries({ queryKey: ['parents'] });
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { error?: { message?: string } } } })
        .response?.data?.error?.message;
      toast.error(msg || '创建失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!window.confirm(`确定删除家长「${name}」的账号吗？`)) return;
    try {
      await deleteParent(id);
      toast.success('已删除');
      queryClient.invalidateQueries({ queryKey: ['parents'] });
    } catch {
      toast.error('删除失败');
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl text-foreground flex items-center gap-2">
          <UserCheck size={24} className="text-warm-gold" /> 家长账号
        </h1>
        <p className="text-muted-foreground text-sm mt-1">给家长开通账号，他们登录后只能看到自己孩子的作业、成绩、评语和打卡记录。</p>
      </div>

      <Card className="p-4 sm:p-5">
        <form onSubmit={handleCreate} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="space-y-2">
            <Label htmlFor="p-username">家长账号</Label>
            <Input id="p-username" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="如 张妈妈" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="p-password">初始密码（至少 6 位）</Label>
            <Input id="p-password" type="text" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="发给家长" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="p-student">绑定学生姓名</Label>
            <Input id="p-student" value={studentName} onChange={(e) => setStudentName(e.target.value)} placeholder="与学生端姓名一致" />
          </div>
          <div className="sm:col-span-3">
            <Button type="submit" className="w-full sm:w-auto" disabled={submitting}>
              <ShieldCheck size={16} className="mr-2" /> {submitting ? '创建中...' : '创建家长账号'}
            </Button>
          </div>
        </form>
      </Card>

      {isLoading ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}
        </div>
      ) : (parents ?? []).length === 0 ? (
        <Empty>
          <EmptyTitle>还没有家长账号</EmptyTitle>
          <EmptyDescription>在上方填写账号、密码和学生姓名即可开通。</EmptyDescription>
        </Empty>
      ) : (
        <div className="space-y-3">
          {(parents ?? []).map((p) => (
            <Card key={p.id} className="p-4 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{p.username}</span>
                  <Badge variant="secondary">学生：{p.studentName}</Badge>
                </div>
                <div className="text-xs text-muted-foreground mt-1">登录地址：/parent</div>
              </div>
              <Button variant="ghost" size="sm" className="text-status-wrong shrink-0" onClick={() => handleDelete(p.id, p.username)}>
                <Trash2 size={16} />
              </Button>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default Parents;
