import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  FileQuestion,
  AlertTriangle,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import * as api from '@/api';
import { getApiErrorMessage } from '@/lib/api-error';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Badge } from '@client/src/components/ui/badge';
import { Input } from '@client/src/components/ui/input';
import { Skeleton } from '@client/src/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';
import {
  SUBJECTS,
  SUBJECT_LABELS,
  SUBJECT_EMOJIS,
  QUESTION_TYPES,
  QUESTION_TYPE_LABELS,
  DIFFICULTIES,
  DIFFICULTY_LABELS,
  type Subject,
  type QuestionType,
  type Difficulty,
  type Question,
} from '@shared/api.interface';

const difficultyVariant: Record<Difficulty, 'default' | 'secondary' | 'outline'> = {
  easy: 'default',
  medium: 'secondary',
  hard: 'outline',
};

const subjectColor: Record<Subject, string> = {
  chinese: 'bg-[hsl(16_85%_62%)]/15 text-[hsl(16_85%_45%)]',
  math: 'bg-[hsl(220_70%_60%)]/15 text-[hsl(220_70%_45%)]',
  english: 'bg-[hsl(45_95%_50%)]/20 text-[hsl(45_95%_40%)]',
  physics: 'bg-[hsl(260_65%_60%)]/15 text-[hsl(260_65%_45%)]',
  chemistry: 'bg-[hsl(142_65%_50%)]/15 text-[hsl(142_65%_40%)]',
  biology: 'bg-[hsl(145_55%_50%)]/15 text-[hsl(145_55%_40%)]',
  geography: 'bg-[hsl(195_70%_55%)]/15 text-[hsl(195_70%_45%)]',
  history: 'bg-[hsl(30_65%_55%)]/15 text-[hsl(30_65%_40%)]',
  politics: 'bg-[hsl(355_78%_62%)]/15 text-[hsl(355_78%_45%)]',
};

const QuestionsSkeleton = () => (
  <div className="space-y-6">
    <div className="flex items-center justify-between">
      <Skeleton className="h-9 w-32" />
      <Skeleton className="h-9 w-28" />
    </div>
    <div className="flex flex-wrap gap-3">
      {Array.from({ length: 3 }).map((_, i) => (
        <Skeleton key={i} className="h-9 w-28" />
      ))}
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="rounded-2xl border p-5 space-y-3">
          <div className="flex gap-2">
            <Skeleton className="h-5 w-14 rounded-full" />
            <Skeleton className="h-5 w-16 rounded-full" />
          </div>
          <Skeleton className="h-5 w-full" />
          <Skeleton className="h-5 w-4/5" />
          <div className="flex items-center justify-between pt-2">
            <Skeleton className="h-5 w-12 rounded-full" />
            <div className="flex gap-2">
              <Skeleton className="h-7 w-7 rounded-md" />
              <Skeleton className="h-7 w-7 rounded-md" />
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const TeacherQuestions: React.FC = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const subject = (searchParams.get('subject') as Subject) || undefined;
  const type = (searchParams.get('type') as QuestionType) || undefined;
  const difficulty = (searchParams.get('difficulty') as Difficulty) || undefined;

  const { data, isLoading } = useQuery({
    queryKey: ['questions', { subject, type, difficulty }],
    queryFn: () =>
      api.listQuestions({
        subject,
        type,
        difficulty,
        pageSize: 100,
      }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.deleteQuestion(id),
    retry: false,
    onSuccess: () => {
      toast.success('题目已删除');
      queryClient.invalidateQueries({ queryKey: ['questions'] });
      setDeleteId(null);
    },
    onError: (error) => {
      logger.error('删除题目失败', error);
      toast.error(getApiErrorMessage(error, '删除失败'));
    },
  });

  const updateFilter = (key: string, value: string | undefined) => {
    const next = new URLSearchParams(searchParams);
    if (value) {
      next.set(key, value);
    } else {
      next.delete(key);
    }
    setSearchParams(next);
  };

  const handleEdit = (id: string) => {
    navigate(`/teacher/questions/${id}/edit`);
  };

  const questions: Question[] = data?.items ?? [];

  return (
    <div className="space-y-6">
      {/* 标题区 */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="font-display text-3xl md:text-4xl text-foreground">
            题库管理
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            共 {data?.total ?? 0} 道题目
          </p>
        </div>
        <Button onClick={() => navigate('/teacher/questions/new')} data-ai-section-type="button">
          <Plus size={16} />
          新建题目
        </Button>
      </div>

      {/* 筛选区 */}
      <Card className="rounded-2xl border-card-border">
        <CardContent className="p-4 flex flex-wrap gap-3 items-center">
          <div className="flex items-center gap-2 flex-1 min-w-[200px]">
            <Search size={16} className="text-muted-foreground flex-shrink-0" />
            <Input
              placeholder="搜索题干..."
              className="flex-1"
              value={searchParams.get('q') ?? ''}
              onChange={(e) => updateFilter('q', e.target.value || undefined)}
            />
          </div>

          <Select
            value={subject ?? 'all'}
            onValueChange={(v) => updateFilter('subject', v === 'all' ? undefined : v)}
          >
            <SelectTrigger className="w-32">
              <SelectValue placeholder="全部学科" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部学科</SelectItem>
              {SUBJECTS.map((s) => (
                <SelectItem key={s} value={s}>
                  {SUBJECT_EMOJIS[s]} {SUBJECT_LABELS[s]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={type ?? 'all'}
            onValueChange={(v) => updateFilter('type', v === 'all' ? undefined : v)}
          >
            <SelectTrigger className="w-32">
              <SelectValue placeholder="全部题型" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部题型</SelectItem>
              {QUESTION_TYPES.map((t) => (
                <SelectItem key={t} value={t}>
                  {QUESTION_TYPE_LABELS[t]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={difficulty ?? 'all'}
            onValueChange={(v) => updateFilter('difficulty', v === 'all' ? undefined : v)}
          >
            <SelectTrigger className="w-32">
              <SelectValue placeholder="全部难度" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部难度</SelectItem>
              {DIFFICULTIES.map((d) => (
                <SelectItem key={d} value={d}>
                  {DIFFICULTY_LABELS[d]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* 题目卡片列表 */}
      {isLoading ? (
        <QuestionsSkeleton />
      ) : questions.length === 0 ? (
        <Card className="rounded-2xl border-card-border">
          <CardContent className="p-12 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full bg-accent/50 flex items-center justify-center mb-4">
              <FileQuestion size={28} className="text-muted-foreground" />
            </div>
            <h3 className="font-medium text-foreground mb-1">暂无题目</h3>
            <p className="text-sm text-muted-foreground mb-4">
              点击下方按钮创建你的第一道题目吧
            </p>
            <Button onClick={() => navigate('/teacher/questions/new')}>
              <Plus size={16} />
              新建题目
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div
          data-ai-section-type="card-list"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {questions.map((q) => (
            <Card
              key={q.id}
              className="hover-elevate transition-all rounded-2xl border-card-border group"
            >
              <CardContent className="p-5 space-y-3">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge
                    variant="outline"
                    className={`${subjectColor[q.subject]} border-0 rounded-full`}
                  >
                    {SUBJECT_EMOJIS[q.subject]} {SUBJECT_LABELS[q.subject]}
                  </Badge>
                  <Badge variant="secondary" className="rounded-full">
                    {QUESTION_TYPE_LABELS[q.type]}
                  </Badge>
                </div>

                <p className="text-sm text-foreground leading-relaxed line-clamp-2 min-h-[2.5rem]">
                  {q.title}
                </p>

                {q.tags?.length > 0 && (
                  <div className="flex gap-1.5 flex-wrap">
                    {q.tags.slice(0, 3).map((tag: string) => (
                      <span
                        key={tag}
                        className="text-xs px-2 py-0.5 rounded-full bg-accent text-muted-foreground"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}

                <div className="flex items-center justify-between pt-2 border-t border-border mt-2">
                  <Badge
                    variant={difficultyVariant[q.difficulty]}
                    className="rounded-full"
                  >
                    {DIFFICULTY_LABELS[q.difficulty]}
                  </Badge>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(q.id)}
                      aria-label="编辑"
                    >
                      <Pencil size={14} />
                    </Button>
                    <AlertDialog
                      open={deleteId === q.id}
                      onOpenChange={(open) => !open && setDeleteId(null)}
                    >
                      <AlertDialogTrigger asChild>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setDeleteId(q.id)}
                          aria-label="删除"
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 size={14} />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle className="flex items-center gap-2">
                            <AlertTriangle
                              size={20}
                              className="text-destructive"
                            />
                            确认删除？
                          </AlertDialogTitle>
                          <AlertDialogDescription>
                            删除后无法恢复，已关联此题目的作业也会受到影响。
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>取消</AlertDialogCancel>
                          <AlertDialogAction
                            className="bg-destructive hover:bg-destructive/90"
                            onClick={() => deleteMutation.mutate(q.id)}
                            disabled={deleteMutation.isPending}
                          >
                            {deleteMutation.isPending && deleteId === q.id && (
                              <span className="animate-spin mr-1">⏳</span>
                            )}
                            删除
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default TeacherQuestions;
