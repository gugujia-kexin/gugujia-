import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams, useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { ArrowLeft, Save, X } from 'lucide-react';
import { Card } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import { Label } from '@client/src/components/ui/label';
import { Skeleton } from '@client/src/components/ui/skeleton';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@client/src/components/ui/select';
import * as api from '@/api';
import type { KnowledgePoint, Subject, KnowledgeType } from '@shared/api.interface';
import {
  SUBJECTS, SUBJECT_LABELS,
  KNOWLEDGE_TYPES, KNOWLEDGE_TYPE_LABELS,
} from '@shared/api.interface';

const KnowledgeCreate: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const isEdit = !!id;

  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState<Subject | ''>('');
  const [contentType, setContentType] = useState<KnowledgeType | ''>('');
  const [description, setDescription] = useState('');
  const [contentText, setContentText] = useState('');
  const [coverUrl, setCoverUrl] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');

  const { data: knowledge, isLoading } = useQuery({
    queryKey: ['knowledge', id],
    queryFn: () => api.getKnowledge(id!),
    enabled: isEdit,
  });

  useEffect(() => {
    if (knowledge) {
      const k: KnowledgePoint = knowledge;
      setTitle(k.title);
      setSubject(k.subject);
      setContentType(k.contentType);
      setDescription(k.description);
      setContentText(k.contentText);
      setCoverUrl(k.coverUrl);
      setAttachmentUrl(k.attachmentUrl);
    }
  }, [knowledge]);

  const createMutation = useMutation({
    mutationFn: (body: Partial<KnowledgePoint>) =>
      isEdit ? api.updateKnowledge(id!, body) : api.createKnowledge(body),
    retry: false,
    onSuccess: () => {
      toast.success(isEdit ? '知识点已更新' : '知识点已创建');
      queryClient.invalidateQueries({ queryKey: ['knowledge'] });
      navigate('/teacher/knowledge');
    },
    onError: (err: any) => {
      const msg = err.response?.data?.error?.message || '保存失败，请稍后重试';
      toast.error(msg);
      logger.error('保存知识点失败', err);
    },
  });

  const handleSave = () => {
    if (!title.trim()) {
      toast.error('请输入标题');
      return;
    }
    if (!subject) {
      toast.error('请选择学科');
      return;
    }
    if (!contentType) {
      toast.error('请选择内容类型');
      return;
    }
    createMutation.mutate({
      title: title.trim(),
      subject: subject as Subject,
      contentType: contentType as KnowledgeType,
      description,
      contentText,
      coverUrl,
      attachmentUrl,
    });
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-40" />
        <Card className="p-6 space-y-4">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-24 w-full" />
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 头部 */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)} aria-label="返回">
          <ArrowLeft className="size-5" />
        </Button>
        <h1 className="font-display text-2xl text-foreground">
          {isEdit ? '编辑知识点' : '上传知识点'}
        </h1>
      </div>

      <Card className="p-6">
        <div className="space-y-5 max-w-2xl">
          <div>
            <Label htmlFor="title" className="mb-1.5 block">
              标题 <span className="text-red-500">*</span>
            </Label>
            <Input
              id="title"
              placeholder="输入知识点标题"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="subject" className="mb-1.5 block">
                学科 <span className="text-red-500">*</span>
              </Label>
              <Select value={subject} onValueChange={(v) => setSubject(v as Subject)}>
                <SelectTrigger className="w-full" id="subject">
                  <SelectValue placeholder="选择学科" />
                </SelectTrigger>
                <SelectContent>
                  {SUBJECTS.map((s) => (
                    <SelectItem key={s} value={s}>{SUBJECT_LABELS[s]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="contentType" className="mb-1.5 block">
                内容类型 <span className="text-red-500">*</span>
              </Label>
              <Select value={contentType} onValueChange={(v) => setContentType(v as KnowledgeType)}>
                <SelectTrigger className="w-full" id="contentType">
                  <SelectValue placeholder="选择类型" />
                </SelectTrigger>
                <SelectContent>
                  {KNOWLEDGE_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>{KNOWLEDGE_TYPE_LABELS[t]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="description" className="mb-1.5 block">描述</Label>
            <Textarea
              id="description"
              placeholder="简要描述这个知识点..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          {contentType === 'text' && (
            <div>
              <Label htmlFor="contentText" className="mb-1.5 block">内容文本</Label>
              <Textarea
                id="contentText"
                placeholder="输入知识点详细内容..."
                value={contentText}
                onChange={(e) => setContentText(e.target.value)}
                rows={8}
                className="font-mono text-sm"
              />
            </div>
          )}

          <div>
            <Label htmlFor="coverUrl" className="mb-1.5 block">封面图 URL</Label>
            <Input
              id="coverUrl"
              placeholder="https://example.com/cover.jpg"
              value={coverUrl}
              onChange={(e) => setCoverUrl(e.target.value)}
            />
          </div>

          {(contentType === 'image' || contentType === 'video') && (
            <div>
              <Label htmlFor="attachmentUrl" className="mb-1.5 block">
                附件 URL {contentType === 'image' ? '（图片）' : '（视频）'}
              </Label>
              <Input
                id="attachmentUrl"
                placeholder={contentType === 'image' ? 'https://example.com/image.jpg' : 'https://example.com/video.mp4'}
                value={attachmentUrl}
                onChange={(e) => setAttachmentUrl(e.target.value)}
              />
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4 border-t border-border">
            <Button variant="outline" onClick={() => navigate(-1)}>
              <X className="size-4" />
              取消
            </Button>
            <Button onClick={handleSave} disabled={createMutation.isPending}>
              <Save className="size-4" />
              {createMutation.isPending ? '保存中...' : '保存'}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default KnowledgeCreate;
