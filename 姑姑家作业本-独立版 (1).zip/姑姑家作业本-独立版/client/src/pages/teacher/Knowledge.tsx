import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, ImageIcon, FileText, Video, BookOpen } from 'lucide-react';
import { Card } from '@client/src/components/ui/card';
import { Button } from '@client/src/components/ui/button';
import { Badge } from '@client/src/components/ui/badge';
import { Skeleton } from '@client/src/components/ui/skeleton';
import { Empty, EmptyTitle, EmptyDescription, EmptyMedia } from '@client/src/components/ui/empty';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@client/src/components/ui/select';
import {
  AlertDialog, AlertDialogTrigger, AlertDialogContent, AlertDialogHeader,
  AlertDialogTitle, AlertDialogDescription, AlertDialogFooter,
  AlertDialogAction, AlertDialogCancel,
} from '@client/src/components/ui/alert-dialog';
import {
  Pagination, PaginationContent, PaginationItem, PaginationLink,
  PaginationPrevious, PaginationNext,
} from '@client/src/components/ui/pagination';
import * as api from '@/api';
import type { KnowledgePoint, Subject, KnowledgeType } from '@shared/api.interface';
import {
  SUBJECTS, SUBJECT_LABELS,
  KNOWLEDGE_TYPES, KNOWLEDGE_TYPE_LABELS,
} from '@shared/api.interface';
import { Image } from '@client/src/components/ui/image';

const PAGE_SIZE = 8;

const Knowledge: React.FC = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [subject, setSubject] = useState<Subject | 'all'>('all');
  const [contentType, setContentType] = useState<KnowledgeType | 'all'>('all');
  const [page, setPage] = useState(1);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ['knowledge', { subject: subject === 'all' ? undefined : subject, contentType: contentType === 'all' ? undefined : contentType, page, pageSize: PAGE_SIZE }],
    queryFn: () => api.listKnowledge({
      subject: subject === 'all' ? undefined : subject,
      contentType: contentType === 'all' ? undefined : contentType,
      page,
      pageSize: PAGE_SIZE,
    }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.deleteKnowledge(id),
    retry: false,
    onSuccess: () => {
      toast.success('知识点已删除');
      queryClient.invalidateQueries({ queryKey: ['knowledge'] });
      setDeleteId(null);
    },
    onError: (err: any) => {
      const msg = err.response?.data?.error?.message || '删除失败，请稍后重试';
      toast.error(msg);
      logger.error('删除知识点失败', err);
    },
  });

  if (isError) {
    logger.error('加载知识点列表失败', error);
  }

  const totalPages = data ? Math.max(1, Math.ceil(data.total / PAGE_SIZE)) : 1;

  const typeIcon = (type: KnowledgeType) => {
    switch (type) {
      case 'text': return <FileText className="size-5" />;
      case 'image': return <ImageIcon className="size-5" />;
      case 'video': return <Video className="size-5" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl text-foreground">知识点</h1>
        <Button onClick={() => navigate('/teacher/knowledge/new')}>
          <Plus className="size-4" />
          上传知识点
        </Button>
      </div>

      {/* 筛选栏 */}
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1">
            <Select value={subject} onValueChange={(v) => { setSubject(v as Subject | 'all'); setPage(1); }}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="选择学科" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部学科</SelectItem>
                {SUBJECTS.map((s) => (
                  <SelectItem key={s} value={s}>{SUBJECT_LABELS[s]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="sm:w-40">
            <Select value={contentType} onValueChange={(v) => { setContentType(v as KnowledgeType | 'all'); setPage(1); }}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="内容类型" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部类型</SelectItem>
                {KNOWLEDGE_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>{KNOWLEDGE_TYPE_LABELS[t]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {/* 卡片网格 */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="h-40 w-full rounded-none" />
              <div className="p-4 space-y-2">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3" />
              </div>
            </Card>
          ))}
        </div>
      ) : !data?.items.length ? (
        <Empty>
          <EmptyMedia variant="icon">
            <BookOpen className="size-6" />
          </EmptyMedia>
          <EmptyTitle>暂无知识点</EmptyTitle>
          <EmptyDescription>上传第一个知识点吧</EmptyDescription>
        </Empty>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" data-ai-section-type="card-list">
            {data.items.map((k: KnowledgePoint) => (
              <Card key={k.id} className="overflow-hidden hover-elevate transition-all flex flex-col">
                <div className="h-40 bg-secondary/50 flex items-center justify-center relative">
                  {k.coverUrl ? (
                    <Image
                      src={k.coverUrl}
                      alt={k.title}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                      }}
                    />
                  ) : (
                    <div className="text-muted-foreground flex flex-col items-center gap-2">
                      {typeIcon(k.contentType)}
                      <span className="text-xs">暂无封面</span>
                    </div>
                  )}
                  <Badge
                    variant="secondary"
                    className="absolute top-3 left-3 bg-card/90 backdrop-blur-sm"
                  >
                    {KNOWLEDGE_TYPE_LABELS[k.contentType]}
                  </Badge>
                </div>
                <div className="p-5 flex-1 flex flex-col">
                  <h3 className="text-base font-semibold text-foreground line-clamp-2 mb-2">
                    {k.title}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-3 flex-1 mb-4">
                    {k.description || '暂无描述'}
                  </p>
                  <div className="flex items-center justify-between pt-3 border-t border-border">
                    <Badge variant="outline" className="text-xs">
                      {SUBJECT_LABELS[k.subject]}
                    </Badge>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label="编辑"
                        onClick={(e) => { e.stopPropagation(); navigate(`/teacher/knowledge/${k.id}/edit`); }}
                      >
                        <Pencil className="size-4" />
                      </Button>
                      <AlertDialog open={deleteId === k.id} onOpenChange={(open) => !open && setDeleteId(null)}>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            aria-label="删除"
                            onClick={(e) => { e.stopPropagation(); setDeleteId(k.id); }}
                            className="text-red-500 hover:text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>确认删除</AlertDialogTitle>
                            <AlertDialogDescription>
                              确定要删除知识点「{k.title}」吗？此操作不可撤销。
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>取消</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-destructive hover:bg-destructive/90"
                              onClick={() => deleteMutation.mutate(k.id)}
                            >
                              {deleteMutation.isPending ? '删除中...' : '删除'}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                    className={page <= 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                  />
                </PaginationItem>
                {Array.from({ length: totalPages }).map((_, i) => (
                  <PaginationItem key={i}>
                    <PaginationLink
                      isActive={page === i + 1}
                      onClick={() => setPage(i + 1)}
                      className="cursor-pointer"
                    >
                      {i + 1}
                    </PaginationLink>
                  </PaginationItem>
                ))}
                <PaginationItem>
                  <PaginationNext
                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                    className={page >= totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}
    </div>
  );
};

export default Knowledge;
