import React from 'react';
import { Route, Routes } from 'react-router-dom';

import Layout from './components/Layout';
import { TeacherProtectedRoute } from './components/TeacherProtectedRoute';
import HomePage from './pages/Home/HomePage';
import TeacherLoginPage from './pages/teacher/Login';
import TeacherDashboard from './pages/teacher/Dashboard';
import TeacherQuestions from './pages/teacher/Questions';
import TeacherQuestionCreate from './pages/teacher/QuestionCreate';
import TeacherAssignments from './pages/teacher/Assignments';
import TeacherAssignmentCreate from './pages/teacher/AssignmentCreate';
import TeacherSubmissions from './pages/teacher/Submissions';
import TeacherSubmissionDetail from './pages/teacher/SubmissionDetail';
import TeacherStudents from './pages/teacher/Students';
import TeacherKnowledge from './pages/teacher/Knowledge';
import TeacherKnowledgeCreate from './pages/teacher/KnowledgeCreate';
import TeacherCheckin from './pages/teacher/Checkin';
import TeacherCheckinCreate from './pages/teacher/CheckinCreate';
import TeacherCheckinRecords from './pages/teacher/CheckinRecords';
import TeacherParents from './pages/teacher/Parents';

import StudentJoin from './pages/student/Join';
import StudentHome from './pages/student/Home';
import StudentAssignment from './pages/student/Assignment';
import StudentResult from './pages/student/Result';
import StudentKnowledge from './pages/student/Knowledge';
import StudentCheckinJoin from './pages/student/CheckinJoin';
import StudentCheckin from './pages/student/Checkin';
import ParentLoginPage from './pages/parent/Login';
import ParentDashboard from './pages/parent/Dashboard';

import NotFound from './pages/NotFound/NotFound';

const RoutesComponent = () => {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<HomePage />} />

        <Route path="teacher">
          <Route path="login" element={<TeacherLoginPage />} />
          <Route element={<TeacherProtectedRoute />}>
            <Route index element={<TeacherDashboard />} />
            <Route path="questions" element={<TeacherQuestions />} />
            <Route path="questions/new" element={<TeacherQuestionCreate />} />
            <Route path="questions/:id/edit" element={<TeacherQuestionCreate />} />
            <Route path="assignments" element={<TeacherAssignments />} />
            <Route path="assignments/new" element={<TeacherAssignmentCreate />} />
            <Route path="assignments/:id/edit" element={<TeacherAssignmentCreate />} />
            <Route path="submissions" element={<TeacherSubmissions />} />
            <Route path="submissions/:id" element={<TeacherSubmissionDetail />} />
            <Route path="students" element={<TeacherStudents />} />
            <Route path="knowledge" element={<TeacherKnowledge />} />
            <Route path="knowledge/new" element={<TeacherKnowledgeCreate />} />
            <Route path="knowledge/:id/edit" element={<TeacherKnowledgeCreate />} />
            <Route path="checkin" element={<TeacherCheckin />} />
            <Route path="checkin/new" element={<TeacherCheckinCreate />} />
            <Route path="checkin/:id/edit" element={<TeacherCheckinCreate />} />
            <Route path="checkin/:id/records" element={<TeacherCheckinRecords />} />
            <Route path="parents" element={<TeacherParents />} />
          </Route>
        </Route>

        <Route path="parent">
          <Route path="login" element={<ParentLoginPage />} />
          <Route index element={<ParentDashboard />} />
        </Route>

        <Route path="student">
          <Route index element={<StudentJoin />} />
          <Route path="home" element={<StudentHome />} />
          <Route path="assignment/:code" element={<StudentAssignment />} />
          <Route path="result/:id" element={<StudentResult />} />
          <Route path="knowledge" element={<StudentKnowledge />} />
          <Route path="checkin" element={<StudentCheckinJoin />} />
          <Route path="checkin/:code" element={<StudentCheckin />} />
        </Route>
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default RoutesComponent;
