import { useCallback, useEffect, useState } from 'react';
import {
  getTeacherAuthStatus,
  teacherLogin as apiLogin,
  teacherLogout as apiLogout,
  teacherChangePassword as apiChangePassword,
} from '@client/src/api';

export function useTeacherAuth() {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);

  const checkStatus = useCallback(async () => {
    try {
      const data = await getTeacherAuthStatus();
      setIsLoggedIn(data.isLoggedIn);
    } catch {
      setIsLoggedIn(false);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    checkStatus();
  }, [checkStatus]);

  const login = useCallback(async (password: string) => {
    const data = await apiLogin(password);
    if (data.ok) {
      setIsLoggedIn(true);
    }
    return data.ok;
  }, []);

  const logout = useCallback(async () => {
    await apiLogout();
    setIsLoggedIn(false);
  }, []);

  const changePassword = useCallback(async (oldPassword: string, newPassword: string) => {
    const data = await apiChangePassword(oldPassword, newPassword);
    return data.ok;
  }, []);

  return { isLoggedIn, loading, login, logout, changePassword, refresh: checkStatus };
}
