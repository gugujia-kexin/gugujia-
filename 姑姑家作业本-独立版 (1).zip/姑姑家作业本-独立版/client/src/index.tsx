import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { ErrorBoundary } from 'react-error-boundary';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

import RoutesComponent from './app.tsx';
import './index.css';
import { createPortal } from 'react-dom';
import { Toaster } from '@client/src/components/ui/sonner';

const queryClient = new QueryClient({
  defaultOptions: { queries: { refetchOnWindowFocus: false, retry: 1 } },
});

const CLIENT_BASE_PATH = import.meta.env.BASE_URL || '/';

const ErrorFallback = ({ error }: { error: Error }) => (
  <div style={{ padding: 24, fontFamily: 'system-ui', lineHeight: 1.7 }}>
    <h2 style={{ marginBottom: 8 }}>页面出了点问题</h2>
    <p style={{ color: '#8a6b57', marginBottom: 12 }}>
      刷新一下试试，如果一直这样，把下面这行发给我。
    </p>
    <pre style={{ whiteSpace: 'pre-wrap', fontSize: 12, color: '#a1806a' }}>
      {error?.message}
    </pre>
  </div>
);

const MainApp = () => {
  return (
    <BrowserRouter basename={CLIENT_BASE_PATH}>
      <QueryClientProvider client={queryClient}>
        <ErrorBoundary fallbackRender={({ error }) => <ErrorFallback error={error as Error} />}>
          <RoutesComponent />
          {createPortal(<Toaster />, document.body)}
        </ErrorBoundary>
      </QueryClientProvider>
    </BrowserRouter>
  );
};

createRoot(document.getElementById('root')!).render(<MainApp />);
