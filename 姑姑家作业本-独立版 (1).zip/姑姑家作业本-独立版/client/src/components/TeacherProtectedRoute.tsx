import { useEffect } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useTeacherAuth } from '@client/src/hooks/useTeacherAuth';
import { Skeleton } from '@client/src/components/ui/skeleton';

export function TeacherProtectedRoute() {
  const { isLoggedIn, loading } = useTeacherAuth();
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  if (loading || isLoggedIn === null) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-full max-w-md space-y-4">
          <Skeleton className="h-8 w-48 mx-auto rounded" />
          <Skeleton className="h-12 w-full rounded-xl" />
          <Skeleton className="h-12 w-full rounded-xl" />
          <Skeleton className="h-12 w-32 mx-auto rounded-xl" />
        </div>
      </div>
    );
  }

  if (!isLoggedIn) {
    return <Navigate to="/teacher/login" state={{ from: location }} replace />;
  }

  return <Outlet />;
}
