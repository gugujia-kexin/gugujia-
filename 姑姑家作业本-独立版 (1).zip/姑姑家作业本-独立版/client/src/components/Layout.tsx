import { Outlet, useLocation, Link, NavLink } from 'react-router-dom';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BookOpen, GraduationCap, Menu, X,
  FileQuestion, ClipboardList, Users, Lightbulb, Mic, UserCheck,
  Home, LogOut, Phone,
} from 'lucide-react';
import logoUrl from '@/assets/logo.png';
import { Image } from '@client/src/components/ui/image';
import { ChangePasswordDialog } from './ChangePasswordDialog';
import { useTeacherAuth } from '@client/src/hooks/useTeacherAuth';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const Layout = () => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { logout } = useTeacherAuth();
  const isTeacher = location.pathname.startsWith('/teacher') && !location.pathname.startsWith('/teacher/login');
  const isStudent = location.pathname.startsWith('/student');
  const isHome = location.pathname === '/';

  const teacherNav = [
    { to: '/teacher', label: '工作台', icon: Home, end: true },
    { to: '/teacher/questions', label: '题库', icon: FileQuestion },
    { to: '/teacher/assignments', label: '作业', icon: ClipboardList },
    { to: '/teacher/submissions', label: '批改', icon: BookOpen },
    { to: '/teacher/students', label: '学生', icon: Users },
    { to: '/teacher/knowledge', label: '知识点', icon: Lightbulb },
    { to: '/teacher/checkin', label: '打卡', icon: Mic },
    { to: '/teacher/parents', label: '家长', icon: UserCheck },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-x-hidden">
      <div className="brand-watermark" />

      <header className="sticky top-0 z-40 border-b border-border bg-card/90 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 hover-elevate rounded-lg p-1 -m-1">
            <Image
              src={logoUrl}
              alt="姑姑家 Auntie's Home"
              className="h-10 w-auto object-contain"
            />
            <div className="hidden sm:block">
              <div className="font-display text-lg text-foreground leading-tight">
                姑姑家
              </div>
              <div className="text-xs text-muted-foreground">Auntie's Home · 可心老师</div>
            </div>
          </Link>

          {isTeacher && (
            <>
              <nav className="hidden md:flex items-center gap-1">
                {teacherNav.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    end={item.end}
                    className={({ isActive }) =>
                      `flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                        isActive
                          ? 'bg-primary text-primary-foreground shadow-sm'
                          : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                      }`
                    }
                  >
                    <item.icon size={16} />
                    <span>{item.label}</span>
                  </NavLink>
                ))}
              </nav>

              <div className="hidden md:flex items-center gap-2 ml-4 pl-4 border-l border-border">
                <ChangePasswordDialog />
                <button
                  onClick={async () => {
                    await logout();
                    toast.success('已退出登录');
                    navigate('/teacher/login', { replace: true });
                  }}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent transition-all"
                >
                  <LogOut size={16} />
                  <span>退出</span>
                </button>
              </div>

              <button
                className="md:hidden p-2 rounded-lg hover:bg-accent"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label="菜单"
              >
                {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </>
          )}

          {isStudent && (
            <div className="flex items-center gap-2">
              <span className="teacher-seal">可心老师</span>
            </div>
          )}

          {isHome && (
            <div className="flex items-center gap-2">
              <span className="teacher-seal hidden sm:inline-block">可心老师</span>
            </div>
          )}
        </div>

        <AnimatePresence>
          {mobileMenuOpen && isTeacher && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="md:hidden border-t border-border overflow-hidden bg-card"
            >
              <nav className="flex flex-col p-2">
                {teacherNav.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    end={item.end}
                    onClick={() => setMobileMenuOpen(false)}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-3 rounded-lg text-base font-medium ${
                        isActive
                          ? 'bg-primary/10 text-primary'
                          : 'text-foreground hover:bg-accent'
                      }`
                    }
                  >
                    <item.icon size={18} />
                    <span>{item.label}</span>
                  </NavLink>
                ))}
                <div className="border-t border-border my-2" />
                <div className="px-1 py-1">
                  <ChangePasswordDialog
                    trigger={
                      <button className="flex items-center gap-3 px-2 py-2 rounded-lg text-base font-medium text-foreground hover:bg-accent text-left w-full">
                        <Lightbulb size={18} className="opacity-0" />
                        <span>修改密码</span>
                      </button>
                    }
                  />
                </div>
                <button
                  onClick={async () => {
                    await logout();
                    setMobileMenuOpen(false);
                    toast.success('已退出登录');
                    navigate('/teacher/login', { replace: true });
                  }}
                  className="flex items-center gap-3 px-3 py-3 rounded-lg text-base font-medium text-muted-foreground hover:bg-accent hover:text-foreground text-left w-full"
                >
                  <LogOut size={18} />
                  <span>退出登录</span>
                </button>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8 pb-28 sm:pb-24">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="fixed bottom-0 left-0 right-0 z-30 bg-[hsl(25_30%_16%)] text-[hsl(32_50%_92%)] border-t border-[hsl(25_25%_24%)] shadow-[0_-4px_20px_rgba(0_0_0_0.15)]">
        <div className="max-w-6xl mx-auto px-3 sm:px-6 py-2.5 sm:py-3 pr-[100px] sm:pr-[120px]">
          <div className="flex items-center justify-start gap-4 sm:gap-8">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-shrink-0">
              <Image
                src={logoUrl}
                alt="姑姑家 Auntie's Home"
                className="h-7 w-auto sm:h-9 object-contain flex-shrink-0"
              />
              <div className="min-w-0">
                <div className="font-display text-sm sm:text-lg leading-tight text-[hsl(32_60%_95%)]">
                  姑姑家
                </div>
                <div className="text-[10px] sm:text-xs text-[hsl(30_20%_65%)] leading-tight whitespace-nowrap">
                  Auntie's Home · 可心老师
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1.5 sm:gap-2 text-[11px] sm:text-sm min-w-0">
              <Phone size={14} className="flex-shrink-0 text-[hsl(16_85%_72%)]" />
              <span className="text-[hsl(32_50%_92%)] font-medium tnum whitespace-nowrap">
                17180130793
              </span>
              <span className="text-[hsl(30_20%_65%)] whitespace-nowrap hidden sm:inline">
                微信同号
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
