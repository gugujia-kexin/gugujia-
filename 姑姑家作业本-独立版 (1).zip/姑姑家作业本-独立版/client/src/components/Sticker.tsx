import { motion } from 'framer-motion';
import haode from '@/assets/stickers/haode.png';
import angry from '@/assets/stickers/angry.png';
import smart from '@/assets/stickers/smart.png';
import wry from '@/assets/stickers/wry.png';
import sad from '@/assets/stickers/sad.png';
import wronged from '@/assets/stickers/wronged.png';
import happy from '@/assets/stickers/happy.png';
import shock from '@/assets/stickers/shock.png';
import thanks from '@/assets/stickers/thanks.png';
import wow from '@/assets/stickers/wow.png';
import dizzy from '@/assets/stickers/dizzy.png';
import daze from '@/assets/stickers/daze.png';

export type StickerName =
  | 'haode' | 'angry' | 'smart' | 'wry' | 'sad' | 'wronged'
  | 'happy' | 'shock' | 'thanks' | 'wow' | 'dizzy' | 'daze';

const MAP: Record<StickerName, string> = {
  haode, angry, smart, wry, sad, wronged,
  happy, shock, thanks, wow, dizzy, daze,
};

interface StickerProps {
  name: StickerName;
  /** 边长像素，默认 120 */
  size?: number;
  /** 入场/循环动画 */
  animation?: 'float' | 'pop' | 'bounce' | 'wobble' | 'none';
  delay?: number;
  className?: string;
}

const loopMap = {
  float: { y: [0, -10, 0], rotate: [0, 2, 0, -2, 0] },
  bounce: { y: [0, -12, 0], scale: [1, 1.04, 1] },
  wobble: { rotate: [-3, 3, -3], y: [0, -4, 0] },
};

const Sticker: React.FC<StickerProps> = ({
  name,
  size = 120,
  animation = 'float',
  delay = 0,
  className = '',
}) => {
  const src = MAP[name];
  const loop = animation === 'float' || animation === 'bounce' || animation === 'wobble'
    ? loopMap[animation]
    : null;

  return (
    <motion.img
      src={src}
      alt=""
      draggable={false}
      className={`select-none pointer-events-none ${className}`}
      style={{ width: size, height: 'auto' }}
      initial={animation === 'none' ? false : { opacity: 0, scale: 0.85, y: 8 }}
      animate={
        loop
          ? { opacity: 1, scale: 1, ...loop }
          : { opacity: 1, scale: 1, y: 0 }
      }
      transition={
        loop
          ? {
              opacity: { duration: 0.35, delay },
              scale: { duration: 0.4, delay, type: 'spring', bounce: 0.5 },
              ...Object.fromEntries(
                Object.keys(loop).map((k) => [
                  k,
                  {
                    duration: k === 'y' ? 2.6 : 3.2,
                    repeat: Infinity,
                    ease: 'easeInOut',
                    delay: delay + 0.4,
                  },
                ]),
              ),
            }
          : { duration: 0.4, delay, type: 'spring', bounce: 0.5 }
      }
    />
  );
};

export default Sticker;
