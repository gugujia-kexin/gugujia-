CREATE TABLE "answers" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"submission_id" uuid NOT NULL,
	"question_id" uuid NOT NULL,
	"student_answer" text NOT NULL,
	"is_correct" boolean,
	"auto_points" numeric DEFAULT '0' NOT NULL,
	"_created_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_updated_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE TABLE "app_config" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"config_key" varchar(50) NOT NULL,
	"config_value" text NOT NULL,
	"_created_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_updated_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	CONSTRAINT "app_config_config_key_unique" UNIQUE("config_key")
);
--> statement-breakpoint
CREATE TABLE "assignments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"title" varchar(200) NOT NULL,
	"subject" varchar(50) DEFAULT 'english' NOT NULL,
	"question_ids" uuid[] DEFAULT '{}' NOT NULL,
	"description" text,
	"access_code" varchar(20) NOT NULL,
	"deadline" timestamptz (3),
	"is_published" boolean DEFAULT false NOT NULL,
	"allow_retry" boolean DEFAULT false NOT NULL,
	"max_submissions" integer DEFAULT 1 NOT NULL,
	"is_closed" boolean DEFAULT false NOT NULL,
	"_created_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_created_by" "user_profile" DEFAULT NULL,
	"_updated_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_updated_by" "user_profile" DEFAULT NULL,
	CONSTRAINT "assignments_access_code_unique" UNIQUE("access_code")
);
--> statement-breakpoint
CREATE TABLE "checkin_records" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"task_id" uuid NOT NULL,
	"student_name" varchar(100) NOT NULL,
	"audio_url" text,
	"note" text,
	"teacher_comment" text,
	"status" varchar(20) DEFAULT 'submitted' NOT NULL,
	"submitted_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"submission_index" integer DEFAULT 1 NOT NULL,
	"student_ip" varchar(50),
	"_created_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_created_by" "user_profile" DEFAULT NULL,
	"_updated_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_updated_by" "user_profile" DEFAULT NULL
);
--> statement-breakpoint
CREATE TABLE "checkin_tasks" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"title" varchar(200) NOT NULL,
	"subject" varchar(50) DEFAULT 'english' NOT NULL,
	"task_type" varchar(20) DEFAULT 'audio' NOT NULL,
	"requirement" text,
	"access_code" varchar(20) NOT NULL,
	"deadline" timestamptz (3),
	"is_published" boolean DEFAULT false NOT NULL,
	"allow_retry" boolean DEFAULT false NOT NULL,
	"max_submissions" integer DEFAULT 1 NOT NULL,
	"is_closed" boolean DEFAULT false NOT NULL,
	"_created_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_created_by" "user_profile" DEFAULT NULL,
	"_updated_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_updated_by" "user_profile" DEFAULT NULL,
	CONSTRAINT "checkin_tasks_access_code_unique" UNIQUE("access_code")
);
--> statement-breakpoint
CREATE TABLE "knowledge_points" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"title" varchar(200) NOT NULL,
	"subject" varchar(50) DEFAULT 'english' NOT NULL,
	"content_type" varchar(20) DEFAULT 'text' NOT NULL,
	"content_text" text,
	"attachment_url" text,
	"cover_url" text,
	"description" text,
	"_created_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_created_by" "user_profile" DEFAULT NULL,
	"_updated_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_updated_by" "user_profile" DEFAULT NULL
);
--> statement-breakpoint
CREATE TABLE "questions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"subject" varchar(50) DEFAULT 'english' NOT NULL,
	"type" varchar(20) DEFAULT 'choice' NOT NULL,
	"title" text NOT NULL,
	"options" jsonb DEFAULT '[]',
	"correct_answer" text NOT NULL,
	"explanation" text,
	"difficulty" varchar(10) DEFAULT 'medium' NOT NULL,
	"tags" text[] DEFAULT '{}',
	"_created_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_created_by" "user_profile" DEFAULT NULL,
	"_updated_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_updated_by" "user_profile" DEFAULT NULL
);
--> statement-breakpoint
CREATE TABLE "submissions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"assignment_id" uuid NOT NULL,
	"student_name" varchar(100) NOT NULL,
	"auto_score" numeric DEFAULT '0' NOT NULL,
	"teacher_score" numeric,
	"teacher_comment" text,
	"status" varchar(20) DEFAULT 'submitted' NOT NULL,
	"submitted_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"submission_index" integer DEFAULT 1 NOT NULL,
	"student_ip" varchar(50),
	"_created_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_created_by" "user_profile" DEFAULT NULL,
	"_updated_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	"_updated_by" "user_profile" DEFAULT NULL
);
--> statement-breakpoint
CREATE TABLE "teacher_sessions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"session_token" varchar(64) NOT NULL,
	"expires_at" timestamptz (3) NOT NULL,
	"_created_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	CONSTRAINT "teacher_sessions_session_token_unique" UNIQUE("session_token")
);
--> statement-breakpoint
CREATE TABLE "parents" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"username" varchar(50) NOT NULL,
	"password_hash" text NOT NULL,
	"student_name" varchar(100) NOT NULL,
	"_created_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	CONSTRAINT "parents_username_unique" UNIQUE("username")
);
--> statement-breakpoint
CREATE TABLE "parent_sessions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"session_token" varchar(64) NOT NULL,
	"parent_id" uuid NOT NULL,
	"expires_at" timestamptz (3) NOT NULL,
	"_created_at" timestamptz (3) DEFAULT CURRENT_TIMESTAMP NOT NULL,
	CONSTRAINT "parent_sessions_session_token_unique" UNIQUE("session_token")
);
--> statement-breakpoint
ALTER TABLE "answers" ADD CONSTRAINT "answers_submission_id_fkey" FOREIGN KEY ("submission_id") REFERENCES "public"."submissions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "answers" ADD CONSTRAINT "answers_question_id_fkey" FOREIGN KEY ("question_id") REFERENCES "public"."questions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "checkin_records" ADD CONSTRAINT "checkin_records_task_id_fkey" FOREIGN KEY ("task_id") REFERENCES "public"."checkin_tasks"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "submissions" ADD CONSTRAINT "submissions_assignment_id_fkey" FOREIGN KEY ("assignment_id") REFERENCES "public"."assignments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_answers_submission" ON "answers" USING btree ("submission_id");--> statement-breakpoint
CREATE INDEX "idx_answers_question" ON "answers" USING btree ("question_id");--> statement-breakpoint
CREATE UNIQUE INDEX "app_config_config_key_key" ON "app_config" USING btree ("config_key");--> statement-breakpoint
CREATE UNIQUE INDEX "idx_assignments_access_code" ON "assignments" USING btree ("access_code");--> statement-breakpoint
CREATE INDEX "idx_assignments_subject" ON "assignments" USING btree ("subject");--> statement-breakpoint
CREATE INDEX "idx_checkin_records_task" ON "checkin_records" USING btree ("task_id");--> statement-breakpoint
CREATE INDEX "idx_checkin_records_student" ON "checkin_records" USING btree ("student_name");--> statement-breakpoint
CREATE UNIQUE INDEX "idx_checkin_records_task_student_idx" ON "checkin_records" USING btree ("task_id","student_name","submission_index");--> statement-breakpoint
CREATE UNIQUE INDEX "idx_checkin_tasks_code" ON "checkin_tasks" USING btree ("access_code");--> statement-breakpoint
CREATE INDEX "idx_checkin_tasks_subject" ON "checkin_tasks" USING btree ("subject");--> statement-breakpoint
CREATE INDEX "idx_kp_subject" ON "knowledge_points" USING btree ("subject");--> statement-breakpoint
CREATE INDEX "idx_questions_subject" ON "questions" USING btree ("subject");--> statement-breakpoint
CREATE INDEX "idx_questions_type" ON "questions" USING btree ("type");--> statement-breakpoint
CREATE INDEX "idx_submissions_assignment" ON "submissions" USING btree ("assignment_id");--> statement-breakpoint
CREATE INDEX "idx_submissions_student" ON "submissions" USING btree ("student_name");--> statement-breakpoint
CREATE INDEX "idx_submissions_status" ON "submissions" USING btree ("status");--> statement-breakpoint
CREATE UNIQUE INDEX "idx_submissions_assignment_student_idx" ON "submissions" USING btree ("assignment_id","student_name","submission_index");--> statement-breakpoint
CREATE UNIQUE INDEX "teacher_sessions_session_token_key" ON "teacher_sessions" USING btree ("session_token");--> statement-breakpoint
CREATE INDEX "idx_teacher_sessions_token" ON "teacher_sessions" USING btree ("session_token");--> statement-breakpoint
CREATE INDEX "idx_teacher_sessions_expires" ON "teacher_sessions" USING btree ("expires_at");