/**
 * 平台层替身（独立部署版）
 *
 * 原项目依赖豆包的 @lark-apaas/fullstack-nestjs-core，它提供数据库注入、登录装饰器、
 * 应用初始化。独立部署时用这份文件里的等价实现替换，业务代码不用动。
 */
import {
  Global,
  Module,
  OnApplicationShutdown,
} from '@nestjs/common';
import { existsSync } from 'fs';
import { join } from 'path';
import * as express from 'express';
import postgres from 'postgres';
import { drizzle } from 'drizzle-orm/postgres-js';

/** 数据库注入 token */
export const DRIZZLE_DATABASE = 'DRIZZLE_DATABASE';

/**
 * 数据库实例类型：业务层沿用的 drizzle 查询写法在这里都能满足，
 * 同时支持 execute<T>() 这种带类型的原生 SQL 调用。
 */
export interface PostgresJsDatabase {
  execute<T = any>(query: any, params?: any): Promise<T[] & { count?: number }>;
  select(...args: any[]): any;
  selectDistinct(...args: any[]): any;
  insert(...args: any[]): any;
  update(...args: any[]): any;
  delete(...args: any[]): any;
  transaction<T>(fn: (tx: any) => Promise<T>): Promise<T>;
  query(...args: any[]): any;
  [key: string]: any;
}

/**
 * 原平台用来要求登录的装饰器。本项目的真实鉴权由 TeacherAuthGuard 负责，
 * 这里保留成空装饰器，只为让原有 controller 代码保持不变。
 */
export function NeedLogin(): MethodDecorator {
  return () => undefined;
}

let sqlClient: ReturnType<typeof postgres> | null = null;

@Global()
@Module({
  providers: [
    {
      provide: DRIZZLE_DATABASE,
      useFactory: () => {
        const url = process.env.DATABASE_URL;
        if (!url) {
          throw new Error(
            '没有配置 DATABASE_URL，请在项目根目录的 .env 里填 PostgreSQL 连接串',
          );
        }
        sqlClient = postgres(url, {
          max: 10,
          onnotice: () => undefined,
        });
        return drizzle(sqlClient);
      },
    },
  ],
  exports: [DRIZZLE_DATABASE],
})
export class PlatformModule implements OnApplicationShutdown {
  static forRoot() {
    return {
      module: PlatformModule,
      global: true,
    };
  }

  async onApplicationShutdown() {
    if (sqlClient) {
      await sqlClient.end({ timeout: 5 });
      sqlClient = null;
    }
  }
}

/**
 * 原平台的应用初始化（CORS、请求体大小、静态资源）。
 * 录音、图片以 data URL 形式提交，所以这里把请求体上限放到 50MB。
 */
export function configureApp(app: any, _options?: { disableSwagger?: boolean }) {
  app.enableCors({ origin: true, credentials: true });

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  const clientDir = join(process.cwd(), 'dist', 'client');
  if (existsSync(clientDir)) {
    // 直接挂 express 静态中间件，保证在路由兜底之前生效
    app.use(express.static(clientDir, { index: false }));
  }

  return app;
}
