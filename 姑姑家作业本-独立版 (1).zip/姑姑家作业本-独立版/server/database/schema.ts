/* eslint-disable */
/** auto generated, do not edit */
import { sql } from 'drizzle-orm';
import { boolean, foreignKey, index, integer, jsonb, numeric, pgTable, text, uniqueIndex, uuid, varchar, customType } from "drizzle-orm/pg-core"

export const customTimestamptz = customType<{
  data: Date;
  driverData: string;
  config: { precision?: number };
}>({
  dataType(config) {
    const precision = typeof config?.precision !== 'undefined'
      ? ` (${config.precision})`
      : '';
    return `timestamptz${precision}`;
  },
  toDriver(value: Date | string | number) {
    if (value == null) return value as any;
    if (typeof value === 'number') return new Date(value).toISOString();
    if (typeof value === 'string') return value;
    if (value instanceof Date) return value.toISOString();
    throw new Error('Invalid timestamp value');
  },
  fromDriver(value: string | Date): Date {
    if (value instanceof Date) return value;
    return new Date(value);
  },
});

export const userProfile = customType<{
  data: string;
  driverData: string;
}>({
  dataType() {
    return 'user_profile';
  },
  toDriver(value: string) {
    return sql`ROW(${value})::user_profile`;
  },
  fromDriver(value: string) {
    const [userId] = value.slice(1, -1).split(',');
    return userId.trim();
  },
});

export type FileAttachment = {
  bucket_id: string;
  file_path: string;
};

export const fileAttachment = customType<{
  data: FileAttachment;
  driverData: string;
}>({
  dataType() {
    return 'file_attachment';
  },
  toDriver(value: FileAttachment) {
    return sql`ROW(${value.bucket_id},${value.file_path})::file_attachment`;
  },
  fromDriver(value: string): FileAttachment {
    const [bucketId, filePath] = value.slice(1, -1).split(',');
    return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
  },
});

export function escapeLiteral(str: string): string {
  return "'" + str.replace(/'/g, "''") + "'";
}

export const userProfileArray = customType<{
  data: string[];
  driverData: string;
}>({
  dataType() {
    return 'user_profile[]';
  },
  toDriver(value: string[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::user_profile[]`;
    }
    const elements = value.map(id => `ROW(${escapeLiteral(id)})::user_profile`).join(',');
    return sql.raw(`ARRAY[${elements}]::user_profile[]`);
  },
  fromDriver(value: string): string[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => m.slice(1, -1).split(',')[0].trim());
  },
});

export const fileAttachmentArray = customType<{
  data: FileAttachment[];
  driverData: string;
}>({
  dataType() {
    return 'file_attachment[]';
  },
  toDriver(value: FileAttachment[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::file_attachment[]`;
    }
    const elements = value.map(f =>
      `ROW(${escapeLiteral(f.bucket_id)},${escapeLiteral(f.file_path)})::file_attachment`
    ).join(',');
    return sql.raw(`ARRAY[${elements}]::file_attachment[]`);
  },
  fromDriver(value: string): FileAttachment[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => {
      const [bucketId, filePath] = m.slice(1, -1).split(',');
      return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
    });
  },
});

export const teacherSessions = pgTable("teacher_sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  sessionToken: varchar("session_token", { length: 64 }).notNull().unique(),
  expiresAt: customTimestamptz("expires_at", { precision: 3 }).notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("teacher_sessions_session_token_key").on(table.sessionToken),
  index("idx_teacher_sessions_token").on(table.sessionToken),
  index("idx_teacher_sessions_expires").on(table.expiresAt),
]);

export const parents = pgTable("parents", {
  id: uuid("id").primaryKey().defaultRandom(),
  username: varchar("username", { length: 50 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  studentName: varchar("student_name", { length: 100 }).notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("parents_username_key").on(table.username),
  index("idx_parents_student").on(table.studentName),
]);

export const parentSessions = pgTable("parent_sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  sessionToken: varchar("session_token", { length: 64 }).notNull().unique(),
  parentId: uuid("parent_id").notNull(),
  expiresAt: customTimestamptz("expires_at", { precision: 3 }).notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("parent_sessions_session_token_key").on(table.sessionToken),
  index("idx_parent_sessions_parent").on(table.parentId),
  index("idx_parent_sessions_expires").on(table.expiresAt),
]);

export const appConfig = pgTable("app_config", {
  id: uuid("id").primaryKey().defaultRandom(),
  configKey: varchar("config_key", { length: 50 }).notNull().unique(),
  configValue: text("config_value").notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("app_config_config_key_key").on(table.configKey),
]);

export const checkinRecords = pgTable("checkin_records", {
  id: uuid("id").primaryKey().defaultRandom(),
  taskId: uuid("task_id").notNull(),
  studentName: varchar("student_name", { length: 100 }).notNull(),
  audioUrl: text("audio_url"),
  note: text("note"),
  teacherComment: text("teacher_comment"),
  status: varchar("status", { length: 20 }).notNull().default('submitted'),
  submittedAt: customTimestamptz("submitted_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  submissionIndex: integer("submission_index").notNull().default(1),
  studentIp: varchar("student_ip", { length: 50 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_checkin_records_task").on(table.taskId),
  index("idx_checkin_records_student").on(table.studentName),
  uniqueIndex("idx_checkin_records_task_student_idx").on(table.taskId, table.studentName, table.submissionIndex),
  foreignKey({
    columns: [table.taskId],
    foreignColumns: [checkinTasks.id],
    name: "checkin_records_task_id_fkey",
  }).onDelete("cascade"),
]);

export const checkinTasks = pgTable("checkin_tasks", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: varchar("title", { length: 200 }).notNull(),
  subject: varchar("subject", { length: 50 }).notNull().default('english'),
  taskType: varchar("task_type", { length: 20 }).notNull().default('audio'),
  requirement: text("requirement"),
  accessCode: varchar("access_code", { length: 20 }).notNull().unique(),
  deadline: customTimestamptz("deadline", { precision: 3 }),
  isPublished: boolean("is_published").notNull().default(false),
  allowRetry: boolean("allow_retry").notNull().default(false),
  maxSubmissions: integer("max_submissions").notNull().default(1),
  isClosed: boolean("is_closed").notNull().default(false),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("idx_checkin_tasks_code").on(table.accessCode),
  index("idx_checkin_tasks_subject").on(table.subject),
]);

export const knowledgePoints = pgTable("knowledge_points", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: varchar("title", { length: 200 }).notNull(),
  subject: varchar("subject", { length: 50 }).notNull().default('english'),
  contentType: varchar("content_type", { length: 20 }).notNull().default('text'),
  contentText: text("content_text"),
  attachmentUrl: text("attachment_url"),
  coverUrl: text("cover_url"),
  description: text("description"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_kp_subject").on(table.subject),
]);

export const answers = pgTable("answers", {
  id: uuid("id").primaryKey().defaultRandom(),
  submissionId: uuid("submission_id").notNull(),
  questionId: uuid("question_id").notNull(),
  studentAnswer: text("student_answer").notNull(),
  isCorrect: boolean("is_correct"),
  autoPoints: numeric("auto_points").notNull().default('0'),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_answers_submission").on(table.submissionId),
  index("idx_answers_question").on(table.questionId),
  foreignKey({
    columns: [table.submissionId],
    foreignColumns: [submissions.id],
    name: "answers_submission_id_fkey",
  }).onDelete("cascade"),
  foreignKey({
    columns: [table.questionId],
    foreignColumns: [questions.id],
    name: "answers_question_id_fkey",
  }).onDelete("cascade"),
]);

export const submissions = pgTable("submissions", {
  id: uuid("id").primaryKey().defaultRandom(),
  assignmentId: uuid("assignment_id").notNull(),
  studentName: varchar("student_name", { length: 100 }).notNull(),
  autoScore: numeric("auto_score").notNull().default('0'),
  teacherScore: numeric("teacher_score"),
  teacherComment: text("teacher_comment"),
  status: varchar("status", { length: 20 }).notNull().default('submitted'),
  submittedAt: customTimestamptz("submitted_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  submissionIndex: integer("submission_index").notNull().default(1),
  studentIp: varchar("student_ip", { length: 50 }),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_submissions_assignment").on(table.assignmentId),
  index("idx_submissions_student").on(table.studentName),
  index("idx_submissions_status").on(table.status),
  uniqueIndex("idx_submissions_assignment_student_idx").on(table.assignmentId, table.studentName, table.submissionIndex),
  foreignKey({
    columns: [table.assignmentId],
    foreignColumns: [assignments.id],
    name: "submissions_assignment_id_fkey",
  }).onDelete("cascade"),
]);

export const assignments = pgTable("assignments", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: varchar("title", { length: 200 }).notNull(),
  subject: varchar("subject", { length: 50 }).notNull().default('english'),
  questionIds: uuid("question_ids").array().notNull().default([]),
  description: text("description"),
  accessCode: varchar("access_code", { length: 20 }).notNull().unique(),
  deadline: customTimestamptz("deadline", { precision: 3 }),
  isPublished: boolean("is_published").notNull().default(false),
  allowRetry: boolean("allow_retry").notNull().default(false),
  maxSubmissions: integer("max_submissions").notNull().default(1),
  isClosed: boolean("is_closed").notNull().default(false),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("idx_assignments_access_code").on(table.accessCode),
  index("idx_assignments_subject").on(table.subject),
]);

export const questions = pgTable("questions", {
  id: uuid("id").primaryKey().defaultRandom(),
  subject: varchar("subject", { length: 50 }).notNull().default('english'),
  type: varchar("type", { length: 20 }).notNull().default('choice'),
  title: text("title").notNull(),
  /**
   * @type { label: string; value: string }[]
   */
  options: jsonb("options").default('[]'),
  correctAnswer: text("correct_answer").notNull(),
  explanation: text("explanation"),
  difficulty: varchar("difficulty", { length: 10 }).notNull().default('medium'),
  tags: text("tags").array().default([]),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_questions_subject").on(table.subject),
  index("idx_questions_type").on(table.type),
]);

// table aliases
export const answersTable = answers;
export const appConfigTable = appConfig;
export const assignmentsTable = assignments;
export const checkinRecordsTable = checkinRecords;
export const checkinTasksTable = checkinTasks;
export const knowledgePointsTable = knowledgePoints;
export const parentsTable = parents;
export const parentSessionsTable = parentSessions;
export const questionsTable = questions;
export const submissionsTable = submissions;
export const teacherSessionsTable = teacherSessions;
