import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { NeedLogin } from '../../platform/shim';
import { TeacherAuthGuard } from '../teacher-auth/teacher-auth.guard';
import { AssignmentsService } from './assignments.service';
import {
  AssignmentListQueryDto,
  CreateAssignmentDto,
  UpdateAssignmentDto,
} from './dto/assignments.dto';

@Controller('api/assignments')
export class AssignmentsController {
  constructor(private readonly assignmentsService: AssignmentsService) {}

  @UseGuards(TeacherAuthGuard)
  @Get()
  async list(@Query() query: AssignmentListQueryDto) {
    return this.assignmentsService.list(query);
  }

  @Get('by-code/:code')
  async getByCode(@Param('code') code: string) {
    return this.assignmentsService.getByCode(code);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Post(':id/regenerate-code')
  async regenerateCode(@Param('id') id: string) {
    return this.assignmentsService.regenerateCode(id);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Post(':id/close')
  async close(@Param('id') id: string) {
    return this.assignmentsService.close(id);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Post(':id/reopen')
  async reopen(@Param('id') id: string) {
    return this.assignmentsService.reopen(id);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Patch(':id/deadline')
  async updateDeadline(
    @Param('id') id: string,
    @Body() body: { deadline?: string | null },
  ) {
    if (!('deadline' in body)) {
      throw new BadRequestException('缺少 deadline 字段');
    }
    const deadline = body.deadline == null ? null : new Date(body.deadline);
    if (body.deadline !== null && deadline && isNaN(deadline.getTime())) {
      throw new BadRequestException('deadline 格式无效');
    }
    return this.assignmentsService.updateDeadline(id, deadline);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Post()
  async create(@Body() dto: CreateAssignmentDto) {
    return this.assignmentsService.create(dto);
  }

  @Get(':id')
  async getById(@Param('id') id: string) {
    return this.assignmentsService.getById(id);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateAssignmentDto,
  ) {
    return this.assignmentsService.update(id, dto);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Delete(':id')
  async remove(@Param('id') id: string) {
    return this.assignmentsService.remove(id);
  }
}
