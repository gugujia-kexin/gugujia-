import {
  BadRequestException,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '../../platform/shim';
import { eq, and, desc, count, inArray } from 'drizzle-orm';
import { assignments, questions, submissions } from '../../database/schema';
import type {
  CreateAssignmentDto,
  AssignmentListQueryDto,
  UpdateAssignmentDto,
} from './dto/assignments.dto';
import type {
  Assignment,
  ListResponse,
  Question,
} from '../../../shared/api.interface';

function generateAccessCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

@Injectable()
export class AssignmentsService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(
    query: AssignmentListQueryDto,
  ): Promise<ListResponse<Assignment>> {
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 20;
    const conditions = [];
    if (query.subject)
      conditions.push(eq(assignments.subject, query.subject));

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [totalResult, items] = await Promise.all([
      this.db.select({ count: count() }).from(assignments).where(where),
      this.db
        .select()
        .from(assignments)
        .where(where)
        .orderBy(desc(assignments.createdAt))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = totalResult[0]?.count ?? 0;

    // 查每个作业的提交数
    const ids = items.map((item) => item.id);
    let submissionCounts: Record<string, number> = {};
    if (ids.length > 0) {
      const countResults = await this.db
        .select({
          assignmentId: submissions.assignmentId,
          count: count(),
        })
        .from(submissions)
        .where(inArray(submissions.assignmentId, ids))
        .groupBy(submissions.assignmentId);
      submissionCounts = Object.fromEntries(
        countResults.map((r) => [r.assignmentId, r.count]),
      );
    }

    return {
      items: items.map((item) => ({
        ...this.toResponse(item),
        submissionCount: submissionCounts[item.id] ?? 0,
      })),
      total,
    };
  }

  async getById(id: string): Promise<Assignment> {
    const [item] = await this.db
      .select()
      .from(assignments)
      .where(eq(assignments.id, id))
      .limit(1);
    if (!item) throw new NotFoundException('作业不存在');

    const questionsList = await this.getQuestionsByIds(item.questionIds);
    return { ...this.toResponse(item), questions: questionsList };
  }

  async getByCode(code: string): Promise<Assignment> {
    const [item] = await this.db
      .select()
      .from(assignments)
      .where(eq(assignments.accessCode, code))
      .limit(1);
    if (!item) throw new NotFoundException('访问码无效');

    this.validateAssignmentAccess(item);

    const questionsList = await this.getQuestionsByIds(item.questionIds);
    return { ...this.toResponse(item), questions: questionsList };
  }

  validateAssignmentAccess(item: typeof assignments.$inferSelect): void {
    if (!item.isPublished) {
      throw new BadRequestException('该作业尚未发布');
    }
    if (item.isClosed) {
      throw new BadRequestException('该作业已关闭');
    }
    if (item.deadline && new Date() > item.deadline) {
      throw new BadRequestException('该作业已过截止时间');
    }
  }

  async create(dto: CreateAssignmentDto): Promise<{ id: string }> {
    const accessCode = generateAccessCode();
    const [result] = await this.db
      .insert(assignments)
      .values({
        title: dto.title,
        subject: dto.subject,
        questionIds: dto.questionIds,
        description: dto.description ?? '',
        accessCode,
        deadline: dto.deadline ?? null,
        isPublished: dto.isPublished ?? false,
        allowRetry: dto.allowRetry ?? false,
        maxSubmissions: dto.maxSubmissions ?? 1,
      })
      .returning({ id: assignments.id });
    return { id: result.id };
  }

  async update(
    id: string,
    dto: UpdateAssignmentDto,
  ): Promise<{ id: string }> {
    const patch: Record<string, unknown> = {};
    if (dto.title !== undefined) patch.title = dto.title;
    if (dto.subject !== undefined) patch.subject = dto.subject;
    if (dto.questionIds !== undefined) patch.questionIds = dto.questionIds;
    if (dto.description !== undefined) patch.description = dto.description;
    if (dto.deadline !== undefined) patch.deadline = dto.deadline;
    if (dto.isPublished !== undefined) patch.isPublished = dto.isPublished;
    if (dto.allowRetry !== undefined) patch.allowRetry = dto.allowRetry;
    if (dto.maxSubmissions !== undefined)
      patch.maxSubmissions = dto.maxSubmissions;

    if (Object.keys(patch).length === 0) {
      return { id };
    }

    const updated = await this.db
      .update(assignments)
      .set(patch)
      .where(eq(assignments.id, id))
      .returning({ id: assignments.id });
    if (updated.length === 0) throw new NotFoundException('作业不存在');
    return { id: updated[0].id };
  }

  async remove(id: string): Promise<{ id: string }> {
    const deleted = await this.db
      .delete(assignments)
      .where(eq(assignments.id, id))
      .returning({ id: assignments.id });
    if (deleted.length === 0) throw new NotFoundException('作业不存在');
    return { id: deleted[0].id };
  }

  async regenerateCode(id: string): Promise<{ accessCode: string }> {
    const maxRetries = 5;
    let lastError: unknown;

    for (let attempt = 0; attempt < maxRetries; attempt += 1) {
      const newCode = generateAccessCode();
      try {
        const updated = await this.db
          .update(assignments)
          .set({ accessCode: newCode })
          .where(eq(assignments.id, id))
          .returning({ id: assignments.id });
        if (updated.length === 0)
          throw new NotFoundException('作业不存在');
        return { accessCode: newCode };
      } catch (err) {
        lastError = err;
        const code = extractPostgresErrorCode(err);
        if (code !== '23505') throw err;
      }
    }

    throw lastError;
  }

  async close(id: string): Promise<{ id: string }> {
    const updated = await this.db
      .update(assignments)
      .set({ isClosed: true })
      .where(eq(assignments.id, id))
      .returning({ id: assignments.id });
    if (updated.length === 0) throw new NotFoundException('作业不存在');
    return { id: updated[0].id };
  }

  async reopen(id: string): Promise<{ id: string }> {
    const updated = await this.db
      .update(assignments)
      .set({ isClosed: false })
      .where(eq(assignments.id, id))
      .returning({ id: assignments.id });
    if (updated.length === 0) throw new NotFoundException('作业不存在');
    return { id: updated[0].id };
  }

  async updateDeadline(
    id: string,
    deadline: Date | null,
  ): Promise<{ id: string }> {
    const updated = await this.db
      .update(assignments)
      .set({ deadline })
      .where(eq(assignments.id, id))
      .returning({ id: assignments.id });
    if (updated.length === 0) throw new NotFoundException('作业不存在');
    return { id: updated[0].id };
  }

  private async getQuestionsByIds(ids: string[]): Promise<Question[]> {
    if (ids.length === 0) return [];
    const rows = await this.db
      .select()
      .from(questions)
      .where(inArray(questions.id, ids));
    const map = new Map<string, (typeof rows)[number]>(rows.map((r) => [r.id, r] as const));
    return ids
      .filter((id) => map.has(id))
      .map((id) => {
        const row = map.get(id)!;
        return {
          id: row.id,
          subject: row.subject as Question['subject'],
          type: row.type as Question['type'],
          title: row.title,
          options: (row.options as Question['options']) ?? [],
          correctAnswer: row.correctAnswer,
          explanation: row.explanation ?? '',
          difficulty: row.difficulty as Question['difficulty'],
          tags: row.tags ?? [],
          createdAt: row.createdAt.toISOString(),
        };
      });
  }

  private toResponse(row: typeof assignments.$inferSelect): Assignment {
    return {
      id: row.id,
      title: row.title,
      subject: row.subject as Assignment['subject'],
      questionIds: row.questionIds as string[],
      description: row.description ?? '',
      accessCode: row.accessCode,
      deadline: row.deadline ? row.deadline.toISOString() : null,
      isPublished: row.isPublished,
      allowRetry: row.allowRetry,
      maxSubmissions: row.maxSubmissions,
      isClosed: row.isClosed,
      createdAt: row.createdAt.toISOString(),
    };
  }
}

function extractPostgresErrorCode(error: unknown): string | undefined {
  let current: unknown = error;
  for (let depth = 0; depth < 4 && current && typeof current === 'object'; depth += 1) {
    const { code, cause } = current as { code?: unknown; cause?: unknown };
    if (typeof code === 'string') return code;
    current = cause;
  }
  return undefined;
}
