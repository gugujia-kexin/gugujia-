import {
  BadRequestException,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '../../platform/shim';
import { eq, and, desc, count, inArray } from 'drizzle-orm';
import { checkinTasks, checkinRecords } from '../../database/schema';
import type {
  CheckinTaskListQueryDto,
  CommentCheckinDto,
  CreateCheckinTaskDto,
  SubmitCheckinDto,
  UpdateCheckinTaskDto,
} from './dto/checkin.dto';
import type {
  CheckinRecord,
  CheckinTask,
  ListResponse,
} from '../../../shared/api.interface';

function generateAccessCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

@Injectable()
export class CheckinService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  // ---- Task ----

  async listTasks(
    query: CheckinTaskListQueryDto,
  ): Promise<ListResponse<CheckinTask>> {
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 20;
    const conditions = [];
    if (query.subject)
      conditions.push(eq(checkinTasks.subject, query.subject));

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [totalResult, items] = await Promise.all([
      this.db.select({ count: count() }).from(checkinTasks).where(where),
      this.db
        .select()
        .from(checkinTasks)
        .where(where)
        .orderBy(desc(checkinTasks.createdAt))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = totalResult[0]?.count ?? 0;

    const ids = items.map((item) => item.id);
    let recordCounts: Record<string, number> = {};
    if (ids.length > 0) {
      const countResults = await this.db
        .select({
          taskId: checkinRecords.taskId,
          count: count(),
        })
        .from(checkinRecords)
        .where(inArray(checkinRecords.taskId, ids))
        .groupBy(checkinRecords.taskId);
      recordCounts = Object.fromEntries(
        countResults.map((r) => [r.taskId, r.count]),
      );
    }

    return {
      items: items.map((item) => ({
        ...this.taskToResponse(item),
        recordCount: recordCounts[item.id] ?? 0,
      })),
      total,
    };
  }

  async getTaskById(id: string): Promise<CheckinTask> {
    const [item] = await this.db
      .select()
      .from(checkinTasks)
      .where(eq(checkinTasks.id, id))
      .limit(1);
    if (!item) throw new NotFoundException('打卡任务不存在');
    return this.taskToResponse(item);
  }

  async getTaskByCode(code: string): Promise<CheckinTask> {
    const [item] = await this.db
      .select()
      .from(checkinTasks)
      .where(eq(checkinTasks.accessCode, code))
      .limit(1);
    if (!item) throw new NotFoundException('访问码无效');

    this.validateTaskAccess(item);
    return this.taskToResponse(item);
  }

  validateTaskAccess(item: typeof checkinTasks.$inferSelect): void {
    if (!item.isPublished) {
      throw new BadRequestException('该打卡任务尚未发布');
    }
    if (item.isClosed) {
      throw new BadRequestException('该打卡任务已关闭');
    }
    if (item.deadline && new Date() > item.deadline) {
      throw new BadRequestException('该打卡任务已过截止时间');
    }
  }

  async createTask(dto: CreateCheckinTaskDto): Promise<{ id: string }> {
    const accessCode = generateAccessCode();
    const [result] = await this.db
      .insert(checkinTasks)
      .values({
        title: dto.title,
        subject: dto.subject,
        taskType: dto.taskType,
        requirement: dto.requirement ?? '',
        accessCode,
        deadline: dto.deadline ?? null,
        isPublished: dto.isPublished ?? false,
        allowRetry: dto.allowRetry ?? false,
        maxSubmissions: dto.maxSubmissions ?? 1,
      })
      .returning({ id: checkinTasks.id });
    return { id: result.id };
  }

  async updateTask(
    id: string,
    dto: UpdateCheckinTaskDto,
  ): Promise<{ id: string }> {
    const patch: Record<string, unknown> = {};
    if (dto.title !== undefined) patch.title = dto.title;
    if (dto.subject !== undefined) patch.subject = dto.subject;
    if (dto.taskType !== undefined) patch.taskType = dto.taskType;
    if (dto.requirement !== undefined) patch.requirement = dto.requirement;
    if (dto.deadline !== undefined) patch.deadline = dto.deadline;
    if (dto.isPublished !== undefined) patch.isPublished = dto.isPublished;
    if (dto.allowRetry !== undefined) patch.allowRetry = dto.allowRetry;
    if (dto.maxSubmissions !== undefined)
      patch.maxSubmissions = dto.maxSubmissions;

    if (Object.keys(patch).length === 0) {
      return { id };
    }

    const updated = await this.db
      .update(checkinTasks)
      .set(patch)
      .where(eq(checkinTasks.id, id))
      .returning({ id: checkinTasks.id });
    if (updated.length === 0)
      throw new NotFoundException('打卡任务不存在');
    return { id: updated[0].id };
  }

  async deleteTask(id: string): Promise<{ id: string }> {
    const deleted = await this.db
      .delete(checkinTasks)
      .where(eq(checkinTasks.id, id))
      .returning({ id: checkinTasks.id });
    if (deleted.length === 0)
      throw new NotFoundException('打卡任务不存在');
    return { id: deleted[0].id };
  }

  async regenerateTaskCode(
    id: string,
  ): Promise<{ accessCode: string }> {
    const maxRetries = 5;
    let lastError: unknown;

    for (let attempt = 0; attempt < maxRetries; attempt += 1) {
      const newCode = generateAccessCode();
      try {
        const updated = await this.db
          .update(checkinTasks)
          .set({ accessCode: newCode })
          .where(eq(checkinTasks.id, id))
          .returning({ id: checkinTasks.id });
        if (updated.length === 0)
          throw new NotFoundException('打卡任务不存在');
        return { accessCode: newCode };
      } catch (err) {
        lastError = err;
        const code = extractPostgresErrorCode(err);
        if (code !== '23505') throw err;
      }
    }

    throw lastError;
  }

  async closeTask(id: string): Promise<{ id: string }> {
    const updated = await this.db
      .update(checkinTasks)
      .set({ isClosed: true })
      .where(eq(checkinTasks.id, id))
      .returning({ id: checkinTasks.id });
    if (updated.length === 0)
      throw new NotFoundException('打卡任务不存在');
    return { id: updated[0].id };
  }

  async reopenTask(id: string): Promise<{ id: string }> {
    const updated = await this.db
      .update(checkinTasks)
      .set({ isClosed: false })
      .where(eq(checkinTasks.id, id))
      .returning({ id: checkinTasks.id });
    if (updated.length === 0)
      throw new NotFoundException('打卡任务不存在');
    return { id: updated[0].id };
  }

  async updateTaskDeadline(
    id: string,
    deadline: Date | null,
  ): Promise<{ id: string }> {
    const updated = await this.db
      .update(checkinTasks)
      .set({ deadline })
      .where(eq(checkinTasks.id, id))
      .returning({ id: checkinTasks.id });
    if (updated.length === 0)
      throw new NotFoundException('打卡任务不存在');
    return { id: updated[0].id };
  }

  // ---- Records ----

  async getTaskRecords(taskId: string): Promise<CheckinRecord[]> {
    // 先校验任务存在
    const [task] = await this.db
      .select({ id: checkinTasks.id })
      .from(checkinTasks)
      .where(eq(checkinTasks.id, taskId))
      .limit(1);
    if (!task) throw new NotFoundException('打卡任务不存在');

    const rows = await this.db
      .select()
      .from(checkinRecords)
      .where(eq(checkinRecords.taskId, taskId))
      .orderBy(desc(checkinRecords.submittedAt));
    return rows.map((r) => this.recordToResponse(r));
  }

  async submitRecord(dto: SubmitCheckinDto): Promise<{ id: string }> {
    const [task] = await this.db
      .select()
      .from(checkinTasks)
      .where(eq(checkinTasks.accessCode, dto.accessCode))
      .limit(1);
    if (!task) throw new NotFoundException('访问码无效');

    // 校验任务状态
    if (!task.isPublished) {
      throw new BadRequestException('该打卡任务尚未发布');
    }
    if (task.isClosed) {
      throw new BadRequestException('该打卡任务已关闭');
    }
    if (task.deadline && new Date() > task.deadline) {
      throw new BadRequestException('该打卡任务已过截止时间');
    }

    const studentName = dto.studentName.trim();
    if (!studentName) {
      throw new BadRequestException('学生姓名不能为空');
    }

    const result = await this.db.transaction(async (tx) => {
      // 统计该学生在这个任务的已有提交数
      const countResult = await tx
        .select({ count: count() })
        .from(checkinRecords)
        .where(
          and(
            eq(checkinRecords.taskId, task.id),
            eq(checkinRecords.studentName, studentName),
          ),
        );
      const existingCount = countResult[0]?.count ?? 0;

      if (existingCount >= task.maxSubmissions) {
        if (!task.allowRetry || task.maxSubmissions <= 1) {
          throw new BadRequestException('你已提交过该打卡任务，不能再次提交');
        }
        throw new BadRequestException(
          `你已达到最大提交次数（${task.maxSubmissions}次），不能再次提交`,
        );
      }

      const submissionIndex = existingCount + 1;

      const [rec] = await tx
        .insert(checkinRecords)
        .values({
          taskId: task.id,
          studentName,
          audioUrl: dto.audioUrl ?? '',
          note: dto.note ?? '',
          teacherComment: '',
          status: 'submitted',
          submissionIndex,
        })
        .returning({ id: checkinRecords.id });

      return rec;
    });

    return { id: result.id };
  }

  async commentRecord(
    id: string,
    dto: CommentCheckinDto,
  ): Promise<{ id: string }> {
    const updated = await this.db
      .update(checkinRecords)
      .set({
        teacherComment: dto.teacherComment,
        status: 'graded',
      })
      .where(eq(checkinRecords.id, id))
      .returning({ id: checkinRecords.id });
    if (updated.length === 0) throw new NotFoundException('打卡记录不存在');
    return { id: updated[0].id };
  }

  private taskToResponse(
    row: typeof checkinTasks.$inferSelect,
  ): CheckinTask {
    return {
      id: row.id,
      title: row.title,
      subject: row.subject as CheckinTask['subject'],
      taskType: row.taskType as CheckinTask['taskType'],
      requirement: row.requirement ?? '',
      accessCode: row.accessCode,
      deadline: row.deadline ? row.deadline.toISOString() : null,
      isPublished: row.isPublished,
      allowRetry: row.allowRetry,
      maxSubmissions: row.maxSubmissions,
      isClosed: row.isClosed,
      createdAt: row.createdAt.toISOString(),
    };
  }

  private recordToResponse(
    row: typeof checkinRecords.$inferSelect,
  ): CheckinRecord {
    return {
      id: row.id,
      taskId: row.taskId,
      studentName: row.studentName,
      audioUrl: row.audioUrl ?? '',
      note: row.note ?? '',
      teacherComment: row.teacherComment ?? '',
      status: row.status,
      submissionIndex: row.submissionIndex,
      submittedAt: row.submittedAt.toISOString(),
    };
  }

  /** 删掉一条打卡记录 */
  async deleteRecord(id: string): Promise<{ ok: boolean }> {
    await this.db.delete(checkinRecords).where(eq(checkinRecords.id, id));
    return { ok: true };
  }
}

function extractPostgresErrorCode(error: unknown): string | undefined {
  let current: unknown = error;
  for (let depth = 0; depth < 4 && current && typeof current === 'object'; depth += 1) {
    const { code, cause } = current as { code?: unknown; cause?: unknown };
    if (typeof code === 'string') return code;
    current = cause;
  }
  return undefined;
}
