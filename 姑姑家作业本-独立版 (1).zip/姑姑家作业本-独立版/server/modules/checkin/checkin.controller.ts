import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { NeedLogin } from '../../platform/shim';
import { TeacherAuthGuard } from '../teacher-auth/teacher-auth.guard';
import { CheckinService } from './checkin.service';
import {
  CheckinTaskListQueryDto,
  CommentCheckinDto,
  CreateCheckinTaskDto,
  SubmitCheckinDto,
  UpdateCheckinTaskDto,
} from './dto/checkin.dto';

@Controller('api/checkin')
export class CheckinController {
  constructor(private readonly checkinService: CheckinService) {}

  // ---- Tasks ----

  @UseGuards(TeacherAuthGuard)
  @Get('tasks')
  async listTasks(@Query() query: CheckinTaskListQueryDto) {
    return this.checkinService.listTasks(query);
  }

  @Get('tasks/by-code/:code')
  async getTaskByCode(@Param('code') code: string) {
    return this.checkinService.getTaskByCode(code);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Post('tasks/:id/regenerate-code')
  async regenerateTaskCode(@Param('id') id: string) {
    return this.checkinService.regenerateTaskCode(id);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Post('tasks/:id/close')
  async closeTask(@Param('id') id: string) {
    return this.checkinService.closeTask(id);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Post('tasks/:id/reopen')
  async reopenTask(@Param('id') id: string) {
    return this.checkinService.reopenTask(id);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Patch('tasks/:id/deadline')
  async updateTaskDeadline(
    @Param('id') id: string,
    @Body() body: { deadline?: string | null },
  ) {
    if (!('deadline' in body)) {
      throw new BadRequestException('缺少 deadline 字段');
    }
    const deadline = body.deadline == null ? null : new Date(body.deadline);
    if (body.deadline !== null && deadline && isNaN(deadline.getTime())) {
      throw new BadRequestException('deadline 格式无效');
    }
    return this.checkinService.updateTaskDeadline(id, deadline);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Post('tasks')
  async createTask(@Body() dto: CreateCheckinTaskDto) {
    return this.checkinService.createTask(dto);
  }

  @Get('tasks/:id')
  async getTaskById(@Param('id') id: string) {
    return this.checkinService.getTaskById(id);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Patch('tasks/:id')
  async updateTask(
    @Param('id') id: string,
    @Body() dto: UpdateCheckinTaskDto,
  ) {
    return this.checkinService.updateTask(id, dto);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Delete('tasks/:id')
  async deleteTask(@Param('id') id: string) {
    return this.checkinService.deleteTask(id);
  }

  @UseGuards(TeacherAuthGuard)
  @Get('tasks/:id/records')
  async getTaskRecords(@Param('id') id: string) {
    return this.checkinService.getTaskRecords(id);
  }

  // ---- Records ----

  @Post('records')
  async submitRecord(@Body() dto: SubmitCheckinDto) {
    return this.checkinService.submitRecord(dto);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @UseGuards(TeacherAuthGuard)
  @Delete('records/:id')
  async deleteRecord(@Param('id') id: string) {
    return this.checkinService.deleteRecord(id);
  }

  @Patch('records/:id/comment')
  async commentRecord(
    @Param('id') id: string,
    @Body() dto: CommentCheckinDto,
  ) {
    return this.checkinService.commentRecord(id, dto);
  }
}
