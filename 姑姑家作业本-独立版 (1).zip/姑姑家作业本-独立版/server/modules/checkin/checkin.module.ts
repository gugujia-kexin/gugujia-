import { Module } from '@nestjs/common';
import { CheckinController } from './checkin.controller';
import { CheckinService } from './checkin.service';
import { TeacherAuthModule } from '../teacher-auth/teacher-auth.module';

@Module({
  imports: [TeacherAuthModule],
  controllers: [CheckinController],
  providers: [CheckinService],
})
export class CheckinModule {}
