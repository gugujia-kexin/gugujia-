import { Transform, Type } from 'class-transformer';
import {
  IsBoolean,
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  Max,
  Min,
} from 'class-validator';
import { CHECKIN_TYPES, SUBJECTS } from '../../../../shared/api.interface';

export class CheckinTaskListQueryDto {
  @IsOptional()
  @Transform(({ obj, key, value }) =>
    obj[key] === '' ? undefined : value,
  )
  @IsString()
  @IsIn(SUBJECTS)
  subject?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  pageSize?: number;
}

export class CreateCheckinTaskDto {
  @IsString()
  title!: string;

  @IsString()
  @IsIn(SUBJECTS)
  subject!: string;

  @IsString()
  @IsIn(CHECKIN_TYPES)
  taskType!: string;

  @IsOptional()
  @IsString()
  requirement?: string;

  @IsOptional()
  @Type(() => Date)
  deadline?: Date;

  @IsOptional()
  @Transform(({ obj, key }) =>
    obj[key] === 'true' ? true : obj[key] === 'false' ? false : obj[key],
  )
  @IsBoolean()
  isPublished?: boolean;

  @IsOptional()
  @Transform(({ obj, key }) =>
    obj[key] === 'true' ? true : obj[key] === 'false' ? false : obj[key],
  )
  @IsBoolean()
  allowRetry?: boolean;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(10)
  maxSubmissions?: number;
}

export class UpdateCheckinTaskDto {
  @IsOptional()
  @IsString()
  title?: string;

  @IsOptional()
  @IsString()
  @IsIn(SUBJECTS)
  subject?: string;

  @IsOptional()
  @IsString()
  @IsIn(CHECKIN_TYPES)
  taskType?: string;

  @IsOptional()
  @IsString()
  requirement?: string;

  @IsOptional()
  @Type(() => Date)
  deadline?: Date | null;

  @IsOptional()
  @Transform(({ obj, key }) =>
    obj[key] === 'true' ? true : obj[key] === 'false' ? false : obj[key],
  )
  @IsBoolean()
  isPublished?: boolean;

  @IsOptional()
  @Transform(({ obj, key }) =>
    obj[key] === 'true' ? true : obj[key] === 'false' ? false : obj[key],
  )
  @IsBoolean()
  allowRetry?: boolean;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(10)
  maxSubmissions?: number;
}

export class SubmitCheckinDto {
  @IsString()
  accessCode!: string;

  @IsString()
  studentName!: string;

  @IsOptional()
  @IsString()
  audioUrl?: string;

  @IsOptional()
  @IsString()
  note?: string;
}

export class CommentCheckinDto {
  @IsString()
  teacherComment!: string;
}
