import {
  BadRequestException,
  Body,
  Controller,
  Get,
  NotFoundException,
  Post,
  Query,
} from '@nestjs/common';
import { PortalService } from './portal.service';

interface BindDto {
  code?: string;
  name?: string;
}

@Controller('api/portal')
export class PortalController {
  constructor(private readonly portalService: PortalService) {}

  @Get('class-code')
  async classCode() {
    return { classCode: await this.portalService.getClassCode() };
  }

  /** 学生输入一个码，判定是班级码还是单个任务的访问码 */
  @Post('bind')
  async bind(@Body() body: BindDto) {
    const code = (body.code ?? '').trim();
    const name = (body.name ?? '').trim();
    if (!code || !name) {
      throw new BadRequestException('请把班级码和姓名都填上');
    }
    try {
      const entry = await this.portalService.resolveEntry(code);
      return { ...entry, name };
    } catch {
      throw new NotFoundException('这个码没找到，再确认一下～');
    }
  }

  @Get('tasks')
  async tasks(@Query('name') name?: string) {
    if (!name || !name.trim()) {
      throw new BadRequestException('请先填姓名');
    }
    return this.portalService.taskboard(name);
  }
}
