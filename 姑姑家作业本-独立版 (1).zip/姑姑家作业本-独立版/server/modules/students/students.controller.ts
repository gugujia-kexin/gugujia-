import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Query,
  UseGuards,
} from '@nestjs/common';
import { TeacherAuthGuard } from '../teacher-auth/teacher-auth.guard';
import { StudentsService } from './students.service';
import { PortalService } from './portal.service';
import { StudentStatsQueryDto } from './dto/students.dto';

@Controller('api/students')
@UseGuards(TeacherAuthGuard)
export class StudentsController {
  constructor(
    private readonly studentsService: StudentsService,
    private readonly portalService: PortalService,
  ) {}

  @Get('list')
  async listStudentNames() {
    return this.studentsService.listStudentNames();
  }

  @Get('stats')
  async stats(@Query() query: StudentStatsQueryDto) {
    return this.studentsService.stats(query);
  }

  @Get('class-code')
  async getClassCode() {
    return { classCode: await this.portalService.getClassCode() };
  }

  @Patch('class-code')
  async setClassCode(@Body() body: { classCode?: string }) {
    return this.portalService.setClassCode(body?.classCode ?? '');
  }

  /** 删除某个学生的全部提交与打卡记录 */
  @Delete('by-name/:name')
  async deleteStudent(@Param('name') name: string) {
    return this.studentsService.deleteStudent(decodeURIComponent(name));
  }

  /** 清空全部提交与打卡记录（清测试数据用） */
  @Delete('records/all')
  async clearAllRecords() {
    return this.studentsService.clearAllRecords();
  }
}
