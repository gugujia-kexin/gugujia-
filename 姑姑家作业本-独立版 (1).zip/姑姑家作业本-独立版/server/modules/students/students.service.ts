import { Inject, Injectable } from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '../../platform/shim';
import { eq, sql, desc, count } from 'drizzle-orm';
import { submissions, answers, checkinRecords } from '../../database/schema';
import type { StudentStatsQueryDto } from './dto/students.dto';
import type { ListResponse, StudentStats } from '../../../shared/api.interface';

@Injectable()
export class StudentsService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async listStudentNames(): Promise<{ items: string[] }> {
    const rows = await this.db
      .select({ studentName: submissions.studentName })
      .from(submissions)
      .groupBy(submissions.studentName)
      .orderBy(submissions.studentName);
    return { items: rows.map((r) => r.studentName) };
  }

  async stats(
    query: StudentStatsQueryDto,
  ): Promise<ListResponse<StudentStats>> {
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 20;

    // 用 raw SQL 聚合：每个学生的提交数、平均分、最新分
    // score = coalesce(teacher_score, auto_score)
    const whereClause = query.studentName
      ? sql`WHERE ${submissions.studentName} = ${query.studentName}`
      : sql``;

    const totalSql = sql`
      SELECT COUNT(DISTINCT ${submissions.studentName}) AS cnt
      FROM ${submissions}
      ${whereClause}
    `;

    const [{ cnt: total }] = await this.db.execute<{ cnt: string }>(totalSql);

    // 主查询：按学生聚合
    const statsSql = sql`
      SELECT
        s.student_name AS "studentName",
        COUNT(*) AS "submissionCount",
        AVG(COALESCE(s.teacher_score::numeric, s.auto_score::numeric)) AS "avgScore",
        (
          SELECT COALESCE(s2.teacher_score::numeric, s2.auto_score::numeric)
          FROM ${submissions} s2
          WHERE s2.student_name = s.student_name
          ORDER BY s2.submitted_at DESC
          LIMIT 1
        ) AS "latestScore"
      FROM ${submissions} s
      ${whereClause}
      GROUP BY s.student_name
      ORDER BY s.student_name
      LIMIT ${pageSize}
      OFFSET ${(page - 1) * pageSize}
    `;

    const statsRows = await this.db.execute<{
      studentName: string;
      submissionCount: string;
      avgScore: string;
      latestScore: string;
    }>(statsSql);

    // 收集所有学生名，批量查错题
    const studentNames = statsRows.map((r) => r.studentName);
    let wrongQuestionsByStudent: Record<
      string,
      { questionId: string; count: number }[]
    > = {};

    if (studentNames.length > 0) {
      // 查出所有 is_correct = false 的答题，按学生+题目分组
      const namesSql = sql.join(
        studentNames.map((name) => sql`${name}`),
        sql`, `,
      );
      const wrongSql = sql`
        SELECT
          s.student_name AS "studentName",
          a.question_id AS "questionId",
          COUNT(*) AS cnt
        FROM ${answers} a
        JOIN ${submissions} s ON s.id = a.submission_id
        WHERE s.student_name = ANY(ARRAY[${namesSql}]::text[])
          AND a.is_correct = false
        GROUP BY s.student_name, a.question_id
        ORDER BY s.student_name, cnt DESC
      `;

      const wrongRows = await this.db.execute<{
        studentName: string;
        questionId: string;
        cnt: string;
      }>(wrongSql);

      const map = new Map<
        string,
        { questionId: string; count: number }[]
      >();
      for (const row of wrongRows) {
        const arr = map.get(row.studentName) ?? [];
        arr.push({ questionId: row.questionId, count: Number(row.cnt) });
        map.set(row.studentName, arr);
      }
      // 每个学生取前 10
      for (const [name, list] of map) {
        wrongQuestionsByStudent[name] = list.slice(0, 10);
      }
    }

    const items: StudentStats[] = statsRows.map((row) => ({
      studentName: row.studentName,
      submissionCount: Number(row.submissionCount),
      avgScore: Number(row.avgScore),
      latestScore: Number(row.latestScore),
      wrongQuestionIds: wrongQuestionsByStudent[row.studentName] ?? [],
    }));

    return {
      items,
      total: Number(total),
    };
  }

  /** 删掉某个学生的全部作业提交 + 打卡记录 */
  async deleteStudent(name: string): Promise<{ ok: boolean; deleted: number }> {
    const subs = await this.db
      .delete(submissions)
      .where(eq(submissions.studentName, name));
    const recs = await this.db
      .delete(checkinRecords)
      .where(eq(checkinRecords.studentName, name));
    const count = Number((subs as any)?.rowCount ?? 0) + Number((recs as any)?.rowCount ?? 0);
    return { ok: true, deleted: count };
  }

  /** 清空全部提交与打卡记录（清测试数据用，题目和任务不动） */
  async clearAllRecords(): Promise<{ ok: boolean }> {
    await this.db.delete(submissions);
    await this.db.delete(checkinRecords);
    return { ok: true };
  }
}
