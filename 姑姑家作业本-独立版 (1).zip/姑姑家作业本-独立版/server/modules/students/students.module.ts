import { Module } from '@nestjs/common';
import { StudentsController } from './students.controller';
import { StudentsService } from './students.service';
import { PortalController } from './portal.controller';
import { PortalService } from './portal.service';
import { TeacherAuthModule } from '../teacher-auth/teacher-auth.module';

@Module({
  imports: [TeacherAuthModule],
  controllers: [StudentsController, PortalController],
  providers: [StudentsService, PortalService],
})
export class StudentsModule {}
