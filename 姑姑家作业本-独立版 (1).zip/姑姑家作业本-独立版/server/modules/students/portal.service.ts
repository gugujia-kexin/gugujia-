import { Inject, Injectable } from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '../../platform/shim';
import { and, asc, eq, inArray } from 'drizzle-orm';
import {
  appConfig,
  assignments,
  checkinRecords,
  checkinTasks,
  submissions,
} from '../../database/schema';

const CLASS_CODE_KEY = 'class_code';
export const DEFAULT_CLASS_CODE = 'GUGUJIA';

export interface PortalTask {
  kind: 'assignment' | 'checkin';
  id: string;
  title: string;
  subject: string;
  accessCode: string;
  deadline: string | null;
  done: boolean;
  score: string | null;
  taskType?: string;
  requirement?: string;
}

@Injectable()
export class PortalService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getClassCode(): Promise<string> {
    const rows = await this.db
      .select({ configValue: appConfig.configValue })
      .from(appConfig)
      .where(eq(appConfig.configKey, CLASS_CODE_KEY))
      .limit(1);
    return rows[0]?.configValue ?? DEFAULT_CLASS_CODE;
  }

  async setClassCode(code: string): Promise<{ classCode: string }> {
    const normalized = code.trim().toUpperCase();
    const existing = await this.db
      .select({ id: appConfig.id })
      .from(appConfig)
      .where(eq(appConfig.configKey, CLASS_CODE_KEY))
      .limit(1);
    if (existing[0]) {
      await this.db
        .update(appConfig)
        .set({ configValue: normalized, updatedAt: new Date() })
        .where(eq(appConfig.configKey, CLASS_CODE_KEY));
    } else {
      await this.db
        .insert(appConfig)
        .values({ configKey: CLASS_CODE_KEY, configValue: normalized });
    }
    return { classCode: normalized };
  }

  /** 学生输入一个码：先当班级码试，再当单个任务的访问码试 */
  async resolveEntry(
    code: string,
  ): Promise<
    | { mode: 'class'; classCode: string }
    | { mode: 'assignment'; code: string }
    | { mode: 'checkin'; code: string }
  > {
    const raw = code.trim().toUpperCase();
    const classCode = await this.getClassCode();
    if (raw === classCode) {
      return { mode: 'class', classCode };
    }
    const asg = await this.db
      .select({ id: assignments.id })
      .from(assignments)
      .where(eq(assignments.accessCode, raw))
      .limit(1);
    if (asg[0]) return { mode: 'assignment', code: raw };
    const ci = await this.db
      .select({ id: checkinTasks.id })
      .from(checkinTasks)
      .where(eq(checkinTasks.accessCode, raw))
      .limit(1);
    if (ci[0]) return { mode: 'checkin', code: raw };
    throw new Error('CODE_NOT_FOUND');
  }

  /** 班级任务清单：老师发布过的作业 + 打卡，标出这个学生做完没有 */
  async taskboard(studentName: string): Promise<{
    classCode: string;
    items: PortalTask[];
    pendingCount: number;
  }> {
    const name = studentName.trim();
    const classCode = await this.getClassCode();

    const asgRows = await this.db
      .select({
        id: assignments.id,
        title: assignments.title,
        subject: assignments.subject,
        accessCode: assignments.accessCode,
        deadline: assignments.deadline,
        isPublished: assignments.isPublished,
        isClosed: assignments.isClosed,
      })
      .from(assignments)
      .where(and(eq(assignments.isPublished, true), eq(assignments.isClosed, false)))
      .orderBy(asc(assignments.createdAt));

    const ciRows = await this.db
      .select({
        id: checkinTasks.id,
        title: checkinTasks.title,
        subject: checkinTasks.subject,
        taskType: checkinTasks.taskType,
        requirement: checkinTasks.requirement,
        accessCode: checkinTasks.accessCode,
        deadline: checkinTasks.deadline,
        isPublished: checkinTasks.isPublished,
        isClosed: checkinTasks.isClosed,
      })
      .from(checkinTasks)
      .where(and(eq(checkinTasks.isPublished, true), eq(checkinTasks.isClosed, false)))
      .orderBy(asc(checkinTasks.createdAt));

    const subRows = asgRows.length
      ? await this.db
          .select({
            assignmentId: submissions.assignmentId,
            autoScore: submissions.autoScore,
            teacherScore: submissions.teacherScore,
          })
          .from(submissions)
          .where(
            and(
              eq(submissions.studentName, name),
              inArray(
                submissions.assignmentId,
                asgRows.map((a) => a.id),
              ),
            ),
          )
      : [];

    const recRows = ciRows.length
      ? await this.db
          .select({ taskId: checkinRecords.taskId })
          .from(checkinRecords)
          .where(
            and(
              eq(checkinRecords.studentName, name),
              inArray(
                checkinRecords.taskId,
                ciRows.map((c) => c.id),
              ),
            ),
          )
      : [];

    const subMap = new Map<string, string>();
    for (const s of subRows) {
      const score = s.teacherScore ?? s.autoScore;
      subMap.set(s.assignmentId, String(score ?? ''));
    }
    const recSet = new Set(recRows.map((r) => r.taskId));

    const items: PortalTask[] = [
      ...asgRows.map((a) => ({
        kind: 'assignment' as const,
        id: a.id,
        title: a.title,
        subject: a.subject,
        accessCode: a.accessCode,
        deadline: a.deadline ? String(a.deadline) : null,
        done: subMap.has(a.id),
        score: subMap.get(a.id) ?? null,
      })),
      ...ciRows.map((c) => ({
        kind: 'checkin' as const,
        id: c.id,
        title: c.title,
        subject: c.subject,
        accessCode: c.accessCode,
        deadline: c.deadline ? String(c.deadline) : null,
        done: recSet.has(c.id),
        score: null,
        taskType: c.taskType,
        requirement: c.requirement ?? '',
      })),
    ];

    const pendingCount = items.filter((i) => !i.done).length;
    return { classCode, items, pendingCount };
  }
}
