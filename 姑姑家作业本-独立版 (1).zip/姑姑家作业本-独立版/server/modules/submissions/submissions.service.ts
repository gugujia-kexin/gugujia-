import {
  BadRequestException,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '../../platform/shim';
import { eq, and, desc, count, inArray } from 'drizzle-orm';
import {
  submissions,
  answers,
  assignments,
  questions,
} from '../../database/schema';
import type {
  GradeSubmissionDto,
  SubmissionListQueryDto,
  SubmitAssignmentDto,
} from './dto/submissions.dto';
import type {
  Answer,
  ListResponse,
  Question,
  Submission,
} from '../../../shared/api.interface';

const POINTS_PER_QUESTION = 10;

function normalizeMultiChoice(answer: string): string {
  return answer
    .split('')
    .sort()
    .join('');
}

function gradeAnswer(
  questionType: string,
  correctAnswer: string,
  studentAnswer: string,
): { isCorrect: boolean | null; autoPoints: number } {
  switch (questionType) {
    case 'choice': {
      const isCorrect = studentAnswer === correctAnswer;
      return { isCorrect, autoPoints: isCorrect ? POINTS_PER_QUESTION : 0 };
    }
    case 'multi_choice': {
      const normalizedStudent = normalizeMultiChoice(studentAnswer);
      const normalizedCorrect = normalizeMultiChoice(correctAnswer);
      const isCorrect = normalizedStudent === normalizedCorrect;
      return { isCorrect, autoPoints: isCorrect ? POINTS_PER_QUESTION : 0 };
    }
    case 'true_false': {
      const isCorrect = studentAnswer === correctAnswer;
      return { isCorrect, autoPoints: isCorrect ? POINTS_PER_QUESTION : 0 };
    }
    case 'fill': {
      const normalizedStudent = studentAnswer.replace(/\s+/g, '');
      const normalizedCorrect = correctAnswer.replace(/\s+/g, '');
      const isCorrect = normalizedStudent === normalizedCorrect;
      return { isCorrect, autoPoints: isCorrect ? POINTS_PER_QUESTION : 0 };
    }
    case 'essay': {
      return { isCorrect: null, autoPoints: 0 };
    }
    default:
      return { isCorrect: false, autoPoints: 0 };
  }
}

@Injectable()
export class SubmissionsService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(query: SubmissionListQueryDto): Promise<ListResponse<Submission>> {
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 20;
    const conditions = [];
    if (query.assignmentId)
      conditions.push(eq(submissions.assignmentId, query.assignmentId));
    if (query.studentName)
      conditions.push(eq(submissions.studentName, query.studentName));
    if (query.status) conditions.push(eq(submissions.status, query.status));

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [totalResult, items] = await Promise.all([
      this.db.select({ count: count() }).from(submissions).where(where),
      this.db
        .select()
        .from(submissions)
        .where(where)
        .orderBy(desc(submissions.submittedAt))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = totalResult[0]?.count ?? 0;

    // 附上作业标题，老师端列表直接显示题目名而不是一串 ID
    const assignmentIds = Array.from(new Set(items.map((i) => i.assignmentId)));
    const titleMap = new Map<string, string>();
    if (assignmentIds.length > 0) {
      const rows = await this.db
        .select({ id: assignments.id, title: assignments.title })
        .from(assignments)
        .where(inArray(assignments.id, assignmentIds));
      rows.forEach((r) => titleMap.set(r.id, r.title));
    }

    return {
      items: items.map((item) => ({
        ...this.toResponse(item),
        assignmentTitle: titleMap.get(item.assignmentId) ?? '',
      })),
      total,
    };
  }

  async getById(id: string): Promise<Submission> {
    const [item] = await this.db
      .select()
      .from(submissions)
      .where(eq(submissions.id, id))
      .limit(1);
    if (!item) throw new NotFoundException('提交记录不存在');

    const answerRows = await this.db
      .select()
      .from(answers)
      .where(eq(answers.submissionId, id));

    const questionIds = answerRows.map((a) => a.questionId);
    let questionList: Question[] = [];
    if (questionIds.length > 0) {
      const questionRows = await this.db
        .select()
        .from(questions)
        .where(inArray(questions.id, questionIds));
      questionList = questionRows.map((q) => ({
        id: q.id,
        subject: q.subject as Question['subject'],
        type: q.type as Question['type'],
        title: q.title,
        options: (q.options as Question['options']) ?? [],
        correctAnswer: q.correctAnswer,
        explanation: q.explanation ?? '',
        difficulty: q.difficulty as Question['difficulty'],
        tags: q.tags ?? [],
        createdAt: q.createdAt.toISOString(),
      }));
    }

    return {
      ...this.toResponse(item),
      answers: answerRows.map((a) => ({
        id: a.id,
        submissionId: a.submissionId,
        questionId: a.questionId,
        studentAnswer: a.studentAnswer,
        isCorrect: a.isCorrect,
        autoPoints: a.autoPoints,
      })),
      questions: questionList,
    };
  }

  async submit(dto: SubmitAssignmentDto): Promise<{ id: string }> {
    // 找到作业
    const [assignment] = await this.db
      .select()
      .from(assignments)
      .where(eq(assignments.accessCode, dto.accessCode))
      .limit(1);
    if (!assignment) throw new NotFoundException('访问码无效');

    // 校验作业状态
    if (!assignment.isPublished) {
      throw new BadRequestException('该作业尚未发布');
    }
    if (assignment.isClosed) {
      throw new BadRequestException('该作业已关闭');
    }
    if (assignment.deadline && new Date() > assignment.deadline) {
      throw new BadRequestException('该作业已过截止时间');
    }

    const studentName = dto.studentName.trim();
    if (!studentName) {
      throw new BadRequestException('学生姓名不能为空');
    }

    const questionIds = assignment.questionIds as string[];
    if (questionIds.length === 0) {
      throw new BadRequestException('作业没有题目');
    }

    // 取出所有题目
    const questionRows = await this.db
      .select()
      .from(questions)
      .where(inArray(questions.id, questionIds));
    const questionMap = new Map<string, (typeof questionRows)[number]>(questionRows.map((q) => [q.id, q] as const));

    // 构建 answer map（按提交顺序，基于 questionIds）
    const answerMap = new Map<string, string>();
    for (const a of dto.answers) {
      answerMap.set(a.questionId, a.studentAnswer);
    }

    // 逐题判分
    let totalAutoScore = 0;
    const answerValues: {
      questionId: string;
      studentAnswer: string;
      isCorrect: boolean | null;
      autoPoints: number;
    }[] = [];

    for (const qid of questionIds) {
      const q = questionMap.get(qid);
      const studentAnswer = answerMap.get(qid) ?? '';
      if (!q) {
        answerValues.push({
          questionId: qid,
          studentAnswer,
          isCorrect: false,
          autoPoints: 0,
        });
        continue;
      }
      const result = gradeAnswer(q.type, q.correctAnswer, studentAnswer);
      totalAutoScore += result.autoPoints;
      answerValues.push({
        questionId: qid,
        studentAnswer,
        isCorrect: result.isCorrect,
        autoPoints: result.autoPoints,
      });
    }

    // 事务：先 count 提交次数，再插入 submission + answers
    const autoScoreStr = totalAutoScore.toString();
    const result = await this.db.transaction(async (tx) => {
      // 统计该学生在这个作业的已有提交数
      const countResult = await tx
        .select({ count: count() })
        .from(submissions)
        .where(
          and(
            eq(submissions.assignmentId, assignment.id),
            eq(submissions.studentName, studentName),
          ),
        );
      const existingCount = countResult[0]?.count ?? 0;

      if (existingCount >= assignment.maxSubmissions) {
        if (!assignment.allowRetry || assignment.maxSubmissions <= 1) {
          throw new BadRequestException('你已提交过该作业，不能再次提交');
        }
        throw new BadRequestException(
          `你已达到最大提交次数（${assignment.maxSubmissions}次），不能再次提交`,
        );
      }

      const submissionIndex = existingCount + 1;

      const [sub] = await tx
        .insert(submissions)
        .values({
          assignmentId: assignment.id,
          studentName,
          autoScore: autoScoreStr,
          teacherScore: null,
          teacherComment: '',
          status: 'submitted',
          submissionIndex,
        })
        .returning({ id: submissions.id });

      if (answerValues.length > 0) {
        await tx.insert(answers).values(
          answerValues.map((a) => ({
            submissionId: sub.id,
            questionId: a.questionId,
            studentAnswer: a.studentAnswer,
            isCorrect: a.isCorrect,
            autoPoints: a.autoPoints.toString(),
          })),
        );
      }

      return sub;
    });

    return { id: result.id };
  }

  async grade(
    id: string,
    dto: GradeSubmissionDto,
  ): Promise<{ id: string }> {
    const updated = await this.db
      .update(submissions)
      .set({
        teacherScore: dto.teacherScore,
        teacherComment: dto.teacherComment ?? '',
        status: 'graded',
      })
      .where(eq(submissions.id, id))
      .returning({ id: submissions.id });
    if (updated.length === 0)
      throw new NotFoundException('提交记录不存在');
    return { id: updated[0].id };
  }

  private toResponse(row: typeof submissions.$inferSelect): Submission {
    return {
      id: row.id,
      assignmentId: row.assignmentId,
      studentName: row.studentName,
      autoScore: row.autoScore,
      teacherScore: row.teacherScore,
      teacherComment: row.teacherComment ?? '',
      status: row.status as Submission['status'],
      submissionIndex: row.submissionIndex,
      submittedAt: row.submittedAt.toISOString(),
    };
  }

  /** 删掉一条提交（连同它的作答明细） */
  async remove(id: string): Promise<{ ok: boolean }> {
    await this.db.delete(answers).where(eq(answers.submissionId, id));
    await this.db.delete(submissions).where(eq(submissions.id, id));
    return { ok: true };
  }
}
