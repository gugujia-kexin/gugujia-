import { Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  Max,
  Min,
} from 'class-validator';
import { SUBMISSION_STATUSES } from '../../../../shared/api.interface';

export class SubmissionListQueryDto {
  @IsOptional()
  @Transform(({ obj, key, value }) =>
    obj[key] === '' ? undefined : value,
  )
  @IsString()
  assignmentId?: string;

  @IsOptional()
  @Transform(({ obj, key, value }) =>
    obj[key] === '' ? undefined : value,
  )
  @IsString()
  studentName?: string;

  @IsOptional()
  @Transform(({ obj, key, value }) =>
    obj[key] === '' ? undefined : value,
  )
  @IsString()
  @IsIn(SUBMISSION_STATUSES)
  status?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  pageSize?: number;
}

export class SubmitAssignmentDto {
  @IsString()
  accessCode!: string;

  @IsString()
  studentName!: string;

  @IsArray()
  answers!: { questionId: string; studentAnswer: string }[];
}

export class GradeSubmissionDto {
  @IsString()
  teacherScore!: string;

  @IsOptional()
  @IsString()
  teacherComment?: string;
}
