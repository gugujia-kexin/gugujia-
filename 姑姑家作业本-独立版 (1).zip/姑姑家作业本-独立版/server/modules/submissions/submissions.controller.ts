import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { NeedLogin } from '../../platform/shim';
import { TeacherAuthGuard } from '../teacher-auth/teacher-auth.guard';
import { SubmissionsService } from './submissions.service';
import {
  GradeSubmissionDto,
  SubmissionListQueryDto,
  SubmitAssignmentDto,
} from './dto/submissions.dto';

@Controller('api/submissions')
export class SubmissionsController {
  constructor(private readonly submissionsService: SubmissionsService) {}

  @UseGuards(TeacherAuthGuard)
  @Get()
  async list(@Query() query: SubmissionListQueryDto) {
    return this.submissionsService.list(query);
  }

  @Get(':id')
  async getById(@Param('id') id: string) {
    return this.submissionsService.getById(id);
  }

  @Post('submit')
  async submit(@Body() dto: SubmitAssignmentDto) {
    return this.submissionsService.submit(dto);
  }

  @UseGuards(TeacherAuthGuard)
  @Delete(':id')
  async remove(@Param('id') id: string) {
    return this.submissionsService.remove(id);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Patch(':id/grade')
  async grade(
    @Param('id') id: string,
    @Body() dto: GradeSubmissionDto,
  ) {
    return this.submissionsService.grade(id, dto);
  }
}
