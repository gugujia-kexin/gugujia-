import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { NeedLogin } from '../../platform/shim';
import { TeacherAuthGuard } from '../teacher-auth/teacher-auth.guard';
import { KnowledgeService } from './knowledge.service';
import {
  CreateKnowledgeDto,
  KnowledgeListQueryDto,
  UpdateKnowledgeDto,
} from './dto/knowledge.dto';

@Controller('api/knowledge')
export class KnowledgeController {
  constructor(private readonly knowledgeService: KnowledgeService) {}

  @UseGuards(TeacherAuthGuard)
  @Get()
  async list(@Query() query: KnowledgeListQueryDto) {
    return this.knowledgeService.list(query);
  }

  @Get(':id')
  async getById(@Param('id') id: string) {
    return this.knowledgeService.getById(id);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Post()
  async create(@Body() dto: CreateKnowledgeDto) {
    return this.knowledgeService.create(dto);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Patch(':id')
  async update(@Param('id') id: string, @Body() dto: UpdateKnowledgeDto) {
    return this.knowledgeService.update(id, dto);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Delete(':id')
  async remove(@Param('id') id: string) {
    return this.knowledgeService.remove(id);
  }
}
