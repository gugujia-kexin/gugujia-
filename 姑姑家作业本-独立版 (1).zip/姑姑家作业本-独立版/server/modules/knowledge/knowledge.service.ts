import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '../../platform/shim';
import { eq, and, desc, count } from 'drizzle-orm';
import { knowledgePoints } from '../../database/schema';
import type {
  CreateKnowledgeDto,
  KnowledgeListQueryDto,
  UpdateKnowledgeDto,
} from './dto/knowledge.dto';
import type {
  KnowledgePoint,
  ListResponse,
} from '../../../shared/api.interface';

@Injectable()
export class KnowledgeService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(
    query: KnowledgeListQueryDto,
  ): Promise<ListResponse<KnowledgePoint>> {
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 20;
    const conditions = [];
    if (query.subject)
      conditions.push(eq(knowledgePoints.subject, query.subject));
    if (query.contentType)
      conditions.push(eq(knowledgePoints.contentType, query.contentType));

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [totalResult, items] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(knowledgePoints)
        .where(where),
      this.db
        .select()
        .from(knowledgePoints)
        .where(where)
        .orderBy(desc(knowledgePoints.createdAt))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = totalResult[0]?.count ?? 0;

    return {
      items: items.map((item) => this.toResponse(item)),
      total,
    };
  }

  async getById(id: string): Promise<KnowledgePoint> {
    const [item] = await this.db
      .select()
      .from(knowledgePoints)
      .where(eq(knowledgePoints.id, id))
      .limit(1);
    if (!item) throw new NotFoundException('知识点不存在');
    return this.toResponse(item);
  }

  async create(dto: CreateKnowledgeDto): Promise<{ id: string }> {
    const [result] = await this.db
      .insert(knowledgePoints)
      .values({
        title: dto.title,
        subject: dto.subject,
        contentType: dto.contentType,
        contentText: dto.contentText ?? '',
        attachmentUrl: dto.attachmentUrl ?? '',
        coverUrl: dto.coverUrl ?? '',
        description: dto.description ?? '',
      })
      .returning({ id: knowledgePoints.id });
    return { id: result.id };
  }

  async update(
    id: string,
    dto: UpdateKnowledgeDto,
  ): Promise<{ id: string }> {
    const patch: Record<string, unknown> = {};
    if (dto.title !== undefined) patch.title = dto.title;
    if (dto.subject !== undefined) patch.subject = dto.subject;
    if (dto.contentType !== undefined) patch.contentType = dto.contentType;
    if (dto.contentText !== undefined) patch.contentText = dto.contentText;
    if (dto.attachmentUrl !== undefined)
      patch.attachmentUrl = dto.attachmentUrl;
    if (dto.coverUrl !== undefined) patch.coverUrl = dto.coverUrl;
    if (dto.description !== undefined) patch.description = dto.description;

    if (Object.keys(patch).length === 0) {
      return { id };
    }

    const updated = await this.db
      .update(knowledgePoints)
      .set(patch)
      .where(eq(knowledgePoints.id, id))
      .returning({ id: knowledgePoints.id });
    if (updated.length === 0) throw new NotFoundException('知识点不存在');
    return { id: updated[0].id };
  }

  async remove(id: string): Promise<{ id: string }> {
    const deleted = await this.db
      .delete(knowledgePoints)
      .where(eq(knowledgePoints.id, id))
      .returning({ id: knowledgePoints.id });
    if (deleted.length === 0) throw new NotFoundException('知识点不存在');
    return { id: deleted[0].id };
  }

  private toResponse(
    row: typeof knowledgePoints.$inferSelect,
  ): KnowledgePoint {
    return {
      id: row.id,
      title: row.title,
      subject: row.subject as KnowledgePoint['subject'],
      contentType: row.contentType as KnowledgePoint['contentType'],
      contentText: row.contentText ?? '',
      attachmentUrl: row.attachmentUrl ?? '',
      coverUrl: row.coverUrl ?? '',
      description: row.description ?? '',
      createdAt: row.createdAt.toISOString(),
    };
  }
}
