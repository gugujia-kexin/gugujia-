import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '../../platform/shim';
import { eq, and, desc, count } from 'drizzle-orm';
import { questions } from '../../database/schema';
import type {
  CreateQuestionDto,
  QuestionListQueryDto,
  UpdateQuestionDto,
} from './dto/questions.dto';
import type { Question, ListResponse } from '../../../shared/api.interface';

@Injectable()
export class QuestionsService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(query: QuestionListQueryDto): Promise<ListResponse<Question>> {
    const page = query.page ?? 1;
    const pageSize = query.pageSize ?? 20;
    const conditions = [];
    if (query.subject) conditions.push(eq(questions.subject, query.subject));
    if (query.type) conditions.push(eq(questions.type, query.type));
    if (query.difficulty)
      conditions.push(eq(questions.difficulty, query.difficulty));

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [totalResult, items] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(questions)
        .where(where),
      this.db
        .select()
        .from(questions)
        .where(where)
        .orderBy(desc(questions.createdAt))
        .limit(pageSize)
        .offset((page - 1) * pageSize),
    ]);

    const total = totalResult[0]?.count ?? 0;

    return {
      items: items.map((item) => this.toResponse(item)),
      total,
    };
  }

  async getById(id: string): Promise<Question> {
    const [item] = await this.db
      .select()
      .from(questions)
      .where(eq(questions.id, id))
      .limit(1);
    if (!item) throw new NotFoundException('题目不存在');
    return this.toResponse(item);
  }

  async create(dto: CreateQuestionDto): Promise<{ id: string }> {
    const [result] = await this.db
      .insert(questions)
      .values({
        subject: dto.subject,
        type: dto.type,
        title: dto.title,
        options: dto.options as unknown as Record<string, unknown>[],
        correctAnswer: dto.correctAnswer,
        explanation: dto.explanation ?? '',
        difficulty: dto.difficulty ?? 'medium',
        tags: dto.tags ?? [],
      })
      .returning({ id: questions.id });
    return { id: result.id };
  }

  async update(id: string, dto: UpdateQuestionDto): Promise<{ id: string }> {
    const patch: Record<string, unknown> = {};
    if (dto.subject !== undefined) patch.subject = dto.subject;
    if (dto.type !== undefined) patch.type = dto.type;
    if (dto.title !== undefined) patch.title = dto.title;
    if (dto.options !== undefined)
      patch.options = dto.options as unknown as Record<string, unknown>[];
    if (dto.correctAnswer !== undefined)
      patch.correctAnswer = dto.correctAnswer;
    if (dto.explanation !== undefined) patch.explanation = dto.explanation;
    if (dto.difficulty !== undefined) patch.difficulty = dto.difficulty;
    if (dto.tags !== undefined) patch.tags = dto.tags;

    if (Object.keys(patch).length === 0) {
      return { id };
    }

    const updated = await this.db
      .update(questions)
      .set(patch)
      .where(eq(questions.id, id))
      .returning({ id: questions.id });
    if (updated.length === 0) throw new NotFoundException('题目不存在');
    return { id: updated[0].id };
  }

  async remove(id: string): Promise<{ id: string }> {
    const deleted = await this.db
      .delete(questions)
      .where(eq(questions.id, id))
      .returning({ id: questions.id });
    if (deleted.length === 0) throw new NotFoundException('题目不存在');
    return { id: deleted[0].id };
  }

  private toResponse(row: typeof questions.$inferSelect): Question {
    return {
      id: row.id,
      subject: row.subject as Question['subject'],
      type: row.type as Question['type'],
      title: row.title,
      options: (row.options as Question['options']) ?? [],
      correctAnswer: row.correctAnswer,
      explanation: row.explanation ?? '',
      difficulty: row.difficulty as Question['difficulty'],
      tags: row.tags ?? [],
      createdAt: row.createdAt.toISOString(),
    };
  }
}
