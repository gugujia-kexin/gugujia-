import { Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  Max,
  Min,
} from 'class-validator';
import {
  DIFFICULTIES,
  QUESTION_TYPES,
  SUBJECTS,
} from '../../../../shared/api.interface';

export class QuestionListQueryDto {
  @IsOptional()
  @Transform(({ obj, key, value }) =>
    obj[key] === '' ? undefined : value,
  )
  @IsString()
  @IsIn(SUBJECTS)
  subject?: string;

  @IsOptional()
  @Transform(({ obj, key, value }) =>
    obj[key] === '' ? undefined : value,
  )
  @IsString()
  @IsIn(QUESTION_TYPES)
  type?: string;

  @IsOptional()
  @Transform(({ obj, key, value }) =>
    obj[key] === '' ? undefined : value,
  )
  @IsString()
  @IsIn(DIFFICULTIES)
  difficulty?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  pageSize?: number;
}

export class CreateQuestionDto {
  @IsString()
  @IsIn(SUBJECTS)
  subject!: string;

  @IsString()
  @IsIn(QUESTION_TYPES)
  type!: string;

  @IsString()
  title!: string;

  @IsArray()
  options!: { label: string; value: string }[];

  @IsString()
  correctAnswer!: string;

  @IsOptional()
  @IsString()
  explanation?: string;

  @IsOptional()
  @IsString()
  @IsIn(DIFFICULTIES)
  difficulty?: string;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];
}

export class UpdateQuestionDto {
  @IsOptional()
  @IsString()
  @IsIn(SUBJECTS)
  subject?: string;

  @IsOptional()
  @IsString()
  @IsIn(QUESTION_TYPES)
  type?: string;

  @IsOptional()
  @IsString()
  title?: string;

  @IsOptional()
  @IsArray()
  options?: { label: string; value: string }[];

  @IsOptional()
  @IsString()
  correctAnswer?: string;

  @IsOptional()
  @IsString()
  explanation?: string;

  @IsOptional()
  @IsString()
  @IsIn(DIFFICULTIES)
  difficulty?: string;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];
}
