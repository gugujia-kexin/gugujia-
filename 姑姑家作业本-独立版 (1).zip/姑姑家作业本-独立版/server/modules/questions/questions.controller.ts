import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { NeedLogin } from '../../platform/shim';
import { TeacherAuthGuard } from '../teacher-auth/teacher-auth.guard';
import { QuestionsService } from './questions.service';
import {
  CreateQuestionDto,
  QuestionListQueryDto,
  UpdateQuestionDto,
} from './dto/questions.dto';

@Controller('api/questions')
export class QuestionsController {
  constructor(private readonly questionsService: QuestionsService) {}

  @UseGuards(TeacherAuthGuard)
  @Get()
  async list(@Query() query: QuestionListQueryDto) {
    return this.questionsService.list(query);
  }

  @Get(':id')
  async getById(@Param('id') id: string) {
    return this.questionsService.getById(id);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Post()
  async create(@Body() dto: CreateQuestionDto) {
    return this.questionsService.create(dto);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Patch(':id')
  async update(@Param('id') id: string, @Body() dto: UpdateQuestionDto) {
    return this.questionsService.update(id, dto);
  }

  @NeedLogin()
  @UseGuards(TeacherAuthGuard)
  @Delete(':id')
  async remove(@Param('id') id: string) {
    return this.questionsService.remove(id);
  }
}
