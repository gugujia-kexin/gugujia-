import { Module } from '@nestjs/common';
import { TeacherAuthService } from './teacher-auth.service';
import { TeacherAuthController } from './teacher-auth.controller';
import { TeacherAuthGuard } from './teacher-auth.guard';

@Module({
  controllers: [TeacherAuthController],
  providers: [TeacherAuthService, TeacherAuthGuard],
  exports: [TeacherAuthService, TeacherAuthGuard],
})
export class TeacherAuthModule {}
