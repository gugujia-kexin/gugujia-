import { Inject, Injectable, OnModuleInit } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '../../platform/shim';
import { genSalt, hash, compare } from 'bcryptjs';
import { randomBytes } from 'crypto';
import { appConfig, teacherSessions } from '../../database/schema';
import { eq, and, gt } from 'drizzle-orm';

const PASSWORD_KEY = 'teacher_password';
const SESSION_TTL_DAYS = 7;

@Injectable()
export class TeacherAuthService implements OnModuleInit {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async onModuleInit(): Promise<void> {
    const existing = await this.db
      .select({ configValue: appConfig.configValue })
      .from(appConfig)
      .where(eq(appConfig.configKey, PASSWORD_KEY));
    if (existing.length === 0) {
      const defaultPassword = 'kexin123';
      const salt = await genSalt(10);
      const hashed = await hash(defaultPassword, salt);
      await this.db.insert(appConfig).values({
        configKey: PASSWORD_KEY,
        configValue: hashed,
      });
    }
  }

  async validatePassword(password: string): Promise<boolean> {
    const rows = await this.db
      .select({ configValue: appConfig.configValue })
      .from(appConfig)
      .where(eq(appConfig.configKey, PASSWORD_KEY));
    if (rows.length === 0) return false;
    return compare(password, rows[0].configValue);
  }

  async createSession(): Promise<string> {
    const token = randomBytes(32).toString('hex');
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + SESSION_TTL_DAYS);
    await this.db.insert(teacherSessions).values({
      sessionToken: token,
      expiresAt,
    });
    return token;
  }

  async validateSession(token: string): Promise<boolean> {
    const rows = await this.db
      .select({ id: teacherSessions.id })
      .from(teacherSessions)
      .where(and(
        eq(teacherSessions.sessionToken, token),
        gt(teacherSessions.expiresAt, new Date()),
      ));
    return rows.length > 0;
  }

  async destroySession(token: string): Promise<void> {
    await this.db.delete(teacherSessions)
      .where(eq(teacherSessions.sessionToken, token));
  }

  async changePassword(oldPassword: string, newPassword: string): Promise<boolean> {
    const valid = await this.validatePassword(oldPassword);
    if (!valid) return false;
    const salt = await genSalt(10);
    const hashed = await hash(newPassword, salt);
    await this.db.update(appConfig)
      .set({ configValue: hashed })
      .where(eq(appConfig.configKey, PASSWORD_KEY));
    return true;
  }
}

