import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import type { Request } from 'express';
import { TeacherAuthService } from './teacher-auth.service';

@Injectable()
export class TeacherAuthGuard implements CanActivate {
  constructor(private readonly authService: TeacherAuthService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest<Request>();
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      throw new UnauthorizedException('请先登录');
    }
    const token = header.slice(7);
    if (!token) {
      throw new UnauthorizedException('请先登录');
    }
    const valid = await this.authService.validateSession(token);
    if (!valid) {
      throw new UnauthorizedException('登录已过期，请重新登录');
    }
    return true;
  }
}
