import {
  Body,
  Controller,
  Get,
  Header,
  Logger,
  Post,
  Req,
  UseGuards,
  UnauthorizedException,
  BadRequestException,
} from '@nestjs/common';
import type { Request } from 'express';
import { TeacherAuthService } from './teacher-auth.service';
import { TeacherAuthGuard } from './teacher-auth.guard';
import type {
  TeacherLoginRequest,
  TeacherLoginResponse,
  TeacherChangePasswordRequest,
  TeacherAuthStatus,
} from '../../../shared/api.interface';

@Controller('api/teacher-auth')
export class TeacherAuthController {
  private readonly logger = new Logger(TeacherAuthController.name);
  constructor(private readonly authService: TeacherAuthService) {}

  @Post('login')
  @Header('Cache-Control', 'no-store')
  async login(
    @Body() body: TeacherLoginRequest,
  ): Promise<TeacherLoginResponse> {
    const valid = await this.authService.validatePassword(body.password);
    if (!valid) {
      throw new UnauthorizedException('密码错误');
    }
    const token = await this.authService.createSession();
    return { ok: true, token };
  }

  @Post('logout')
  @Header('Cache-Control', 'no-store')
  @UseGuards(TeacherAuthGuard)
  async logout(@Req() req: Request): Promise<{ ok: boolean }> {
    const token = extractBearerToken(req);
    if (token) {
      await this.authService.destroySession(token);
    }
    return { ok: true };
  }

  @UseGuards(TeacherAuthGuard)
  @Post('change-password')
  @Header('Cache-Control', 'no-store')
  async changePassword(
    @Body() body: TeacherChangePasswordRequest,
  ): Promise<{ ok: boolean }> {
    if (!body.newPassword || body.newPassword.length < 6) {
      throw new BadRequestException('新密码至少 6 位');
    }
    const success = await this.authService.changePassword(
      body.oldPassword,
      body.newPassword,
    );
    if (!success) {
      throw new UnauthorizedException('原密码错误');
    }
    return { ok: true };
  }

  @Get('status')
  @Header('Cache-Control', 'no-store')
  async status(@Req() req: Request): Promise<TeacherAuthStatus> {
    const token = extractBearerToken(req);
    if (!token) return { isLoggedIn: false };
    const valid = await this.authService.validateSession(token);
    return { isLoggedIn: valid };
  }
}

function extractBearerToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) return null;
  return header.slice(7);
}
