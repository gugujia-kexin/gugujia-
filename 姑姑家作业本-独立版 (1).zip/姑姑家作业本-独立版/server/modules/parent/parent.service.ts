import { Inject, Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '../../platform/shim';
import { genSalt, hash, compare } from 'bcryptjs';
import { randomBytes } from 'crypto';
import { eq, and, gt, desc } from 'drizzle-orm';
import {
  parents, parentSessions, submissions, assignments,
  checkinRecords, checkinTasks,
} from '../../database/schema';

const SESSION_TTL_DAYS = 7;

@Injectable()
export class ParentService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async login(username: string, password: string) {
    const rows = await this.db.select().from(parents).where(eq(parents.username, username));
    if (rows.length === 0) throw new BadRequestException('账号或密码错误');
    const p = rows[0];
    const ok = await compare(password, p.passwordHash);
    if (!ok) throw new BadRequestException('账号或密码错误');
    const token = randomBytes(32).toString('hex');
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + SESSION_TTL_DAYS);
    await this.db.insert(parentSessions).values({ sessionToken: token, parentId: p.id, expiresAt });
    return { token, studentName: p.studentName };
  }

  async validateSession(token: string) {
    const rows = await this.db
      .select({
        id: parents.id,
        username: parents.username,
        studentName: parents.studentName,
      })
      .from(parentSessions)
      .innerJoin(parents, eq(parents.id, parentSessions.parentId))
      .where(and(
        eq(parentSessions.sessionToken, token),
        gt(parentSessions.expiresAt, new Date()),
      ));
    return rows[0] ?? null;
  }

  async destroySession(token: string): Promise<void> {
    await this.db.delete(parentSessions).where(eq(parentSessions.sessionToken, token));
  }

  async list() {
    const rows = await this.db
      .select({
        id: parents.id,
        username: parents.username,
        studentName: parents.studentName,
        createdAt: parents.createdAt,
      })
      .from(parents)
      .orderBy(desc(parents.createdAt));
    return rows.map((r) => ({
      id: r.id,
      username: r.username,
      studentName: r.studentName,
      createdAt: r.createdAt instanceof Date ? r.createdAt.toISOString() : String(r.createdAt),
    }));
  }

  async create(body: { username: string; password: string; studentName: string }) {
    const username = body.username.trim();
    const studentName = body.studentName.trim();
    if (!username) throw new BadRequestException('家长账号必填');
    if (!body.password || body.password.length < 6) throw new BadRequestException('密码至少 6 位');
    if (!studentName) throw new BadRequestException('请填写绑定的学生姓名');
    const dup = await this.db.select({ id: parents.id }).from(parents).where(eq(parents.username, username));
    if (dup.length > 0) throw new BadRequestException('这个家长账号已经存在');
    const salt = await genSalt(10);
    const passwordHash = await hash(body.password, salt);
    const [row] = await this.db
      .insert(parents)
      .values({ username, passwordHash, studentName })
      .returning({ id: parents.id });
    return row;
  }

  async update(id: string, body: { studentName?: string; password?: string }) {
    const patch: Record<string, unknown> = {};
    if (body.studentName !== undefined) patch.studentName = body.studentName.trim();
    if (body.password) {
      if (body.password.length < 6) throw new BadRequestException('新密码至少 6 位');
      const salt = await genSalt(10);
      patch.passwordHash = await hash(body.password, salt);
    }
    if (Object.keys(patch).length === 0) return;
    await this.db.update(parents).set(patch).where(eq(parents.id, id));
  }

  async remove(id: string): Promise<void> {
    await this.db.delete(parents).where(eq(parents.id, id));
  }

  async overview(parentId: string) {
    const [p] = await this.db
      .select({ studentName: parents.studentName })
      .from(parents)
      .where(eq(parents.id, parentId));
    if (!p) throw new NotFoundException('账号不存在');

    const subRows = await this.db
      .select({
        assignmentTitle: assignments.title,
        subject: assignments.subject,
        autoScore: submissions.autoScore,
        teacherScore: submissions.teacherScore,
        teacherComment: submissions.teacherComment,
        status: submissions.status,
        submittedAt: submissions.submittedAt,
      })
      .from(submissions)
      .leftJoin(assignments, eq(assignments.id, submissions.assignmentId))
      .where(eq(submissions.studentName, p.studentName))
      .orderBy(desc(submissions.submittedAt));

    const ckRows = await this.db
      .select({
        taskTitle: checkinTasks.title,
        note: checkinRecords.note,
        teacherComment: checkinRecords.teacherComment,
        status: checkinRecords.status,
        submittedAt: checkinRecords.submittedAt,
      })
      .from(checkinRecords)
      .leftJoin(checkinTasks, eq(checkinTasks.id, checkinRecords.taskId))
      .where(eq(checkinRecords.studentName, p.studentName))
      .orderBy(desc(checkinRecords.submittedAt));

    const iso = (d: unknown) => (d instanceof Date ? d.toISOString() : String(d));

    return {
      studentName: p.studentName,
      submissions: subRows.map((r) => ({
        assignmentTitle: r.assignmentTitle ?? '作业',
        subject: r.subject ?? '',
        score: r.teacherScore ?? r.autoScore,
        teacherComment: r.teacherComment,
        status: r.status,
        submittedAt: iso(r.submittedAt),
      })),
      checkins: ckRows.map((r) => ({
        taskTitle: r.taskTitle ?? '打卡',
        note: r.note,
        teacherComment: r.teacherComment,
        status: r.status,
        submittedAt: iso(r.submittedAt),
      })),
    };
  }
}
