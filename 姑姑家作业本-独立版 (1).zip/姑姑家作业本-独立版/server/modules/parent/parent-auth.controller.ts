import { Body, Controller, Get, Header, Post, Req, UseGuards } from '@nestjs/common';
import type { Request } from 'express';
import { ParentService } from './parent.service';
import { ParentGuard } from './parent.guard';
import type { ParentLoginRequest, ParentLoginResponse, ParentOverview } from '../../../shared/api.interface';

@Controller('api/parent-auth')
export class ParentAuthController {
  constructor(private readonly parentService: ParentService) {}

  @Post('login')
  @Header('Cache-Control', 'no-store')
  async login(@Body() body: ParentLoginRequest): Promise<ParentLoginResponse> {
    const { token, studentName } = await this.parentService.login(body.username, body.password);
    return { ok: true, token, studentName };
  }

  @UseGuards(ParentGuard)
  @Get('status')
  @Header('Cache-Control', 'no-store')
  async status(@Req() req: Request): Promise<{ isLoggedIn: boolean; studentName?: string }> {
    const me = (req as Request & { parent?: { studentName: string } }).parent;
    return { isLoggedIn: true, studentName: me?.studentName };
  }

  @UseGuards(ParentGuard)
  @Post('logout')
  async logout(@Req() req: Request): Promise<{ ok: boolean }> {
    const header = req.headers.authorization;
    if (header?.startsWith('Bearer ')) {
      await this.parentService.destroySession(header.slice(7));
    }
    return { ok: true };
  }
}
