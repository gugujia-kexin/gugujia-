import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import type { Request } from 'express';
import { ParentService } from './parent.service';
import { ParentGuard } from './parent.guard';
import type { ParentOverview } from '../../../shared/api.interface';

@Controller('api/parent')
@UseGuards(ParentGuard)
export class ParentOverviewController {
  constructor(private readonly parentService: ParentService) {}

  @Get('overview')
  async overview(@Req() req: Request): Promise<ParentOverview> {
    const me = (req as Request & { parent?: { id: string } }).parent;
    return this.parentService.overview(me!.id);
  }
}
