import { Module } from '@nestjs/common';
import { ParentService } from './parent.service';
import { ParentGuard } from './parent.guard';
import { ParentAuthController } from './parent-auth.controller';
import { ParentManageController } from './parent-manage.controller';
import { ParentOverviewController } from './parent-overview.controller';
import { TeacherAuthModule } from '../teacher-auth/teacher-auth.module';

@Module({
  imports: [TeacherAuthModule],
  controllers: [ParentAuthController, ParentManageController, ParentOverviewController],
  providers: [ParentService, ParentGuard],
  exports: [ParentService, ParentGuard],
})
export class ParentModule {}
