import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ParentService } from './parent.service';
import { TeacherAuthGuard } from '../teacher-auth/teacher-auth.guard';
import type { ParentAccount } from '../../../shared/api.interface';

@Controller('api/parents')
@UseGuards(TeacherAuthGuard)
export class ParentManageController {
  constructor(private readonly parentService: ParentService) {}

  @Get()
  async list(): Promise<{ items: ParentAccount[] }> {
    const items = await this.parentService.list();
    return { items };
  }

  @Post()
  async create(@Body() body: { username: string; password: string; studentName: string }) {
    return this.parentService.create(body);
  }

  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() body: { studentName?: string; password?: string },
  ) {
    await this.parentService.update(id, body);
    return { ok: true };
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    await this.parentService.remove(id);
    return { ok: true };
  }
}
