import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import type { Request } from 'express';
import { ParentService } from './parent.service';

@Injectable()
export class ParentGuard implements CanActivate {
  constructor(private readonly parentService: ParentService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest<Request & { parent?: unknown }>();
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) throw new UnauthorizedException('请先登录');
    const token = header.slice(7);
    if (!token) throw new UnauthorizedException('请先登录');
    const me = await this.parentService.validateSession(token);
    if (!me) throw new UnauthorizedException('登录已过期，请重新登录');
    req.parent = me;
    return true;
  }
}
