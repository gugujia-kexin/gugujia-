import 'dotenv/config';
import { NestFactory } from '@nestjs/core';
import { Logger } from '@nestjs/common';
import { join } from 'path';
import { __express as hbsExpressEngine } from 'hbs';

import type { NestExpressApplication } from '@nestjs/platform-express';
import { AppModule } from './app.module';
import { configureApp } from './platform/shim';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, {
    abortOnError: process.env.NODE_ENV !== 'development',
    bodyParser: false,
  });

  await configureApp(app, { disableSwagger: true });

  const logger = new Logger('Bootstrap');
  const host = process.env.SERVER_HOST || '0.0.0.0';
  const port = Number(process.env.SERVER_PORT || '3000');

  // 注册视图引擎，渲染 dist/client 下的 html 文件
  app.setBaseViewsDir(join(process.cwd(), 'dist/client'));
  app.setViewEngine('html');
  // 关闭视图缓存：重新构建前端后无需重启也能拿到最新的 index.html
  app.getHttpAdapter().getInstance().set('view cache', false);
  app.engine('html', hbsExpressEngine);

  await app.listen(port, host);
  logger.log(`服务已启动：http://${host}:${port}`);
  logger.log(`接口地址：http://${host}:${port}/api`);
}

bootstrap();
