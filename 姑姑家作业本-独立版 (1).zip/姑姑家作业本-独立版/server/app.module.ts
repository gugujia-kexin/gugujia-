import { APP_FILTER } from '@nestjs/core';
import { Module } from '@nestjs/common';
import { PlatformModule } from './platform/shim';

import { GlobalExceptionFilter } from './common/filters/exception.filter';
import { ViewModule } from './modules/view/view.module';
import { QuestionsModule } from './modules/questions/questions.module';
import { AssignmentsModule } from './modules/assignments/assignments.module';
import { SubmissionsModule } from './modules/submissions/submissions.module';
import { KnowledgeModule } from './modules/knowledge/knowledge.module';
import { CheckinModule } from './modules/checkin/checkin.module';
import { StudentsModule } from './modules/students/students.module';
import { TeacherAuthModule } from './modules/teacher-auth/teacher-auth.module';
import { ParentModule } from './modules/parent/parent.module';

@Module({
  imports: [
    // 平台 Module，提供平台能力
    PlatformModule.forRoot(),
    // ====== @route-section: business-modules START ======
    // Place all business modules here.Do NOT add fallback modules here.
    QuestionsModule,
    AssignmentsModule,
    SubmissionsModule,
    KnowledgeModule,
    CheckinModule,
    StudentsModule,
    TeacherAuthModule,
    ParentModule,
    // ====== @route-section: business-modules END ======

    // ⚠️ @route-order: last
    // ViewModule is the fallback route module, must be registered last.
    ViewModule,
  ],
  providers: [
    {
      provide: APP_FILTER,
      useClass: GlobalExceptionFilter,
    },
  ],
})
export class AppModule {}
