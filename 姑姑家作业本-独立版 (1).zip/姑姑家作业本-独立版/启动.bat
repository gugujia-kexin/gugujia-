@echo off
chcp 65001 >nul
cd /d %~dp0
echo === 姑姑家作业本 启动 ===
if not exist node_modules (
  echo 第一次运行，正在安装依赖，请稍等...
  call npm install
)
if not exist dist (
  echo 正在构建...
  call npm run build
)
echo 启动服务，浏览器打开 http://localhost:3000
call npm start
pause
