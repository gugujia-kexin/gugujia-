/**
 * 建表脚本：独立部署版专用
 * 用法：npm run db:init    （先确保 .env 里的 DATABASE_URL 指向一个空库）
 * 重复执行不会报错，已存在的表会被跳过。
 */
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const postgres = require('postgres');

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('没有找到 DATABASE_URL，请在 .env 里配置');
  process.exit(1);
}

const IGNORABLE = new Set(['42P07', '42710', '42P16', '23505', '42723']);

(async () => {
  const sql = postgres(url, { max: 1, onnotice: () => {} });
  try {
    // 1. 平台自定义的复合类型（原库由平台预建，这里自己补上）
    await sql.unsafe(`DO $$ BEGIN
  CREATE TYPE user_profile AS (user_id text);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;`);
    await sql.unsafe(`DO $$ BEGIN
  CREATE TYPE file_attachment AS (bucket_id text, file_path text);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;`);

    // 2. 按顺序执行 schema 生成的建表 SQL
    const file = path.resolve(__dirname, '..', 'drizzle', '0000_init.sql');
    const statements = fs
      .readFileSync(file, 'utf8')
      .split('--> statement-breakpoint')
      .map((s) => s.trim())
      .filter(Boolean);

    let ok = 0;
    let skipped = 0;
    for (const stmt of statements) {
      try {
        await sql.unsafe(stmt);
        ok += 1;
      } catch (e) {
        if (IGNORABLE.has(e.code)) {
          skipped += 1;
        } else {
          console.error('执行失败：', stmt.slice(0, 120));
          throw e;
        }
      }
    }
    console.log(`建表完成：成功 ${ok} 条，跳过已存在 ${skipped} 条`);
  } finally {
    await sql.end({ timeout: 5 });
  }
})().catch((e) => {
  console.error(e.message || e);
  process.exit(1);
});
